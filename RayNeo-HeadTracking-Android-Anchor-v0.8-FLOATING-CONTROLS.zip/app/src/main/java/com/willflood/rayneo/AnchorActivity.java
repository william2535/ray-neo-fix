package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/**
 * RayNeo 3DoF Spatial Desktop v0.7.
 *
 * Important architectural change from v0.6:
 * v0.6 translated full-display child views outside a display-sized parent. On some Android
 * compositors that effectively behaves like one moving panel. v0.7 instead creates a large
 * world canvas (~5 display widths), places three real panels at fixed world coordinates, and
 * moves the camera (the world container) from the Air 4 Pro head pose.
 *
 * Centre = live Android capture. Left/right = independent saved views for now.
 */
public class AnchorActivity extends Activity {
    public static final String ACTION_OVERLAY = "com.willflood.rayneo.ANCHOR_OVERLAY_ACTION";
    public static final String EXTRA_COMMAND = "command";
    public static final String CMD_SNAP_LEFT = "snap_left";
    public static final String CMD_SNAP_RIGHT = "snap_right";
    public static final String CMD_PIN = "pin";
    public static final String CMD_STOP = "stop";

    private static final int REQ_CAPTURE = 4401;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;
    private static final long UI_INTERVAL_MS = 250L;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;
    private SpatialPresentation presentation;

    private TextView status, poseInfo, renderInfo;
    private boolean overlayPermissionRequested;

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_OVERLAY.equals(intent.getAction())) return;
            String command = intent.getStringExtra(EXTRA_COMMAND);
            if (CMD_SNAP_LEFT.equals(command)) snapshot(true);
            else if (CMD_SNAP_RIGHT.equals(command)) snapshot(false);
            else if (CMD_PIN.equals(command)) pinHere();
            else if (CMD_STOP.equals(command)) stopAnchor();
        }
    };

    private volatile float latestPitch, latestYaw;
    private float filteredPitch, filteredYaw;
    private float anchorPitch, anchorYaw;
    private boolean havePose;

    private boolean anchorRunning, stopping;
    private boolean invertX = true, invertY = true; // proven on user's Air 4 Pro
    private float panelScale = 0.72f;
    private float panelSpacingScreens = 1.02f;
    private float hFovDeg = 46f, vFovDeg = 27f;
    private long lastFrameNs, lastUiMs;
    private float lastDx, lastDy;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (isFinishing() || isDestroyed()) return;

            if (TrackingService.livePoseValid) {
                latestPitch = (float) TrackingService.livePitch;
                latestYaw = (float) TrackingService.liveYaw;
                if (!havePose) {
                    filteredPitch = latestPitch;
                    filteredYaw = latestYaw;
                    anchorPitch = filteredPitch;
                    anchorYaw = filteredYaw;
                    havePose = true;
                }
            }

            if (havePose) {
                float dt = lastFrameNs == 0 ? 1f/60f : Math.min(.05f,(frameTimeNanos-lastFrameNs)/1_000_000_000f);
                float alpha = 1f-(float)Math.exp(-dt*30f);
                filteredPitch += (latestPitch-filteredPitch)*alpha;
                filteredYaw += (latestYaw-filteredYaw)*alpha;
            }
            lastFrameNs = frameTimeNanos;

            if (anchorRunning && !stopping) updateCamera();

            long now = SystemClock.uptimeMillis();
            if (now-lastUiMs >= UI_INTERVAL_MS) {
                lastUiMs=now;
                poseInfo.setText(String.format(Locale.UK,
                        "PITCH %+7.2f°   YAW %+7.2f°\nPIN   %+7.2f°   %+7.2f°",
                        filteredPitch,filteredYaw,anchorPitch,anchorYaw));
                renderInfo.setText(String.format(Locale.UK,
                        "CAMERA X %+7.0f px   Y %+7.0f px\nLEFT / CENTRE / RIGHT fixed in world\nscale %.2f  spacing %.2f screens",
                        lastDx,lastDy,panelScale,panelSpacingScreens));
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(overlayReceiver, new IntentFilter(ACTION_OVERLAY));
        buildUi();
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,32); sv.addView(root);
        TextView title=new TextView(this); title.setText("RAYNEO SPATIAL DESKTOP • v0.8"); title.setTextSize(24); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView help=new TextView(this); help.setText("Spatial desktop + floating controls. Centre is live Android. Enable the floating bar, open any app, then snapshot it directly into Left or Right without coming back here."); help.setPadding(0,8,0,12); root.addView(help);
        status=box(root,"Ready");
        poseInfo=box(root,"IMU waiting…");
        renderInfo=box(root,"Spatial canvas not started");

        TextView sz=new TextView(this); sz.setText("Panel size"); root.addView(sz);
        SeekBar size=new SeekBar(this); size.setMax(100); size.setProgress(60); root.addView(size);
        TextView sp=new TextView(this); sp.setText("Panel spacing"); root.addView(sp);
        SeekBar spacing=new SeekBar(this); spacing.setMax(100); spacing.setProgress(52); root.addView(spacing);

        CheckBox ix=new CheckBox(this); ix.setText("Invert horizontal anchor"); ix.setChecked(true); root.addView(ix);
        CheckBox iy=new CheckBox(this); iy.setText("Invert vertical anchor"); iy.setChecked(true); root.addView(iy);

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button start=button("START ANCHOR",0xff2f7d4a), pin=button("PIN HERE",0xff59645b);
        row.addView(start,new LinearLayout.LayoutParams(0,-2,1)); row.addView(pin,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);

        LinearLayout snap=new LinearLayout(this); snap.setOrientation(LinearLayout.HORIZONTAL);
        Button sl=button("SNAP LEFT",0xff4f638c), sr=button("SNAP RIGHT",0xff4f638c);
        snap.addView(sl,new LinearLayout.LayoutParams(0,-2,1)); snap.addView(sr,new LinearLayout.LayoutParams(0,-2,1)); root.addView(snap);

        Button floating=button("ENABLE FLOATING CONTROLS",0xff7b4f9c);
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2); flp.setMargins(0,8,0,8); root.addView(floating,flp);

        LinearLayout clr=new LinearLayout(this); clr.setOrientation(LinearLayout.HORIZONTAL);
        Button cl=button("CLEAR LEFT",0xff555555), cr=button("CLEAR RIGHT",0xff555555);
        clr.addView(cl,new LinearLayout.LayoutParams(0,-2,1)); clr.addView(cr,new LinearLayout.LayoutParams(0,-2,1)); root.addView(clr);

        Button stop=button("STOP ANCHOR",0xffa43f35); root.addView(stop);
        TextView note=new TextView(this); note.setText("USE: Start Anchor → PIN HERE → Enable Floating Controls. Then leave this app. Open YouTube/GTA/etc and use the floating ◀ SNAP / PIN / SNAP ▶ bar. The bar hides itself briefly before each snapshot so it is not saved into the panel."); note.setPadding(0,16,0,0); root.addView(note);

        start.setOnClickListener(v->requestCapture()); pin.setOnClickListener(v->pinHere()); stop.setOnClickListener(v->stopAnchor());
        sl.setOnClickListener(v->snapshot(true)); sr.setOnClickListener(v->snapshot(false)); cl.setOnClickListener(v->clear(true)); cr.setOnClickListener(v->clear(false));
        floating.setOnClickListener(v->enableFloatingControls());
        ix.setOnCheckedChangeListener((b2,c)->invertX=c); iy.setOnCheckedChangeListener((b2,c)->invertY=c);
        size.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelScale=.46f+.42f*(p/100f);layoutWorld();}});
        spacing.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelSpacingScreens=.78f+.75f*(p/100f);layoutWorld();}});
        panelScale=.46f+.42f*.60f; panelSpacingScreens=.78f+.75f*.52f;
        setContentView(sv);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener { public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }
    private TextView box(LinearLayout r,String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(13);v.setTypeface(Typeface.MONOSPACE);v.setTextColor(0xffe8eee8);v.setBackgroundColor(0xff20242a);v.setPadding(12,12,12,12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);r.addView(v,lp);return v;}
    private Button button(String t,int c){Button b=new Button(this);b.setText(t);b.setTextColor(Color.WHITE);b.setBackgroundColor(c);return b;}


    private void enableFloatingControls() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlayPermissionRequested = true;
            status.setText("Allow ‘Display over other apps’, then return here");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        try {
            Intent i = new Intent(this, OverlayControlService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("FLOATING CONTROLS ACTIVE — switch to another app");
        } catch (Throwable t) {
            status.setText("Could not start floating controls: " + t.getMessage());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (overlayPermissionRequested && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            overlayPermissionRequested = false;
            startOverlayService();
        }
    }

    private Display externalDisplay(){DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);Display[] p=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);if(p!=null)for(Display d:p)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;for(Display d:dm.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return null;}

    private void requestCapture(){
        if(anchorRunning||projection!=null){status.setText("Already running — STOP first");return;}
        Display d=externalDisplay(); if(d==null){status.setText("No external RayNeo display detected");return;}
        status.setText("Requesting Android screen capture…"); startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(req!=REQ_CAPTURE)return;
        if(result!=RESULT_OK||data==null){status.setText("Capture permission cancelled");return;}
        projection=projectionManager.getMediaProjection(result,data); if(projection==null){status.setText("MediaProjection failed");return;}
        projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(!stopping){anchorRunning=false;status.setText("Capture stopped by Android");}});}};
        projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper()));
        startSpatialDisplay();
    }

    private void startSpatialDisplay(){
        Display d=externalDisplay(); if(d==null){status.setText("RayNeo display disappeared");stopAnchor();return;}
        try{presentation=new SpatialPresentation(this,d);presentation.show();}catch(Throwable t){status.setText("Presentation failed: "+t.getMessage());stopAnchor();return;}
        presentation.root.post(()->{layoutWorld(); attachCapture(); pinHere();});
    }

    private void attachCapture(){
        if(presentation==null)return;
        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startVirtualDisplay(st);}
            public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseVD();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(presentation.texture.isAvailable())startVirtualDisplay(presentation.texture.getSurfaceTexture());
    }

    private void startVirtualDisplay(SurfaceTexture st){
        releaseVD(); if(stopping||projection==null||st==null)return;
        DisplayMetrics m=new DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(m);
        float ds=Math.min(1f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(m.widthPixels,m.heightPixels));
        int w=Math.max(320,Math.round(m.widthPixels*ds)),h=Math.max(240,Math.round(m.heightPixels*ds)),dpi=Math.max(160,Math.round(m.densityDpi*ds));
        st.setDefaultBufferSize(w,h); captureSurface=new Surface(st);
        virtualDisplay=projection.createVirtualDisplay("RayNeoSpatialCapture",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,captureSurface,null,null);
        anchorRunning=virtualDisplay!=null;
        status.setText(anchorRunning?"SPATIAL DESKTOP ACTIVE — three world positions":"Virtual display failed");
    }

    private void layoutWorld(){
        if(presentation==null||presentation.root==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight(); if(vw<=0||vh<=0)return;
        int worldW=vw*5;
        FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)presentation.world.getLayoutParams();wlp.width=worldW;wlp.height=vh;wlp.gravity=Gravity.TOP|Gravity.LEFT;presentation.world.setLayoutParams(wlp);
        int pw=Math.max(320,Math.round(vw*panelScale));int ph=Math.max(240,Math.round(vh*panelScale));
        float cx=worldW/2f;
        float gap=panelSpacingScreens*vw;
        placePanel(presentation.leftPanel,pw,ph,cx-gap, vh/2f);
        placePanel(presentation.centerPanel,pw,ph,cx, vh/2f);
        placePanel(presentation.rightPanel,pw,ph,cx+gap, vh/2f);
        presentation.worldCenterX=cx;
        updateCamera();
    }

    private void placePanel(View v,int w,int h,float centerX,float centerY){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();lp.width=w;lp.height=h;lp.gravity=Gravity.TOP|Gravity.LEFT;v.setLayoutParams(lp);v.setX(centerX-w/2f);v.setY(centerY-h/2f);}

    private void pinHere(){
        if(!havePose&&TrackingService.livePoseValid){latestPitch=(float)TrackingService.livePitch;latestYaw=(float)TrackingService.liveYaw;filteredPitch=latestPitch;filteredYaw=latestYaw;havePose=true;}
        if(!havePose){status.setText("Start head tracking first — no IMU pose yet");return;}
        filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;updateCamera();status.setText("PINNED — centre is straight ahead");
    }

    private void updateCamera(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float yaw=filteredYaw-anchorYaw,pitch=filteredPitch-anchorPitch;
        float dx=(invertX?1f:-1f)*(yaw/hFovDeg)*vw;
        float dy=(invertY?1f:-1f)*(pitch/vFovDeg)*vh;
        float baseX=vw/2f-presentation.worldCenterX;
        presentation.world.setTranslationX(baseX+dx);
        presentation.world.setTranslationY(dy);
        lastDx=dx;lastDy=dy;
    }

    private void snapshot(boolean left){
        if(presentation==null||!presentation.texture.isAvailable()){status.setText("Start Anchor first");return;}
        try{Bitmap b=presentation.texture.getBitmap();if(b==null){status.setText("Snapshot empty");return;}ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView label=left?presentation.leftLabel:presentation.rightLabel;iv.setImageBitmap(b);iv.setVisibility(View.VISIBLE);label.setVisibility(View.GONE);status.setText(left?"LEFT panel saved":"RIGHT panel saved");}catch(Throwable t){status.setText("Snapshot failed: "+t.getMessage());}
    }
    private void clear(boolean left){if(presentation==null)return;ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView l=left?presentation.leftLabel:presentation.rightLabel;iv.setImageDrawable(null);iv.setVisibility(View.GONE);l.setVisibility(View.VISIBLE);}

    private void releaseVD(){VirtualDisplay vd=virtualDisplay;virtualDisplay=null;if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}Surface s=captureSurface;captureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){} }
    private void stopAnchor(){
        if(stopping)return;stopping=true;anchorRunning=false;releaseVD();
        SpatialPresentation p=presentation;presentation=null;if(p!=null){try{p.texture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        MediaProjection mp=projection;projection=null;if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}
        projectionCallback=null;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");
    }
    @Override protected void onDestroy(){
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        try{unregisterReceiver(overlayReceiver);}catch(Throwable ignored){}
        try{stopService(new Intent(this,OverlayControlService.class));}catch(Throwable ignored){}
        stopAnchor();
        super.onDestroy();
    }

    private static class SpatialPresentation extends Presentation {
        FrameLayout root,world,leftPanel,centerPanel,rightPanel;TextureView texture;ImageView leftImage,rightImage;TextView leftLabel,rightLabel;float worldCenterX;
        SpatialPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){
            super.onCreate(b);getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(true);
            world=new FrameLayout(getContext());world.setBackgroundColor(Color.BLACK);world.setClipChildren(false);world.setClipToPadding(false);root.addView(world,new FrameLayout.LayoutParams(1,-1,Gravity.TOP|Gravity.LEFT));
            leftPanel=panel(getContext(),0xff171b22);centerPanel=panel(getContext(),Color.BLACK);rightPanel=panel(getContext(),0xff171b22);
            world.addView(leftPanel,new FrameLayout.LayoutParams(1,1));world.addView(centerPanel,new FrameLayout.LayoutParams(1,1));world.addView(rightPanel,new FrameLayout.LayoutParams(1,1));
            leftImage=image(getContext());leftPanel.addView(leftImage,new FrameLayout.LayoutParams(-1,-1));leftLabel=label(getContext(),"LEFT\nSNAPSHOT");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1));
            texture=new TextureView(getContext());texture.setOpaque(true);centerPanel.addView(texture,new FrameLayout.LayoutParams(-1,-1));TextView ct=tag(getContext(),"CENTRE • LIVE");FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=10;centerPanel.addView(ct,ctlp);
            rightImage=image(getContext());rightPanel.addView(rightImage,new FrameLayout.LayoutParams(-1,-1));rightLabel=label(getContext(),"RIGHT\nSNAPSHOT");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1));
            setContentView(root);
        }
        private static FrameLayout panel(Context c,int bg){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(bg);f.setClipChildren(true);f.setElevation(2f);return f;}
        private static ImageView image(Context c){ImageView i=new ImageView(c);i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);i.setVisibility(View.GONE);return i;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(28);v.setGravity(Gravity.CENTER);v.setTextColor(0xffe0e0e0);v.setBackgroundColor(0xff171b22);return v;}
        private static TextView tag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(13);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }
}
