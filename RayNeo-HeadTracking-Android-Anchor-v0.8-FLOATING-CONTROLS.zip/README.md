# RayNeo Head Tracker + Spatial Desktop v0.8

Hardware-tested base: RayNeo Air 4 Pro IMU head tracking, Android virtual mouse, and 3DoF anchored display.

## v0.8 change
Adds a floating Android overlay controller so Left/Right snapshots can be taken while another app is actually open.

Floating controls:
- ◀ SNAP — saves the current captured screen to the Left spatial panel
- 📌 PIN — recentres the spatial desktop at the current head direction
- SNAP ▶ — saves the current captured screen to the Right spatial panel
- × — closes the floating controls

The floating bar temporarily hides itself before a snapshot, waits briefly for the compositor to update, triggers the snapshot, then reappears. This prevents the control bar itself being baked into the saved panel.

First use requires Android's **Display over other apps** permission.

Recommended flow:
1. Start RayNeo tracking.
2. Start Anchor and approve screen capture.
3. PIN HERE.
4. Enable Floating Controls and grant overlay permission.
5. Open another Android app.
6. Tap ◀ SNAP or SNAP ▶ while that app is visible.
7. Open a different app and save the other side.
8. Leave a third app live in Centre and turn your head between the spatial panels.
