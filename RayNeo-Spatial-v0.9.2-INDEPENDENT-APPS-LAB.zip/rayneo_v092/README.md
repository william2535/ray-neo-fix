# RayNeo Spatial v0.9.2 — Independent Apps LAB

This build advances the hardware-proven v0.9.1 VirtualDisplay test. v0.9.1 confirmed that LEFT and RIGHT app-owned VirtualDisplays can be created independently or together without slowing the Air 4 Pro tracking path.

## What changed
- Keeps the proven v0.8/v0.9.1 USB, IMU, tracker and spatial renderer path.
- LEFT and RIGHT VirtualDisplays still only exist when you manually create them.
- Adds **LAUNCH LEFT APP** and **LAUNCH RIGHT APP**.
- Each button lists installed launchable Android apps and requests launch onto that side display using Android `ActivityOptions.setLaunchDisplayId()`.
- All picker/create/launch failures are caught and shown in the LAB status area instead of intentionally taking down Anchor Mode.

## Test order
1. Start Tracking and confirm it remains smooth.
2. Start Anchor and PIN HERE.
3. CREATE LEFT DISPLAY.
4. LAUNCH LEFT APP and choose a simple app (Settings/Calculator/browser are good first tests).
5. Confirm the app renders live on LEFT.
6. CREATE RIGHT DISPLAY.
7. LAUNCH RIGHT APP and choose a different app.
8. Confirm LEFT / CENTRE / RIGHT are all still live and head anchoring remains smooth.

## What a successful test proves
If two different third-party apps render independently on LEFT and RIGHT while Centre stays the normal live Android capture, the device supports the core multi-display architecture needed for a real RayNeo spatial desktop.

## If Android blocks launch
Leave the app running and report the exact `LAB:` error text. Display creation has already been proven; a launch-only failure means the next route is privileged task/display control (for example ADB/Shizuku), not a tracking rewrite.

## Public release
Keep v0.8 as the public beta. This remains a development/lab build until independent app launch is hardware-proven.
