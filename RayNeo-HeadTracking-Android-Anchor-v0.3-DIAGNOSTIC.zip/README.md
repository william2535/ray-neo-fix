# RayNeo Head Tracker v0.3

Experimental diagnostic 3DoF Anchor build.

Adds display enumeration, live IMU pose, MediaProjection state, captured-frame count, calculated anchor X/Y, an on-glasses ANCHOR TEST marker, and a TEST MOVE button.

# RayNeo Head Tracker for Android

Native Android port of the **working RayNeo Air 4 Pro Termux head tracker**.

The aim of this repository is simple: plug the RayNeo Air 4 Pro into the Android handheld, read its IMU directly over USB, and turn head movement into a system mouse through `/dev/uinput` so it can be used in apps such as Shadow PC.

## Proven hardware/protocol baseline

The Android implementation preserves the values that worked on the actual glasses:

- RayNeo USB VID/PID: `0x1BBB / 0xAF50`
- Interrupt IN endpoint: `0x81`
- Poll/enable payload: `66 01`
- Control transfer: request type `0x21`, request `0x09`, value `0x0301`, index `0`
- Sensor frame begins `99 65 40 00`
- 7 little-endian float32 values begin at byte offset 4
- Gyro X: offset 16
- Gyro Y: offset 20
- Gyro Z: offset 24
- Temperature: offset 28
- Pitch rate: `gyroX`
- Yaw rate: `gyroY + gyroZ`
- Roll rate: `gyroY - gyroZ`
- Deadzone default: `2.0 deg/s`
- Smoothing default: `0.35`
- Mouse sensitivity default: `25 px/deg`
- 2-second stationary startup calibration
- Fractional/sub-pixel mouse carry retained for slow movement

The original proven Python files are kept under `reference/` so Android behavior can always be compared against the working Termux implementation.

## What the APK does

- Detects the RayNeo glasses over Android USB Host.
- Requests USB permission.
- Runs tracking in a foreground service so it can stay active while Shadow is in front.
- Claims the endpoint and actively polls each sensor frame.
- Calibrates gyro bias for two seconds.
- Displays pitch, yaw, roll, temperature and frame count.
- Provides sensitivity, deadzone, smoothing, X/Y invert, recenter and recalibrate controls.
- Uses a tiny JNI native module to create `RayNeo Head Mouse` through `/dev/uinput`.

## Build an APK on GitHub — no PC required

This repo includes `.github/workflows/build-apk.yml`.

After these files are placed on the `main` branch, GitHub Actions automatically builds the app. Open **Actions → Build RayNeo APK**, open the completed run, then download the artifact named **RayNeo-Head-Tracker-APK**. Inside it is `RayNeo-Head-Tracker-debug.apk`.

## First hardware test

1. Install the APK on the Android handheld.
2. Plug in RayNeo Air 4 Pro.
3. Open **RayNeo Head Tracker**.
4. Press **START** and approve USB access.
5. Keep the glasses completely still for about two seconds.
6. Check that pitch/yaw/roll and the frame counter update.
7. Check whether the status says `Tracking → virtual mouse`.
8. Open Shadow and test head-controlled mouse movement.

## Important first-test caveat

The Termux version has already proven that `/dev/uinput` is writable without root on this handheld. A standalone APK can still receive a different SELinux policy. If the app reports that `/dev/uinput` failed, that does **not** automatically mean the USB/IMU port failed. The app reports the error so that the first device test tells us exactly which layer needs changing.

Built from the RayNeo Air 4 Pro protocol work completed 29–30 August 2026.

## v0.2 experimental 3DoF Anchor mode

This build keeps the proven head-mouse mode and adds an experimental `3DoF ANCHOR SCREEN` mode.

How it works:
1. Start normal RayNeo tracking and complete calibration.
2. Tap `3DoF ANCHOR SCREEN`.
3. Tap `START ANCHOR` and approve Android screen-capture permission.
4. Tap `PIN HERE` while looking at the direction where you want the virtual screen fixed.
5. Head yaw/pitch counter-moves the captured screen on the external RayNeo presentation display.

The anchor path uses Android `MediaProjection` + a secondary `Presentation` display. The Android device therefore needs to expose the RayNeo as a separate presentation/external display. If the device only performs hardware display mirroring and does not expose a second display, the app reports that instead of starting a recursive capture.

This is 3DoF rotation anchoring only. It does not yet use camera-based position tracking (6DoF).
