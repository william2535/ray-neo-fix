package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/**
 * RayNeo 3DoF anchor diagnostic build v0.3.
 *
 * This build deliberately exposes every stage of the pipeline:
 *  - detected Android displays
 *  - live IMU pose arriving from TrackingService
 *  - presentation creation
 *  - TextureView surface readiness
 *  - MediaProjection/VirtualDisplay creation
 *  - captured frame counter
 *  - calculated anchor X/Y transform
 *  - TEST MOVE, which shifts the output without using the IMU
 */
public class AnchorActivity extends Activity {
    private static final int REQ_CAPTURE = 4401;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private AnchorPresentation presentation;

    private TextView status, displayInfo, poseInfo, renderInfo;

    private float screenScale = 0.78f;
    private float hFovDeg = 46.0f;
    private float vFovDeg = 27.0f;
    private float anchorPitch = 0f, anchorYaw = 0f;
    private float filteredPitch = 0f, filteredYaw = 0f;
    private boolean havePose = false;
    private boolean surfaceReady = false;
    private boolean virtualDisplayReady = false;
    private long capturedFrames = 0;
    private float testOffsetX = 0f;
    private boolean testMoved = false;

    private final BroadcastReceiver poseReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TrackingService.ACTION_STATUS.equals(intent.getAction())) return;
            float pitch = (float) intent.getDoubleExtra("pitch", 0.0);
            float yaw = (float) intent.getDoubleExtra("yaw", 0.0);

            if (!havePose) {
                anchorPitch = pitch;
                anchorYaw = yaw;
                filteredPitch = pitch;
                filteredYaw = yaw;
                havePose = true;
            }

            filteredPitch += (pitch - filteredPitch) * 0.35f;
            filteredYaw += (yaw - filteredYaw) * 0.35f;
            updatePoseText();
            updateAnchorTransform();
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(poseReceiver, new IntentFilter(TrackingService.ACTION_STATUS));
        buildUi();
        refreshDisplayInfo();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 32);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("RAYNEO 3DoF ANCHOR • v0.3");
        title.setTextSize(25);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Diagnostic anchor build. Keep normal Head Tracking running. This page now shows whether Android sees the glasses as a separate display, whether IMU pose is arriving, whether capture frames arrive, and the exact X/Y anchor movement.");
        help.setTextSize(13);
        help.setPadding(0, 8, 0, 14);
        root.addView(help);

        status = box(root, "Ready • checking displays…", 0xffe4e7e0, Color.BLACK);
        displayInfo = box(root, "DISPLAY DIAGNOSTICS", 0xff20242a, 0xffd8e2ef);
        poseInfo = box(root, "IMU: waiting for TrackingService…", 0xff16241c, 0xff77e49e);
        renderInfo = box(root, "RENDER: not started", 0xff242024, 0xffffd27a);

        Button refresh = button("REFRESH DISPLAYS", 0xff59645b);
        root.addView(refresh, fullButtonLp());

        TextView scaleLabel = new TextView(this);
        scaleLabel.setText("Virtual screen size");
        scaleLabel.setPadding(0, 16, 0, 0);
        root.addView(scaleLabel);

        SeekBar scale = new SeekBar(this);
        scale.setMax(90);
        scale.setProgress(62);
        root.addView(scale);
        screenScale = 0.30f + 0.70f * (scale.getProgress() / 90f);
        scale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                screenScale = 0.30f + 0.70f * (progress / 90f);
                updateAnchorTransform();
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 14, 0, 0);
        Button capture = button("START ANCHOR", 0xff2f7d4a);
        Button recenter = button("PIN HERE", 0xff59645b);
        row.addView(capture, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(recenter, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        Button testMove = button("TEST MOVE ↔", 0xff775b9b);
        root.addView(testMove, fullButtonLp());

        Button stop = button("STOP ANCHOR", 0xffa43f35);
        root.addView(stop, fullButtonLp());

        TextView note = new TextView(this);
        note.setText("TEST MOVE does not use the gyro. If it visibly moves the ANCHOR TEST marker on the glasses, Android presentation rendering is working. If live PITCH/YAW changes here, IMU delivery is working. CAPTURE FRAMES > 0 proves MediaProjection is feeding the output.");
        note.setTextSize(13);
        note.setPadding(0, 18, 0, 0);
        root.addView(note);

        refresh.setOnClickListener(v -> refreshDisplayInfo());
        capture.setOnClickListener(v -> requestCapture());
        recenter.setOnClickListener(v -> pinHere());
        testMove.setOnClickListener(v -> {
            testMoved = !testMoved;
            testOffsetX = testMoved ? 220f : -220f;
            updateAnchorTransform();
            status.setText("TEST MOVE applied: " + (int)testOffsetX + " px. Watch the RayNeo display.");
        });
        stop.setOnClickListener(v -> stopAnchor());

        setContentView(scroll);
    }

    private TextView box(LinearLayout root, String text, int bg, int fg) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(13);
        v.setTypeface(Typeface.MONOSPACE);
        v.setTextColor(fg);
        v.setBackgroundColor(bg);
        v.setPadding(12, 12, 12, 12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 0);
        root.addView(v, lp);
        return v;
    }

    private LinearLayout.LayoutParams fullButtonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 0);
        return lp;
    }

    private Button button(String text, int colour) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(colour);
        return b;
    }

    private void refreshDisplayInfo() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        StringBuilder s = new StringBuilder();
        Display[] all = dm.getDisplays();
        Display[] pres = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        s.append("ALL DISPLAYS: ").append(all == null ? 0 : all.length)
         .append("   PRESENTATION: ").append(pres == null ? 0 : pres.length).append('\n');
        if (all != null) {
            for (Display d : all) {
                DisplayMetrics m = new DisplayMetrics();
                d.getRealMetrics(m);
                s.append("ID ").append(d.getDisplayId())
                 .append(d.getDisplayId() == Display.DEFAULT_DISPLAY ? " [DEFAULT]" : "")
                 .append("\n  ").append(d.getName())
                 .append("\n  ").append(m.widthPixels).append('x').append(m.heightPixels)
                 .append("  state=").append(d.getState())
                 .append("  flags=0x").append(Integer.toHexString(d.getFlags()))
                 .append('\n');
            }
        }
        Display target = findExternalDisplay();
        if (target != null) s.append("TARGET → ID ").append(target.getDisplayId()).append(" ").append(target.getName());
        else s.append("TARGET → NONE");
        displayInfo.setText(s.toString());
    }

    private void updatePoseText() {
        if (poseInfo == null) return;
        poseInfo.setText(String.format(Locale.UK,
                "IMU LIVE\nPITCH %+8.2f°\nYAW   %+8.2f°\nPIN P %+8.2f°\nPIN Y %+8.2f°",
                filteredPitch, filteredYaw, anchorPitch, anchorYaw));
    }

    private void updateRenderText(float dx, float dy) {
        if (renderInfo == null) return;
        renderInfo.setText(String.format(Locale.UK,
                "RENDER\npresentation=%s  surface=%s\nvirtualDisplay=%s  captureFrames=%d\nX %+7.1f px   Y %+7.1f px\nscale %.2f",
                presentation != null ? "YES" : "NO",
                surfaceReady ? "YES" : "NO",
                virtualDisplayReady ? "YES" : "NO",
                capturedFrames, dx, dy, screenScale));
    }

    private void requestCapture() {
        refreshDisplayInfo();
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("NO TARGET DISPLAY. Android is not exposing the RayNeo as a separate display, so this Presentation method cannot control it.");
            return;
        }
        status.setText("Target display found: " + target.getName() + " • requesting screen capture permission…");
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Screen capture permission cancelled");
            return;
        }
        projection = projectionManager.getMediaProjection(resultCode, data);
        if (projection == null) {
            status.setText("MediaProjection returned NULL");
            return;
        }
        projection.registerCallback(new MediaProjection.Callback() {
            @Override public void onStop() {
                runOnUiThread(() -> {
                    virtualDisplayReady = false;
                    status.setText("MediaProjection STOPPED by Android");
                    updateRenderText(0, 0);
                });
            }
        }, new Handler(Looper.getMainLooper()));
        startPresentationAndCapture();
    }

    private Display findExternalDisplay() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display[] displays = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if (displays != null && displays.length > 0) {
            for (Display d : displays) if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
            return displays[0];
        }
        for (Display d : dm.getDisplays()) if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
        return null;
    }

    private void startPresentationAndCapture() {
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("External display disappeared before Presentation opened");
            stopAnchor();
            return;
        }

        try {
            presentation = new AnchorPresentation(this, target);
            presentation.setOnDismissListener(dialog -> stopVirtualDisplayOnly());
            presentation.show();
        } catch (Throwable t) {
            status.setText("PRESENTATION FAILED: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            stopAnchor();
            return;
        }

        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
                surfaceReady = true;
                status.setText("Presentation + Texture surface ready • starting capture…");
                startVirtualDisplay(st);
                updateAnchorTransform();
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                surfaceReady = false;
                stopVirtualDisplayOnly();
                updateRenderText(0, 0);
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {
                capturedFrames++;
                if ((capturedFrames % 15) == 0) updateAnchorTransform();
            }
        });

        if (presentation.texture.isAvailable()) {
            surfaceReady = true;
            startVirtualDisplay(presentation.texture.getSurfaceTexture());
        }

        pinHere();
        status.setText("Presentation opened on " + target.getName() + ". Look for the ANCHOR TEST label on the glasses.");
        updateAnchorTransform();
    }

    private void startVirtualDisplay(SurfaceTexture st) {
        stopVirtualDisplayOnly();
        if (projection == null || st == null || presentation == null) {
            status.setText("Capture start blocked: missing projection/surface/presentation");
            return;
        }

        DisplayMetrics m = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(m);
        int width = Math.max(640, m.widthPixels);
        int height = Math.max(360, m.heightPixels);
        int density = Math.max(160, m.densityDpi);
        st.setDefaultBufferSize(width, height);
        Surface surface = new Surface(st);

        try {
            virtualDisplay = projection.createVirtualDisplay(
                    "RayNeoAnchorCapture", width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    surface, null, null);
            virtualDisplayReady = virtualDisplay != null;
            if (virtualDisplayReady) status.setText("CAPTURE CREATED • waiting for frames. Try TEST MOVE and turn your head.");
            else status.setText("createVirtualDisplay returned NULL");
        } catch (Throwable t) {
            virtualDisplayReady = false;
            status.setText("CAPTURE FAILED: " + t.getClass().getSimpleName() + ": " + t.getMessage());
        }
        updateAnchorTransform();
    }

    private void pinHere() {
        if (havePose) {
            anchorPitch = filteredPitch;
            anchorYaw = filteredYaw;
            status.setText("Pinned at current IMU pose • turn your head");
        } else {
            anchorPitch = anchorYaw = 0f;
            status.setText("PIN requested but NO IMU POSE has arrived yet. Start tracking on the main page first.");
        }
        testOffsetX = 0f;
        testMoved = false;
        updatePoseText();
        updateAnchorTransform();
    }

    private void updateAnchorTransform() {
        if (presentation == null || presentation.mover == null) {
            updateRenderText(0, 0);
            return;
        }
        View mover = presentation.mover;
        int w = presentation.root != null ? presentation.root.getWidth() : mover.getWidth();
        int h = presentation.root != null ? presentation.root.getHeight() : mover.getHeight();
        if (w <= 0 || h <= 0) {
            updateRenderText(0, 0);
            return;
        }

        float yaw = filteredYaw - anchorYaw;
        float pitch = filteredPitch - anchorPitch;
        float dx = -(yaw / hFovDeg) * w + testOffsetX;
        float dy = +(pitch / vFovDeg) * h;

        mover.setPivotX(w / 2f);
        mover.setPivotY(h / 2f);
        mover.setScaleX(screenScale);
        mover.setScaleY(screenScale);
        mover.setTranslationX(dx);
        mover.setTranslationY(dy);

        if (presentation.marker != null) {
            presentation.marker.setText(String.format(Locale.UK,
                    "ANCHOR TEST\nP %+.1f  Y %+.1f\nX %+.0f  Y %+.0f\nframes %d",
                    pitch, yaw, dx, dy, capturedFrames));
        }
        updateRenderText(dx, dy);
    }

    private void stopVirtualDisplayOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Throwable ignored) {}
            virtualDisplay = null;
        }
        virtualDisplayReady = false;
    }

    private void stopAnchor() {
        stopVirtualDisplayOnly();
        if (presentation != null) {
            AnchorPresentation p = presentation;
            presentation = null;
            try { p.setOnDismissListener(null); p.dismiss(); } catch (Throwable ignored) {}
        }
        if (projection != null) {
            MediaProjection p = projection;
            projection = null;
            try { p.stop(); } catch (Throwable ignored) {}
        }
        surfaceReady = false;
        capturedFrames = 0;
        testOffsetX = 0f;
        if (status != null) status.setText("Anchor stopped");
        updateRenderText(0, 0);
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(poseReceiver); } catch (Throwable ignored) {}
        stopAnchor();
        super.onDestroy();
    }

    private static class AnchorPresentation extends Presentation {
        FrameLayout root;
        FrameLayout mover;
        TextureView texture;
        TextView marker;

        AnchorPresentation(Context outerContext, Display display) {
            super(outerContext, display);
        }

        @Override protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            getWindow().setBackgroundDrawableResource(android.R.color.black);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            root = new FrameLayout(getContext());
            root.setBackgroundColor(Color.BLACK);

            mover = new FrameLayout(getContext());
            mover.setBackgroundColor(Color.BLACK);
            FrameLayout.LayoutParams fill = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
            root.addView(mover, fill);

            texture = new TextureView(getContext());
            texture.setOpaque(true);
            mover.addView(texture, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

            marker = new TextView(getContext());
            marker.setText("ANCHOR TEST\nwaiting…");
            marker.setTextColor(Color.WHITE);
            marker.setTextSize(18);
            marker.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
            marker.setGravity(Gravity.CENTER);
            marker.setPadding(20, 12, 20, 12);
            marker.setBackgroundColor(0xaa6b3fa0);
            FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
            mover.addView(marker, mlp);

            setContentView(root);
        }
    }
}
