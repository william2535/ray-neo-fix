package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import java.nio.*;
import java.util.*;

public class TrackingService extends Service {
    public static final String ACTION_START = "com.willflood.rayneo.START";
    public static final String ACTION_STOP = "com.willflood.rayneo.STOP";
    public static final String ACTION_RECENTER = "com.willflood.rayneo.RECENTER";
    public static final String ACTION_RECALIBRATE = "com.willflood.rayneo.RECALIBRATE";
    public static final String ACTION_CONFIG = "com.willflood.rayneo.CONFIG";
    public static final String ACTION_STATUS = "com.willflood.rayneo.STATUS";

    private static final int VID=0x1BBB, PID=0xAF50;
    private static final byte[] ENABLE=new byte[]{0x66,0x01};
    private volatile boolean running=false, recalibrate=false;
    private Thread worker;
    private UsbDeviceConnection conn;
    private UsbRequest request;
    private UsbInterface intf;
    private UsbEndpoint inEp;
    private int mouseFd=-1;
    private final Tracker tracker=new Tracker();
    private volatile double sens=25.0;
    private volatile boolean invertX=false, invertY=false, mouseEnabled=true;
    private double carryX=0, carryY=0;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        startForeground(7, makeNotification("Waiting for RayNeo"));
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RayNeo:Tracking");
        wakeLock.acquire();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent==null) return START_STICKY;
        String a=intent.getAction();
        if (ACTION_STOP.equals(a)) { stopTracking(); return START_NOT_STICKY; }
        if (ACTION_RECENTER.equals(a)) { tracker.recentre(); carryX=carryY=0; sendStatus("Recentred",0,0,0,0,0); return START_STICKY; }
        if (ACTION_RECALIBRATE.equals(a)) { recalibrate=true; return START_STICKY; }
        if (ACTION_CONFIG.equals(a) || ACTION_START.equals(a)) applyConfig(intent);
        if (ACTION_START.equals(a) && !running) startTracking();
        return START_STICKY;
    }

    private void applyConfig(Intent i) {
        sens=i.getDoubleExtra("sens",sens);
        tracker.deadzone=i.getDoubleExtra("deadzone",tracker.deadzone);
        tracker.smooth=i.getDoubleExtra("smooth",tracker.smooth);
        invertX=i.getBooleanExtra("invertX",invertX);
        invertY=i.getBooleanExtra("invertY",invertY);
        mouseEnabled=i.getBooleanExtra("mouse",mouseEnabled);
    }

    private void startTracking() {
        running=true;
        worker=new Thread(this::runLoop,"RayNeo-IMU");
        worker.start();
    }

    private UsbDevice findDevice(UsbManager um) {
        for (UsbDevice d: um.getDeviceList().values())
            if (d.getVendorId()==VID && d.getProductId()==PID) return d;
        return null;
    }

    private void runLoop() {
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE);
        UsbDevice dev=findDevice(um);
        if (dev==null) { fail("RayNeo not connected"); return; }
        if (!um.hasPermission(dev)) { fail("USB permission missing - reopen app and press Start"); return; }

        conn=um.openDevice(dev);
        if (conn==null) { fail("Could not open RayNeo USB device"); return; }
        intf=null; inEp=null;
        for (int i=0;i<dev.getInterfaceCount();i++) {
            UsbInterface ui=dev.getInterface(i);
            for (int e=0;e<ui.getEndpointCount();e++) {
                UsbEndpoint ep=ui.getEndpoint(e);
                if (ep.getAddress()==0x81) { intf=ui; inEp=ep; break; }
            }
            if (inEp!=null) break;
        }
        if (intf==null || inEp==null) { fail("Could not find HID endpoint 0x81"); cleanupUsb(); return; }
        if (!conn.claimInterface(intf,true)) { fail("Could not claim RayNeo interface"); cleanupUsb(); return; }
        request=new UsbRequest();
        if (!request.initialize(conn,inEp)) { fail("Could not initialise interrupt endpoint"); cleanupUsb(); return; }

        if (mouseEnabled) openMouse();

        sendStatus("Calibrating - keep glasses still",0,0,0,0,0);
        double spread=calibrateFor(2.0);
        if (!running) return;
        sendStatus(String.format(Locale.UK,"Tracking • calibration spread %.2f",spread),0,0,0,0,0);
        updateNotification("Head tracking active");

        long last=System.nanoTime();
        long lastUi=0;
        long frames=0;
        while (running) {
            if (recalibrate) {
                recalibrate=false;
                sendStatus("Recalibrating - keep glasses still",0,0,0,0,frames);
                spread=calibrateFor(2.0);
                tracker.recentre(); carryX=carryY=0;
                last=System.nanoTime();
                sendStatus(String.format(Locale.UK,"Tracking • calibration spread %.2f",spread),0,0,0,0,frames);
                continue;
            }
            ByteBuffer frame=pollFrame();
            if (frame==null) continue;
            long now=System.nanoTime();
            double dt=(now-last)/1_000_000_000.0;
            last=now;
            if (dt<=0 || dt>0.5) continue;
            double[] rates=decodeRates(frame);
            float temp=frame.order(ByteOrder.LITTLE_ENDIAN).getFloat(28);
            double[][] ar=tracker.update(rates,dt);
            double[] angle=ar[0], rate=ar[1];
            frames++;

            if (mouseEnabled && mouseFd>=0) {
                double sx=invertX ? -1.0 : 1.0;
                double sy=invertY ? -1.0 : 1.0;
                carryX += -sx * rate[1] * dt * sens;
                carryY += -sy * rate[0] * dt * sens;
                int dx=(int)carryX, dy=(int)carryY;
                carryX-=dx; carryY-=dy;
                if (dx!=0 || dy!=0) NativeUInput.moveMouse(mouseFd,dx,dy);
            }
            if (now-lastUi>100_000_000L) {
                lastUi=now;
                sendStatus(mouseEnabled && mouseFd>=0 ? "Tracking → virtual mouse" : "Tracking → angles",
                        angle[0],angle[1],angle[2],temp,frames);
            }
        }
        cleanupAll();
    }

    private double calibrateFor(double seconds) {
        ArrayList<double[]> samples=new ArrayList<>();
        long end=System.nanoTime()+(long)(seconds*1_000_000_000L);
        while (running && System.nanoTime()<end) {
            ByteBuffer f=pollFrame();
            if (f!=null) samples.add(decodeRates(f));
        }
        return tracker.calibrate(samples);
    }

    private ByteBuffer pollFrame() {
        if (conn==null || request==null) return null;
        int rc=conn.controlTransfer(0x21,0x09,0x0301,0,ENABLE,2,600);
        if (rc<0) return null;
        ByteBuffer b=ByteBuffer.allocateDirect(64);
        b.order(ByteOrder.LITTLE_ENDIAN);
        if (!request.queue(b)) return null;
        UsbRequest done;
        try { done=conn.requestWait(100); }
        catch (Exception e) { return null; }
        if (done!=request) return null;
        int n=b.position();
        if (n<32) return null;
        if ((b.get(0)&0xff)!=0x99 || (b.get(1)&0xff)!=0x65) return null;
        return b;
    }

    private double[] decodeRates(ByteBuffer f) {
        f.order(ByteOrder.LITTLE_ENDIAN);
        double gx=f.getFloat(16), gy=f.getFloat(20), gz=f.getFloat(24);
        return new double[]{gx,gy+gz,gy-gz};
    }

    private void openMouse() {
        if (mouseFd>=0) return;
        try { mouseFd=NativeUInput.openMouse(); }
        catch (Throwable t) { mouseFd=-99999; }
        if (mouseFd<0) sendStatus("IMU works, but /dev/uinput mouse failed: "+mouseFd,0,0,0,0,0);
        else SystemClock.sleep(300);
    }

    private void sendStatus(String text,double pitch,double yaw,double roll,double temp,long frames) {
        Intent i=new Intent(ACTION_STATUS).setPackage(getPackageName());
        i.putExtra("text",text); i.putExtra("pitch",pitch); i.putExtra("yaw",yaw);
        i.putExtra("roll",roll); i.putExtra("temp",temp); i.putExtra("frames",frames);
        sendBroadcast(i);
    }

    private void fail(String s) {
        sendStatus(s,0,0,0,0,0);
        updateNotification(s);
        running=false;
    }

    private void stopTracking() {
        running=false;
        cleanupAll();
        stopForeground(true);
        stopSelf();
    }

    private synchronized void cleanupUsb() {
        try { if (request!=null) request.close(); } catch(Exception ignored) {}
        request=null;
        try { if (conn!=null && intf!=null) conn.releaseInterface(intf); } catch(Exception ignored) {}
        try { if (conn!=null) conn.close(); } catch(Exception ignored) {}
        conn=null; intf=null; inEp=null;
    }

    private synchronized void cleanupAll() {
        if (mouseFd>=0) { try { NativeUInput.closeMouse(mouseFd); } catch(Throwable ignored) {} }
        mouseFd=-1;
        cleanupUsb();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel("tracking","RayNeo head tracking",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification makeNotification(String text) {
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        return new Notification.Builder(this,"tracking").setContentTitle("RayNeo Head Tracker")
                .setContentText(text).setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).setOngoing(true).build();
    }
    private void updateNotification(String text) { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,makeNotification(text)); }

    @Override public void onDestroy() {
        running=false; cleanupAll();
        if (wakeLock!=null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
