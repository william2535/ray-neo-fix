# RayNeo Spatial v0.9.4 — Input + Position LAB

Experimental follow-up to the working v0.9.3.3 isolated-Shizuku build.

## What stays known-good
- RayNeo Air 4 Pro USB IMU path and 3DoF tracker remain the same.
- LEFT/RIGHT app-owned VirtualDisplays remain manual and independent.
- Shizuku remains isolated in the separate `:shizuku` Android process.
- POSITION tracking is OFF by default.

## New experiment 1 — manual display control
After Shizuku is connected and apps are launched:
1. `CONTROL LEFT`, `CONTROL CENTRE`, or `CONTROL RIGHT` chooses the input target.
2. LEFT/RIGHT temporarily disable the normal centre `/dev/uinput` mouse.
3. Head-angle changes are converted to an absolute cursor position on that selected VirtualDisplay.
4. A persistent Shizuku-backed shell injects `input mouse -d <displayId> motionevent MOVE x y` at up to ~30 Hz.
5. `CLICK SELECTED` sends a mouse-source tap to the tracked cursor position.
6. `BACK SELECTED` targets Android BACK at that display.
7. `CONTROL CENTRE` restores the original `/dev/uinput` head mouse.

This is deliberately manual first. If display-targeted input proves reliable, automatic look-to-select/cross-screen routing can come next.

## New experiment 2 — accelerometer POSITION LAB
The existing sensor packet already contains accel X/Y/Z at offsets 4/8/12. v0.9.4 publishes those values alongside the proven gyro pose without changing Tracker math.

The Anchor UI now shows:
- raw accel X/Y/Z
- high-pass-ish linear X/Y/Z after a slow gravity estimate
- experimental depth/vertical integrated state
- selectable depth and vertical axes
- invert toggles
- strength controls
- `POSITION RECENTER`

When `POSITION TRACKING ON` is enabled, short acceleration impulses are double-integrated with strong velocity damping and slow positional recentring. Depth changes panel scale; the vertical channel adds a Y position offset. It is intentionally constrained and is **not true absolute 6DoF**.

## Test order
1. Start Shizuku and leave it running in the background.
2. Start RayNeo tracking and confirm it is smooth.
3. Start Spatial Desktop and PIN normally.
4. CONNECT SHIZUKU.
5. CREATE LEFT/RIGHT displays and launch two apps.
6. Leave POSITION OFF.
7. Test CONTROL LEFT -> move head -> CLICK SELECTED.
8. Test CONTROL RIGHT.
9. Test CONTROL CENTRE and confirm normal centre mouse returns.
10. Only then enable POSITION TRACKING and test forward/back/up/down movement.
11. If depth goes the wrong way, use `Invert depth`; if the wrong accel axis responds, try X/Y/Z.

## Expected limitations
- Android/OEM builds may accept app launching to a VirtualDisplay but reject or partially support input injection on that display.
- Mouse pointer visibility on a VirtualDisplay is device-dependent. `CLICK SELECTED` still tests whether the stored coordinates can activate the app.
- Accelerometer-only position drifts. This build uses damping/recentring for a lean/translation effect, not room-scale tracking.
- Do not replace the public v0.8 beta with this LAB build yet.
