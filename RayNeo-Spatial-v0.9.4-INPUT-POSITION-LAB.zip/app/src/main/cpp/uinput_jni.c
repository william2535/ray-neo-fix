#include <jni.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <stdio.h>
#include <sys/ioctl.h>
#include <linux/uinput.h>
#include <linux/input.h>

JNIEXPORT jint JNICALL
Java_com_willflood_rayneo_NativeUInput_openMouse(JNIEnv *env, jclass cls) {
    (void)env; (void)cls;
    int fd=open("/dev/uinput",O_WRONLY|O_NONBLOCK);
    if(fd<0) return -errno;
    if(ioctl(fd,UI_SET_EVBIT,EV_KEY)<0 || ioctl(fd,UI_SET_EVBIT,EV_REL)<0 || ioctl(fd,UI_SET_EVBIT,EV_SYN)<0 ||
       ioctl(fd,UI_SET_RELBIT,REL_X)<0 || ioctl(fd,UI_SET_RELBIT,REL_Y)<0 || ioctl(fd,UI_SET_RELBIT,REL_WHEEL)<0 ||
       ioctl(fd,UI_SET_KEYBIT,BTN_LEFT)<0 || ioctl(fd,UI_SET_KEYBIT,BTN_RIGHT)<0 || ioctl(fd,UI_SET_KEYBIT,BTN_MIDDLE)<0) {
        int e=errno; close(fd); return -1000-e;
    }
    struct uinput_user_dev uidev;
    memset(&uidev,0,sizeof(uidev));
    snprintf(uidev.name,UINPUT_MAX_NAME_SIZE,"RayNeo Head Mouse");
    uidev.id.bustype=BUS_USB;
    uidev.id.vendor=0x1BBB;
    uidev.id.product=0xAF51;
    uidev.id.version=1;
    if(write(fd,&uidev,sizeof(uidev))!=(ssize_t)sizeof(uidev)) { int e=errno; close(fd); return -2000-e; }
    if(ioctl(fd,UI_DEV_CREATE)<0) { int e=errno; close(fd); return -3000-e; }
    return fd;
}

static int emit(int fd,unsigned short type,unsigned short code,int value) {
    struct input_event ev; memset(&ev,0,sizeof(ev)); ev.type=type; ev.code=code; ev.value=value;
    return write(fd,&ev,sizeof(ev))==(ssize_t)sizeof(ev)?0:-errno;
}

JNIEXPORT jint JNICALL
Java_com_willflood_rayneo_NativeUInput_moveMouse(JNIEnv *env,jclass cls,jint fd,jint dx,jint dy) {
    (void)env; (void)cls;
    if(fd<0) return -1;
    if(dx) emit(fd,EV_REL,REL_X,dx);
    if(dy) emit(fd,EV_REL,REL_Y,dy);
    if(dx||dy) emit(fd,EV_SYN,SYN_REPORT,0);
    return 0;
}

JNIEXPORT void JNICALL
Java_com_willflood_rayneo_NativeUInput_closeMouse(JNIEnv *env,jclass cls,jint fd) {
    (void)env; (void)cls;
    if(fd>=0) { ioctl(fd,UI_DEV_DESTROY); close(fd); }
}
