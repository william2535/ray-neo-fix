package com.willflood.rayneo;

public final class NativeUInput {
    static {
        System.loadLibrary("uinputjni");
    }

    private NativeUInput() {}

    public static native int openMouse();
    public static native int moveMouse(int fd, int dx, int dy);
    public static native void closeMouse(int fd);
}
