package com.willflood.rayneo;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;

import rikka.shizuku.Shizuku;

/**
 * v0.9.3.3 isolation bridge.
 *
 * IMPORTANT: this Activity and ShizukuProvider both run in :shizuku, never in the
 * main RayNeo process. The proven v0.9.1 tracking/anchor process therefore does
 * not load or register Shizuku at all.
 */
public class ShizukuBridgeActivity extends Activity {
    public static final String ACTION_RESULT = "com.willflood.rayneo.SHIZUKU_BRIDGE_RESULT";
    public static final String EXTRA_MODE = "mode";
    public static final String MODE_CONNECT = "connect";
    public static final String MODE_LAUNCH = "launch";
    public static final String EXTRA_DISPLAY_ID = "display_id";
    public static final String EXTRA_COMPONENT = "component";
    public static final String EXTRA_SIDE = "side";
    public static final String EXTRA_RESULT = "result";
    public static final String EXTRA_OK = "ok";

    private static final int REQ_PERMISSION = 9331;
    private final Handler main = new Handler(Looper.getMainLooper());
    private boolean finished;

    private final Shizuku.OnBinderReceivedListener binderListener = () -> main.post(this::attempt);
    private final Shizuku.OnBinderDeadListener deadListener = () -> main.post(() -> fail("SHIZUKU STOPPED"));
    private final Shizuku.OnRequestPermissionResultListener permissionListener = (requestCode, grantResult) -> {
        if (requestCode != REQ_PERMISSION) return;
        main.post(() -> {
            if (grantResult == PackageManager.PERMISSION_GRANTED) attempt();
            else fail("SHIZUKU PERMISSION DENIED");
        });
    };

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        Shizuku.addBinderReceivedListenerSticky(binderListener);
        Shizuku.addBinderDeadListener(deadListener);
        Shizuku.addRequestPermissionResultListener(permissionListener);
        main.post(this::attempt);
    }

    private void attempt() {
        if (finished) return;
        try {
            if (!Shizuku.pingBinder()) {
                fail("SHIZUKU NOT READY — make sure Shizuku says Running, then retry");
                return;
            }
            if (Shizuku.isPreV11()) {
                fail("SHIZUKU TOO OLD — v11+ required");
                return;
            }
            if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED) {
                Shizuku.requestPermission(REQ_PERMISSION);
                return;
            }

            String mode = getIntent().getStringExtra(EXTRA_MODE);
            if (MODE_LAUNCH.equals(mode)) launch();
            else success("SHIZUKU READY — server uid=" + Shizuku.getUid());
        } catch (Throwable t) {
            fail(describe("bridge", t));
        }
    }

    private void launch() {
        final int displayId = getIntent().getIntExtra(EXTRA_DISPLAY_ID, -1);
        final String flat = getIntent().getStringExtra(EXTRA_COMPONENT);
        if (displayId < 0 || flat == null || ComponentName.unflattenFromString(flat) == null) {
            fail("BAD LAUNCH REQUEST — display/component missing");
            return;
        }
        new Thread(() -> {
            try {
                String result = runShizukuShell(new String[]{
                        "am", "start", "--display", Integer.toString(displayId), "-n", flat
                });
                main.post(() -> success(result));
            } catch (Throwable t) {
                main.post(() -> fail(describe("am start", t)));
            }
        }, "RayNeo-ShizukuBridge").start();
    }

    private String runShizukuShell(String[] command) throws Exception {
        // newProcess is private/deprecated in API 13.1.5; reflection keeps this LAB tiny.
        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        Object remote = m.invoke(null, command, null, null);
        if (remote == null) return "ERROR: Shizuku returned no process";
        Class<?> cls = remote.getClass();
        java.io.InputStream stdout = (java.io.InputStream) cls.getMethod("getInputStream").invoke(remote);
        java.io.InputStream stderr = (java.io.InputStream) cls.getMethod("getErrorStream").invoke(remote);
        String out = read(stdout);
        String err = read(stderr);
        int rc = ((Number) cls.getMethod("waitFor").invoke(remote)).intValue();
        try { cls.getMethod("destroy").invoke(remote); } catch (Throwable ignored) {}
        return "serverUid=" + Shizuku.getUid() + " rc=" + rc
                + (out.isEmpty() ? "" : "\n" + out)
                + (err.isEmpty() ? "" : "\nERR: " + err);
    }

    private String read(java.io.InputStream in) throws Exception {
        StringBuilder sb = new StringBuilder();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
            String line;
            while ((line = br.readLine()) != null) {
                if (sb.length() > 0) sb.append('\n');
                sb.append(line);
            }
        }
        return sb.toString();
    }

    private String describe(String stage, Throwable t) {
        String msg = t.getMessage();
        if (msg == null || msg.trim().isEmpty()) msg = "(no message)";
        return "ERROR at " + stage + "\n" + t.getClass().getName() + "\n" + msg;
    }

    private void success(String text) { send(true, text); }
    private void fail(String text) { send(false, text); }

    private void send(boolean ok, String text) {
        if (finished) return;
        finished = true;
        Intent result = new Intent(ACTION_RESULT).setPackage(getPackageName())
                .putExtra(EXTRA_OK, ok)
                .putExtra(EXTRA_RESULT, text)
                .putExtra(EXTRA_SIDE, getIntent().getStringExtra(EXTRA_SIDE));
        sendBroadcast(result);
        finish();
    }

    @Override protected void onDestroy() {
        try { Shizuku.removeBinderReceivedListener(binderListener); } catch (Throwable ignored) {}
        try { Shizuku.removeBinderDeadListener(deadListener); } catch (Throwable ignored) {}
        try { Shizuku.removeRequestPermissionResultListener(permissionListener); } catch (Throwable ignored) {}
        super.onDestroy();
    }
}
