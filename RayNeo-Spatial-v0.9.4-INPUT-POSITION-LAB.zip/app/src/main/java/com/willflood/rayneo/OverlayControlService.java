package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;

/**
 * Small draggable system overlay used while another Android app is in the foreground.
 * Snap commands hide the overlay briefly before asking AnchorActivity to grab the
 * current TextureView frame, then restore the overlay afterwards.
 */
public class OverlayControlService extends Service {
    private static final String CHANNEL_ID = "rayneo_anchor_controls";
    private WindowManager wm;
    private LinearLayout bar;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("RayNeo Spatial Controls")
                .setContentText("Floating Snap / Pin controls are active")
                .setOngoing(true)
                .build();
        startForeground(2208, n);
        showOverlay();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "RayNeo Spatial Controls", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the floating spatial desktop controls available over other apps");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private TextView control(String text) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextColor(Color.WHITE);
        v.setTextSize(15);
        v.setGravity(Gravity.CENTER);
        v.setPadding(18, 15, 18, 15);
        v.setBackgroundColor(0xdd263238);
        return v;
    }

    private void showOverlay() {
        if (bar != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(0xcc101417);
        bar.setPadding(4,4,4,4);

        TextView left = control("◀ SNAP");
        TextView pin = control("📌 PIN");
        TextView right = control("SNAP ▶");
        TextView close = control("×");
        bar.addView(left); bar.addView(pin); bar.addView(right); bar.addView(close);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.START;
        params.x = 20; params.y = 120;

        final float[] down = new float[4];
        pin.setOnTouchListener((v,e)->{
            switch(e.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    down[0]=e.getRawX(); down[1]=e.getRawY(); down[2]=params.x; down[3]=params.y; return false;
                case MotionEvent.ACTION_MOVE:
                    if(Math.abs(e.getRawX()-down[0])>12 || Math.abs(e.getRawY()-down[1])>12) {
                        params.x=(int)(down[2]+e.getRawX()-down[0]); params.y=(int)(down[3]+e.getRawY()-down[1]);
                        try{wm.updateViewLayout(bar,params);}catch(Throwable ignored){}
                        return true;
                    }
            }
            return false;
        });

        left.setOnClickListener(v -> snapshot(AnchorActivity.CMD_SNAP_LEFT));
        right.setOnClickListener(v -> snapshot(AnchorActivity.CMD_SNAP_RIGHT));
        pin.setOnClickListener(v -> send(AnchorActivity.CMD_PIN));
        close.setOnClickListener(v -> stopSelf());

        try { wm.addView(bar, params); }
        catch (Throwable t) { stopSelf(); }
    }

    private void snapshot(String command) {
        if (bar == null) return;
        bar.setVisibility(View.INVISIBLE);
        // Give SurfaceFlinger two-ish frames to remove the overlay from the captured image.
        handler.postDelayed(() -> send(command), 70);
        handler.postDelayed(() -> { if (bar != null) bar.setVisibility(View.VISIBLE); }, 260);
    }

    private void send(String command) {
        Intent i = new Intent(AnchorActivity.ACTION_OVERLAY)
                .setPackage(getPackageName())
                .putExtra(AnchorActivity.EXTRA_COMMAND, command);
        sendBroadcast(i);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) { return START_STICKY; }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (bar != null && wm != null) {
            try { wm.removeView(bar); } catch (Throwable ignored) {}
        }
        bar = null;
        stopForeground(true);
        super.onDestroy();
    }
}
