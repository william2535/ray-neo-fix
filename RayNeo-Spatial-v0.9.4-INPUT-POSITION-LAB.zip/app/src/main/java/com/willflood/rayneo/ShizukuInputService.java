package com.willflood.rayneo;

import android.app.Service;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.lang.reflect.Method;
import java.nio.charset.StandardCharsets;

import rikka.shizuku.Shizuku;

/**
 * v0.9.4 input LAB.
 *
 * Runs ONLY in :shizuku. The main RayNeo process talks to it through Messenger.
 * A single Shizuku-backed interactive shell is kept open so head-mouse moves do
 * not create a new privileged process for every frame.
 */
public class ShizukuInputService extends Service {
    public static final int MSG_INIT = 1;
    public static final int MSG_MOVE = 2;
    public static final int MSG_CLICK = 3;
    public static final int MSG_BACK = 4;
    public static final int MSG_CLOSE = 5;
    public static final int MSG_STATUS = 100;

    public static final String KEY_DISPLAY = "display";
    public static final String KEY_X = "x";
    public static final String KEY_Y = "y";
    public static final String KEY_TEXT = "text";
    public static final String KEY_OK = "ok";

    private final Handler handler = new Handler(Looper.getMainLooper(), this::handleMessage);
    private final Messenger messenger = new Messenger(handler);

    private Object remoteShell;
    private OutputStream shellIn;
    private Messenger replyTo;
    private volatile boolean shellReady;

    @Override public IBinder onBind(Intent intent) {
        return messenger.getBinder();
    }

    private boolean handleMessage(Message msg) {
        if (msg.replyTo != null) replyTo = msg.replyTo;
        try {
            switch (msg.what) {
                case MSG_INIT:
                    ensureShell();
                    status(true, "INPUT BRIDGE READY — shell uid=" + Shizuku.getUid());
                    return true;
                case MSG_MOVE: {
                    ensureShell();
                    Bundle b = msg.getData();
                    int display = b.getInt(KEY_DISPLAY, -1);
                    int x = b.getInt(KEY_X, 0);
                    int y = b.getInt(KEY_Y, 0);
                    if (display < 0) throw new IllegalArgumentException("display id missing");
                    writeCommand("input mouse -d " + display + " motionevent MOVE " + x + " " + y);
                    return true;
                }
                case MSG_CLICK: {
                    ensureShell();
                    Bundle b = msg.getData();
                    int display = b.getInt(KEY_DISPLAY, -1);
                    int x = b.getInt(KEY_X, 0);
                    int y = b.getInt(KEY_Y, 0);
                    if (display < 0) throw new IllegalArgumentException("display id missing");
                    // Use a mouse-source tap at our tracked cursor position.
                    writeCommand("input mouse -d " + display + " tap " + x + " " + y);
                    status(true, "CLICK sent to display " + display + " @ " + x + "," + y);
                    return true;
                }
                case MSG_BACK: {
                    ensureShell();
                    int display = msg.getData().getInt(KEY_DISPLAY, -1);
                    if (display < 0) throw new IllegalArgumentException("display id missing");
                    writeCommand("input keyboard -d " + display + " keyevent KEYCODE_BACK");
                    status(true, "BACK sent to display " + display);
                    return true;
                }
                case MSG_CLOSE:
                    closeShell();
                    status(true, "INPUT BRIDGE CLOSED");
                    return true;
                default:
                    return false;
            }
        } catch (Throwable t) {
            status(false, describe(t));
            return true;
        }
    }

    private synchronized void ensureShell() throws Exception {
        if (shellReady && shellIn != null && remoteShell != null) return;
        if (!Shizuku.pingBinder()) throw new IllegalStateException("Shizuku is not running");
        if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED)
            throw new SecurityException("Shizuku permission not granted — press CONNECT SHIZUKU first");

        Method m = Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        remoteShell = m.invoke(null, new String[]{"sh"}, null, null);
        if (remoteShell == null) throw new IllegalStateException("Shizuku returned no shell process");
        Class<?> cls = remoteShell.getClass();
        shellIn = (OutputStream) cls.getMethod("getOutputStream").invoke(remoteShell);
        java.io.InputStream stdout = (java.io.InputStream) cls.getMethod("getInputStream").invoke(remoteShell);
        java.io.InputStream stderr = (java.io.InputStream) cls.getMethod("getErrorStream").invoke(remoteShell);
        drain(stdout, "RayNeoInputOut");
        drain(stderr, "RayNeoInputErr");
        shellReady = true;
    }

    private void drain(java.io.InputStream in, String threadName) {
        new Thread(() -> {
            try (BufferedReader br = new BufferedReader(new InputStreamReader(in))) {
                String line;
                while ((line = br.readLine()) != null) {
                    android.util.Log.d(threadName, line);
                }
            } catch (Throwable ignored) {}
        }, threadName).start();
    }

    private synchronized void writeCommand(String command) throws Exception {
        if (!shellReady || shellIn == null) throw new IllegalStateException("input shell not ready");
        shellIn.write((command + "\n").getBytes(StandardCharsets.UTF_8));
        shellIn.flush();
    }

    private synchronized void closeShell() {
        shellReady = false;
        try {
            if (shellIn != null) {
                shellIn.write("exit\n".getBytes(StandardCharsets.UTF_8));
                shellIn.flush();
                shellIn.close();
            }
        } catch (Throwable ignored) {}
        shellIn = null;
        if (remoteShell != null) {
            try { remoteShell.getClass().getMethod("destroy").invoke(remoteShell); } catch (Throwable ignored) {}
        }
        remoteShell = null;
    }

    private void status(boolean ok, String text) {
        Messenger m = replyTo;
        if (m == null) return;
        try {
            Message out = Message.obtain(null, MSG_STATUS);
            Bundle b = new Bundle();
            b.putBoolean(KEY_OK, ok);
            b.putString(KEY_TEXT, text);
            out.setData(b);
            m.send(out);
        } catch (Throwable ignored) {}
    }

    private String describe(Throwable t) {
        String msg = t.getMessage();
        if (msg == null || msg.trim().isEmpty()) msg = "(no message)";
        return "INPUT ERROR — " + t.getClass().getSimpleName() + ": " + msg;
    }

    @Override public void onDestroy() {
        closeShell();
        super.onDestroy();
    }
}
