package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import android.graphics.*;

/**
 * Experimental 3DoF screen anchor.
 *
 * Captures the handset's main display with MediaProjection, renders it into a
 * TextureView hosted on the RayNeo/external presentation display, and moves
 * that texture opposite the integrated RayNeo pitch/yaw angles.
 */
public class AnchorActivity extends Activity {
    private static final int REQ_CAPTURE = 4401;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private VirtualDisplay virtualDisplay;
    private AnchorPresentation presentation;
    private TextView status;

    private float screenScale = 0.72f;
    private float hFovDeg = 46.0f;
    private float vFovDeg = 27.0f;
    private float anchorPitch = 0f, anchorYaw = 0f;
    private float filteredPitch = 0f, filteredYaw = 0f;
    private boolean havePose = false;

    private final BroadcastReceiver poseReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TrackingService.ACTION_STATUS.equals(intent.getAction())) return;
            float pitch = (float) intent.getDoubleExtra("pitch", 0.0);
            float yaw = (float) intent.getDoubleExtra("yaw", 0.0);

            if (!havePose) {
                anchorPitch = pitch;
                anchorYaw = yaw;
                filteredPitch = pitch;
                filteredYaw = yaw;
                havePose = true;
            }

            // Light display smoothing. The IMU service already filters rates.
            filteredPitch += (pitch - filteredPitch) * 0.35f;
            filteredYaw += (yaw - filteredYaw) * 0.35f;
            updateAnchorTransform();
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(poseReceiver, new IntentFilter(TrackingService.ACTION_STATUS));
        buildUi();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(28, 28, 28, 28);

        TextView title = new TextView(this);
        title.setText("RAYNEO 3DoF ANCHOR");
        title.setTextSize(26);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Experimental anchor mode. It captures the Android screen and counter-moves it on the RayNeo display using the proven Air 4 Pro IMU.\n\nKeep Head Tracking running first, then start screen capture.");
        help.setTextSize(14);
        help.setPadding(0, 10, 0, 18);
        root.addView(help);

        status = new TextView(this);
        status.setText("Ready. Start capture below.");
        status.setPadding(14, 14, 14, 14);
        status.setBackgroundColor(0xffe4e7e0);
        root.addView(status, new LinearLayout.LayoutParams(-1, -2));

        TextView scaleLabel = new TextView(this);
        scaleLabel.setText("Virtual screen size");
        scaleLabel.setPadding(0, 22, 0, 0);
        root.addView(scaleLabel);

        SeekBar scale = new SeekBar(this);
        scale.setMax(90);
        scale.setProgress(62); // maps to 0.30..1.00 ~= 0.78
        root.addView(scale);
        screenScale = 0.30f + 0.70f * (scale.getProgress() / 90f);
        scale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                screenScale = 0.30f + 0.70f * (progress / 90f);
                updateAnchorTransform();
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 20, 0, 0);
        Button capture = button("START ANCHOR", 0xff2f7d4a);
        Button recenter = button("PIN HERE", 0xff59645b);
        row.addView(capture, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(recenter, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        Button stop = button("STOP ANCHOR", 0xffa43f35);
        LinearLayout.LayoutParams stopLp = new LinearLayout.LayoutParams(-1, -2);
        stopLp.setMargins(0, 8, 0, 0);
        root.addView(stop, stopLp);

        TextView note = new TextView(this);
        note.setText("PIN HERE makes the screen's current direction its fixed virtual position. Turn your head and the image should move the opposite way. This first build is 3DoF rotation only — no positional 6DoF yet.");
        note.setTextSize(13);
        note.setPadding(0, 20, 0, 0);
        root.addView(note);

        capture.setOnClickListener(v -> requestCapture());
        recenter.setOnClickListener(v -> pinHere());
        stop.setOnClickListener(v -> stopAnchor());

        setContentView(root);
    }

    private Button button(String text, int colour) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(colour);
        return b;
    }

    private void requestCapture() {
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("No separate external/presentation display detected. If the glasses are only mirrored by Android, this anchor method cannot take control of them yet.");
            return;
        }
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Screen capture permission cancelled");
            return;
        }
        projection = projectionManager.getMediaProjection(resultCode, data);
        startPresentationAndCapture();
    }

    private Display findExternalDisplay() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display[] displays = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if (displays != null && displays.length > 0) return displays[0];
        // Fallback: any non-default physical display.
        for (Display d : dm.getDisplays()) if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
        return null;
    }

    private void startPresentationAndCapture() {
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("External display disappeared");
            stopAnchor();
            return;
        }

        presentation = new AnchorPresentation(this, target);
        presentation.setOnDismissListener(dialog -> stopVirtualDisplayOnly());
        try {
            presentation.show();
        } catch (Throwable t) {
            status.setText("Could not open RayNeo presentation display: " + t.getMessage());
            stopAnchor();
            return;
        }

        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
                startVirtualDisplay(st);
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) { stopVirtualDisplayOnly(); return true; }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {}
        });

        if (presentation.texture.isAvailable()) startVirtualDisplay(presentation.texture.getSurfaceTexture());
        pinHere();
        status.setText("Anchor active on external display • use PIN HERE to recenter");
    }

    private void startVirtualDisplay(SurfaceTexture st) {
        stopVirtualDisplayOnly();
        if (projection == null || st == null || presentation == null) return;

        DisplayMetrics m = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(m);
        int width = Math.max(640, m.widthPixels);
        int height = Math.max(360, m.heightPixels);
        int density = Math.max(160, m.densityDpi);
        st.setDefaultBufferSize(width, height);
        Surface surface = new Surface(st);

        try {
            virtualDisplay = projection.createVirtualDisplay(
                    "RayNeoAnchorCapture", width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    surface, null, null);
        } catch (Throwable t) {
            status.setText("Could not start screen capture: " + t.getMessage());
            try { surface.release(); } catch (Throwable ignored) {}
        }
    }

    private void pinHere() {
        if (havePose) {
            anchorPitch = filteredPitch;
            anchorYaw = filteredYaw;
        } else {
            anchorPitch = anchorYaw = 0f;
        }
        updateAnchorTransform();
        if (status != null) status.setText("Pinned here • turn your head to test the anchor");
    }

    private void updateAnchorTransform() {
        if (presentation == null || presentation.texture == null) return;
        TextureView t = presentation.texture;
        int w = t.getWidth(), h = t.getHeight();
        if (w <= 0 || h <= 0) return;

        float yaw = filteredYaw - anchorYaw;
        float pitch = filteredPitch - anchorPitch;

        // Map angular head rotation into the opposite screen-space movement.
        // tan() gives a better approximation of a fixed world direction than
        // simple linear pixels/degree, while still being cheap enough at ~10Hz UI updates.
        double xNorm = Math.tan(Math.toRadians(yaw)) / Math.tan(Math.toRadians(hFovDeg / 2.0));
        double yNorm = Math.tan(Math.toRadians(pitch)) / Math.tan(Math.toRadians(vFovDeg / 2.0));
        float dx = (float) (-xNorm * (w / 2.0));
        float dy = (float) ( yNorm * (h / 2.0));

        Matrix matrix = new Matrix();
        float cx = w / 2f, cy = h / 2f;
        matrix.postScale(screenScale, screenScale, cx, cy);
        matrix.postTranslate(dx, dy);
        t.setTransform(matrix);
    }

    private void stopVirtualDisplayOnly() {
        if (virtualDisplay != null) {
            try { virtualDisplay.release(); } catch (Throwable ignored) {}
            virtualDisplay = null;
        }
    }

    private void stopAnchor() {
        stopVirtualDisplayOnly();
        if (presentation != null) {
            try { presentation.dismiss(); } catch (Throwable ignored) {}
            presentation = null;
        }
        if (projection != null) {
            try { projection.stop(); } catch (Throwable ignored) {}
            projection = null;
        }
        if (status != null) status.setText("Anchor stopped");
    }

    @Override protected void onDestroy() {
        try { unregisterReceiver(poseReceiver); } catch (Throwable ignored) {}
        stopAnchor();
        super.onDestroy();
    }

    private static class AnchorPresentation extends Presentation {
        TextureView texture;

        AnchorPresentation(Context outerContext, Display display) {
            super(outerContext, display);
        }

        @Override protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                    WindowManager.LayoutParams.FLAG_FULLSCREEN);
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_FULLSCREEN |
                    View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);

            FrameLayout root = new FrameLayout(getContext());
            root.setBackgroundColor(Color.BLACK);
            texture = new TextureView(getContext());
            root.addView(texture, new FrameLayout.LayoutParams(-1, -1));

            TextView marker = new TextView(getContext());
            marker.setText("•");
            marker.setTextColor(0x88ffffff);
            marker.setTextSize(18);
            marker.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams mlp = new FrameLayout.LayoutParams(40, 40, Gravity.CENTER);
            root.addView(marker, mlp);
            setContentView(root);
        }
    }
}
