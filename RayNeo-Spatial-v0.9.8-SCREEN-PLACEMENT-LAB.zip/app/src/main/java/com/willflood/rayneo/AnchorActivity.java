package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * RayNeo Spatial Desktop v0.9.8 SCREEN PLACEMENT + STICKY SIDE APPS LAB.
 *
 * Important architectural change from v0.6:
 * v0.6 translated full-display child views outside a display-sized parent. On some Android
 * compositors that effectively behaves like one moving panel. v0.7 instead creates a large
 * world canvas (~5 display widths), places three real panels at fixed world coordinates, and
 * moves the camera (the world container) from the Air 4 Pro head pose.
 *
 * Centre = live Android capture. Left/right = independent app-owned VirtualDisplays.
 * v0.9.8 keeps the proven RayNeo-drawn software cursor and sticky side-app path.
 * It replaces the rigid row-layout sliders with a direct placement editor:
 * select LEFT/CENTRE/RIGHT, drag on a circular touch pad to place that screen in X/Y,
 * and pinch on the pad to resize only the selected screen. Layout changes are user-driven only.
 */
public class AnchorActivity extends Activity {
    public static final String ACTION_OVERLAY = "com.willflood.rayneo.ANCHOR_OVERLAY_ACTION";
    public static final String EXTRA_COMMAND = "command";
    public static final String CMD_SNAP_LEFT = "snap_left";
    public static final String CMD_SNAP_RIGHT = "snap_right";
    public static final String CMD_PIN = "pin";
    public static final String CMD_STOP = "stop";

    private static final int REQ_CAPTURE = 4401;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;
    private static final long UI_INTERVAL_MS = 250L;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;

    // v0.9.1 LAB ONLY. These are never created automatically.
    // Keeping them completely idle preserves the proven v0.8 tracking path until a test button is pressed.
    private VirtualDisplay leftLabDisplay, rightLabDisplay;
    private Surface leftLabSurface, rightLabSurface;
    private int leftLabWidth, leftLabHeight, rightLabWidth, rightLabHeight;
    private SpatialPresentation presentation;

    private TextView status, poseInfo, renderInfo, labInfo;
    private boolean overlayPermissionRequested;

    // v0.9.6 fixed panels + software-cursor control. No focus scaling or depth code.
    private boolean stickySideApps = true;
    private String leftAppPackage, rightAppPackage;
    private String leftAppComponent, rightAppComponent;
    private int controlTarget = 0; // 0 = centre/native uinput, 1 = left, 2 = right
    private int leftCursorDisplayX, leftCursorDisplayY, rightCursorDisplayX, rightCursorDisplayY;
    private boolean leftCursorInside, rightCursorInside;

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_OVERLAY.equals(intent.getAction())) return;
            String command = intent.getStringExtra(EXTRA_COMMAND);
            if (CMD_SNAP_LEFT.equals(command)) snapshot(true);
            else if (CMD_SNAP_RIGHT.equals(command)) snapshot(false);
            else if (CMD_PIN.equals(command)) pinHere();
            else if (CMD_STOP.equals(command)) stopAnchor();
        }
    };

    private final BroadcastReceiver shizukuResultReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ShizukuBridgeActivity.ACTION_RESULT.equals(intent.getAction())) return;
            boolean ok=intent.getBooleanExtra(ShizukuBridgeActivity.EXTRA_OK,false);
            String result=intent.getStringExtra(ShizukuBridgeActivity.EXTRA_RESULT);
            String side=intent.getStringExtra(ShizukuBridgeActivity.EXTRA_SIDE);
            setLabStatus((ok?"SHIZUKU OK — ":"SHIZUKU ERROR — ") + (result==null?"(no result)":result));
            if(ok && side!=null && presentation!=null){
                boolean left="LEFT".equals(side);
                TextView label=left?presentation.leftLabel:presentation.rightLabel;
                TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
                if(tv!=null)tv.setVisibility(View.VISIBLE);
                if(label!=null)label.setVisibility(View.GONE);
            }
        }
    };

    private volatile float latestPitch, latestYaw;
    private float filteredPitch, filteredYaw;
    private float anchorPitch, anchorYaw;
    private boolean havePose;

    private boolean anchorRunning, stopping;
    private boolean invertX = true, invertY = true; // proven on user's Air 4 Pro

    // v0.9.8 direct screen placement. The base geometry matches the comfortable v0.9.7 layout.
    private static final int SCREEN_LEFT = 0, SCREEN_CENTRE = 1, SCREEN_RIGHT = 2;
    private int layoutSelected = SCREEN_CENTRE;
    private boolean layoutLocked = false;
    private final float[] panelOffsetX = new float[]{0f,0f,0f}; // screen-width units from each default position
    private final float[] panelOffsetY = new float[]{0f,0f,0f}; // screen-height units from each default position
    private final float[] panelUserScale = new float[]{1f,1f,1f};
    private final float panelScale = 0.712f;
    private final float panelSpacingScreens = 1.17f;
    private LayoutPadView layoutPad;
    private TextView layoutInfo;
    private Button layoutLockButton;

    private float hFovDeg = 46f, vFovDeg = 27f;
    private long lastFrameNs, lastUiMs;
    private float lastDx, lastDy;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (isFinishing() || isDestroyed()) return;

            if (TrackingService.livePoseValid) {
                latestPitch = (float) TrackingService.livePitch;
                latestYaw = (float) TrackingService.liveYaw;
                if (!havePose) {
                    filteredPitch = latestPitch;
                    filteredYaw = latestYaw;
                    anchorPitch = filteredPitch;
                    anchorYaw = filteredYaw;
                    havePose = true;
                }
            }

            if (havePose) {
                float dt = lastFrameNs == 0 ? 1f/60f : Math.min(.05f,(frameTimeNanos-lastFrameNs)/1_000_000_000f);
                float alpha = 1f-(float)Math.exp(-dt*30f);
                filteredPitch += (latestPitch-filteredPitch)*alpha;
                filteredYaw += (latestYaw-filteredYaw)*alpha;
            }
            lastFrameNs = frameTimeNanos;

            if (anchorRunning && !stopping) updateCamera();
            updateSoftwareCursor();

            long now = SystemClock.uptimeMillis();
            if (now-lastUiMs >= UI_INTERVAL_MS) {
                lastUiMs=now;
                poseInfo.setText(String.format(Locale.UK,
                        "PITCH %+7.2f°   YAW %+7.2f°\nPIN   %+7.2f°   %+7.2f°",
                        filteredPitch,filteredYaw,anchorPitch,anchorYaw));
                renderInfo.setText(String.format(Locale.UK,
                        "CAMERA X %+7.0f px   Y %+7.0f px\nPLACEMENT: %s  X %+4.2f  Y %+4.2f  SIZE %3.0f%%",
                        lastDx,lastDy,screenName(layoutSelected),panelOffsetX[layoutSelected],panelOffsetY[layoutSelected],panelUserScale[layoutSelected]*100f));
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        loadLayoutState();
        registerReceiver(overlayReceiver, new IntentFilter(ACTION_OVERLAY));
        registerReceiver(shizukuResultReceiver, new IntentFilter(ShizukuBridgeActivity.ACTION_RESULT));
        buildUi();
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,32); sv.addView(root);
        TextView title=new TextView(this); title.setText("RAYNEO SPATIAL DESKTOP • v0.9.8 SCREEN PLACEMENT + STICKY SIDE APPS LAB"); title.setTextSize(24); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView help=new TextView(this); help.setText("Place each screen directly: choose LEFT / CENTRE / RIGHT, drag on the circular pad to move it, and pinch on the same pad to shrink/grow it. No automatic gaze zoom."); help.setPadding(0,8,0,12); root.addView(help);
        status=box(root,"Ready");
        poseInfo=box(root,"IMU waiting…");
        renderInfo=box(root,"Spatial canvas not started");
        labInfo=box(root,"LAB: Shizuku isolated • software cursor idle");

        TextView layoutTitle=new TextView(this); layoutTitle.setText("SCREEN PLACEMENT"); layoutTitle.setTypeface(null,Typeface.BOLD); layoutTitle.setPadding(0,14,0,4); root.addView(layoutTitle);
        layoutInfo=box(root,"LAYOUT: CENTRE selected");
        LinearLayout selectRow=new LinearLayout(this); selectRow.setOrientation(LinearLayout.HORIZONTAL);
        Button selectLeft=button("LEFT",0xff5a6470), selectCentre=button("CENTRE",0xff3f6d4f), selectRight=button("RIGHT",0xff5a6470);
        selectRow.addView(selectLeft,new LinearLayout.LayoutParams(0,-2,1)); selectRow.addView(selectCentre,new LinearLayout.LayoutParams(0,-2,1)); selectRow.addView(selectRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(selectRow);

        layoutPad=new LayoutPadView(this,new LayoutPadListener(){
            @Override public void onMove(float dxNorm,float dyNorm){
                if(layoutLocked)return;
                panelOffsetX[layoutSelected]=clampf(panelOffsetX[layoutSelected]+dxNorm*0.85f,-1.50f,1.50f);
                panelOffsetY[layoutSelected]=clampf(panelOffsetY[layoutSelected]+dyNorm*0.65f,-1.20f,1.20f);
                applyPanelPositions(); updateLayoutInfo(); updateSoftwareCursor();
            }
            @Override public float getScale(){return panelUserScale[layoutSelected];}
            @Override public void onScale(float scale){
                if(layoutLocked)return;
                panelUserScale[layoutSelected]=clampf(scale,0.45f,1.60f);
                applyPanelScales(); updateLayoutInfo(); updateSoftwareCursor();
            }
            @Override public void onGestureEnd(){saveLayoutState();}
        });
        LinearLayout.LayoutParams padLp=new LinearLayout.LayoutParams(-1,-2); padLp.setMargins(0,8,0,8); root.addView(layoutPad,padLp);
        TextView padHelp=new TextView(this); padHelp.setText("ONE FINGER = move selected screen   •   TWO FINGERS = pinch size"); padHelp.setGravity(Gravity.CENTER); padHelp.setPadding(0,0,0,8); root.addView(padHelp);

        LinearLayout resetRow=new LinearLayout(this); resetRow.setOrientation(LinearLayout.HORIZONTAL);
        Button resetSelected=button("RESET SELECTED",0xff555555), resetAll=button("RESET ALL",0xff555555);
        layoutLockButton=button(layoutLocked?"UNLOCK LAYOUT":"LOCK LAYOUT",0xff765229);
        resetRow.addView(resetSelected,new LinearLayout.LayoutParams(0,-2,1)); resetRow.addView(resetAll,new LinearLayout.LayoutParams(0,-2,1)); resetRow.addView(layoutLockButton,new LinearLayout.LayoutParams(0,-2,1)); root.addView(resetRow);

        selectLeft.setOnClickListener(v->selectLayoutPanel(SCREEN_LEFT));
        selectCentre.setOnClickListener(v->selectLayoutPanel(SCREEN_CENTRE));
        selectRight.setOnClickListener(v->selectLayoutPanel(SCREEN_RIGHT));
        resetSelected.setOnClickListener(v->resetSelectedLayout());
        resetAll.setOnClickListener(v->resetAllLayout());
        layoutLockButton.setOnClickListener(v->{
            layoutLocked=!layoutLocked;
            layoutLockButton.setText(layoutLocked?"UNLOCK LAYOUT":"LOCK LAYOUT");
            layoutPad.setLocked(layoutLocked);
            updateLayoutInfo();
            saveLayoutState();
        });
        updateLayoutInfo();

        CheckBox ix=new CheckBox(this); ix.setText("Invert horizontal anchor"); ix.setChecked(true); root.addView(ix);
        CheckBox iy=new CheckBox(this); iy.setText("Invert vertical anchor"); iy.setChecked(true); root.addView(iy);

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button start=button("START ANCHOR",0xff2f7d4a), pin=button("PIN HERE",0xff59645b);
        row.addView(start,new LinearLayout.LayoutParams(0,-2,1)); row.addView(pin,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);

        TextView labTitle=new TextView(this); labTitle.setText("INDEPENDENT APP DISPLAYS"); labTitle.setTypeface(null,Typeface.BOLD); labTitle.setPadding(0,14,0,4); root.addView(labTitle);
        Button shizuku=button("CONNECT SHIZUKU",0xff6a3f8e); root.addView(shizuku);
        LinearLayout labRow=new LinearLayout(this); labRow.setOrientation(LinearLayout.HORIZONTAL);
        Button createLeft=button("CREATE LEFT DISPLAY",0xff765229), createRight=button("CREATE RIGHT DISPLAY",0xff765229);
        labRow.addView(createLeft,new LinearLayout.LayoutParams(0,-2,1)); labRow.addView(createRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(labRow);
        LinearLayout launchRow=new LinearLayout(this); launchRow.setOrientation(LinearLayout.HORIZONTAL);
        Button launchLeft=button("LAUNCH LEFT APP",0xff355f82), launchRight=button("LAUNCH RIGHT APP",0xff355f82);
        launchRow.addView(launchLeft,new LinearLayout.LayoutParams(0,-2,1)); launchRow.addView(launchRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(launchRow);

        CheckBox stickyToggle=new CheckBox(this); stickyToggle.setText("Keep LEFT/RIGHT apps pinned to their display (experimental)"); stickyToggle.setChecked(true); root.addView(stickyToggle);

        TextView inputTitle=new TextView(this); inputTitle.setText("SOFTWARE CURSOR CONTROL"); inputTitle.setTypeface(null,Typeface.BOLD); inputTitle.setPadding(0,14,0,4); root.addView(inputTitle);
        LinearLayout controlRow=new LinearLayout(this); controlRow.setOrientation(LinearLayout.HORIZONTAL);
        Button controlLeft=button("CONTROL LEFT",0xff8a5a24), controlCentre=button("CONTROL CENTRE",0xff3f6d4f), controlRight=button("CONTROL RIGHT",0xff8a5a24);
        controlRow.addView(controlLeft,new LinearLayout.LayoutParams(0,-2,1)); controlRow.addView(controlCentre,new LinearLayout.LayoutParams(0,-2,1)); controlRow.addView(controlRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(controlRow);
        LinearLayout actionRow=new LinearLayout(this); actionRow.setOrientation(LinearLayout.HORIZONTAL);
        Button clickSelected=button("CLICK SELECTED",0xff355f82), backSelected=button("BACK SELECTED",0xff555555);
        actionRow.addView(clickSelected,new LinearLayout.LayoutParams(0,-2,1)); actionRow.addView(backSelected,new LinearLayout.LayoutParams(0,-2,1)); root.addView(actionRow);
        LinearLayout repinRow=new LinearLayout(this); repinRow.setOrientation(LinearLayout.HORIZONTAL);
        Button repinLeft=button("RETURN LEFT APP",0xff6a3f8e), repinRight=button("RETURN RIGHT APP",0xff6a3f8e);
        repinRow.addView(repinLeft,new LinearLayout.LayoutParams(0,-2,1)); repinRow.addView(repinRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(repinRow);
        TextView cursorHelp=new TextView(this); cursorHelp.setText("The white crosshair is drawn by RayNeo Spatial. CLICK SELECTED injects a touchscreen tap into the chosen VirtualDisplay. If an app opens its next screen on the phone display, sticky mode tries to move that escaped task back. RETURN LEFT/RIGHT APP lets you retry manually."); cursorHelp.setPadding(0,6,0,8); root.addView(cursorHelp);

        LinearLayout labStopRow=new LinearLayout(this); labStopRow.setOrientation(LinearLayout.HORIZONTAL);
        Button destroyLeft=button("DESTROY LEFT",0xff555555), destroyRight=button("DESTROY RIGHT",0xff555555);
        labStopRow.addView(destroyLeft,new LinearLayout.LayoutParams(0,-2,1)); labStopRow.addView(destroyRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(labStopRow);

        Button floating=button("ENABLE FLOATING CONTROLS",0xff7b4f9c);
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2); flp.setMargins(0,8,0,8); root.addView(floating,flp);

        Button stop=button("STOP ANCHOR",0xffa43f35); root.addView(stop);
        TextView note=new TextView(this); note.setText("TEST: choose a screen above, drag on the circular pad to move only that screen, then pinch on the pad to resize only that screen. Lock the layout when comfortable. Side cursor/click and sticky app-return behaviour are unchanged."); note.setPadding(0,16,0,0); root.addView(note);

        start.setOnClickListener(v->requestCapture()); pin.setOnClickListener(v->pinHere()); stop.setOnClickListener(v->stopAnchor());
        shizuku.setOnClickListener(v->startShizukuBridge(ShizukuBridgeActivity.MODE_CONNECT,null,-1,null));
        createLeft.setOnClickListener(v->createLabDisplay(true));
        createRight.setOnClickListener(v->createLabDisplay(false));
        launchLeft.setOnClickListener(v->chooseAndLaunchApp(true));
        launchRight.setOnClickListener(v->chooseAndLaunchApp(false));
        controlLeft.setOnClickListener(v->selectControlTarget(1));
        controlCentre.setOnClickListener(v->selectControlTarget(0));
        controlRight.setOnClickListener(v->selectControlTarget(2));
        clickSelected.setOnClickListener(v->clickSelectedDisplay());
        backSelected.setOnClickListener(v->backSelectedDisplay());
        repinLeft.setOnClickListener(v->repinSideApp(true));
        repinRight.setOnClickListener(v->repinSideApp(false));
        destroyLeft.setOnClickListener(v->releaseLabDisplay(true, "LEFT display released"));
        destroyRight.setOnClickListener(v->releaseLabDisplay(false, "RIGHT display released"));
        floating.setOnClickListener(v->enableFloatingControls());
        stickyToggle.setOnCheckedChangeListener((b2,c)->stickySideApps=c);
        ix.setOnCheckedChangeListener((b2,c)->invertX=c); iy.setOnCheckedChangeListener((b2,c)->invertY=c);
        setContentView(sv);
    }
    private TextView box(LinearLayout r,String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(13);v.setTypeface(Typeface.MONOSPACE);v.setTextColor(0xffe8eee8);v.setBackgroundColor(0xff20242a);v.setPadding(12,12,12,12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);r.addView(v,lp);return v;}
    private Button button(String t,int c){Button b=new Button(this);b.setText(t);b.setTextColor(Color.WHITE);b.setBackgroundColor(c);return b;}


    private String screenName(int index){
        if(index==SCREEN_LEFT)return "LEFT";
        if(index==SCREEN_RIGHT)return "RIGHT";
        return "CENTRE";
    }

    private FrameLayout panelForIndex(int index){
        if(presentation==null)return null;
        if(index==SCREEN_LEFT)return presentation.leftPanel;
        if(index==SCREEN_RIGHT)return presentation.rightPanel;
        return presentation.centerPanel;
    }

    private void selectLayoutPanel(int index){
        layoutSelected=Math.max(SCREEN_LEFT,Math.min(SCREEN_RIGHT,index));
        updateLayoutInfo(); saveLayoutState();
    }

    private void applyPanelScales(){
        if(presentation==null)return;
        for(int i=SCREEN_LEFT;i<=SCREEN_RIGHT;i++){
            FrameLayout p=panelForIndex(i);
            if(p!=null){
                float sc=clampf(panelUserScale[i],0.45f,1.60f);
                p.setScaleX(sc); p.setScaleY(sc);
            }
        }
    }

    private void updateLayoutInfo(){
        if(layoutInfo!=null){
            layoutInfo.setText(String.format(Locale.UK,
                    "LAYOUT: %s selected%s\nX %+4.2f screens   Y %+4.2f screens   SIZE %3.0f%%\nDrag = position   •   Pinch = size",
                    screenName(layoutSelected),layoutLocked?" • LOCKED":"",
                    panelOffsetX[layoutSelected],panelOffsetY[layoutSelected],panelUserScale[layoutSelected]*100f));
        }
        if(layoutPad!=null){
            layoutPad.setPanelState(panelOffsetX[layoutSelected],panelOffsetY[layoutSelected],panelUserScale[layoutSelected],screenName(layoutSelected));
            layoutPad.setLocked(layoutLocked);
        }
    }

    private void resetSelectedLayout(){
        panelOffsetX[layoutSelected]=0f; panelOffsetY[layoutSelected]=0f; panelUserScale[layoutSelected]=1f;
        applyPanelPositions(); applyPanelScales(); updateSoftwareCursor(); updateLayoutInfo(); saveLayoutState();
    }

    private void resetAllLayout(){
        for(int i=0;i<3;i++){panelOffsetX[i]=0f;panelOffsetY[i]=0f;panelUserScale[i]=1f;}
        layoutLocked=false;
        if(layoutPad!=null)layoutPad.setLocked(false);
        if(layoutLockButton!=null)layoutLockButton.setText("LOCK LAYOUT");
        applyPanelPositions(); applyPanelScales(); updateSoftwareCursor(); updateLayoutInfo(); saveLayoutState();
    }

    private void loadLayoutState(){
        try{
            android.content.SharedPreferences p=getSharedPreferences("spatial_layout_v098",MODE_PRIVATE);
            for(int i=0;i<3;i++){
                panelOffsetX[i]=p.getFloat("x"+i,0f);
                panelOffsetY[i]=p.getFloat("y"+i,0f);
                panelUserScale[i]=clampf(p.getFloat("s"+i,1f),0.45f,1.60f);
            }
            layoutSelected=Math.max(SCREEN_LEFT,Math.min(SCREEN_RIGHT,p.getInt("selected",SCREEN_CENTRE)));
            layoutLocked=p.getBoolean("locked",false);
        }catch(Throwable ignored){}
    }

    private void saveLayoutState(){
        try{
            android.content.SharedPreferences.Editor e=getSharedPreferences("spatial_layout_v098",MODE_PRIVATE).edit();
            for(int i=0;i<3;i++)e.putFloat("x"+i,panelOffsetX[i]).putFloat("y"+i,panelOffsetY[i]).putFloat("s"+i,panelUserScale[i]);
            e.putInt("selected",layoutSelected).putBoolean("locked",layoutLocked).apply();
        }catch(Throwable ignored){}
    }


    private void enableFloatingControls() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlayPermissionRequested = true;
            status.setText("Allow ‘Display over other apps’, then return here");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        try {
            Intent i = new Intent(this, OverlayControlService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("FLOATING CONTROLS ACTIVE — switch to another app");
        } catch (Throwable t) {
            status.setText("Could not start floating controls: " + t.getMessage());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (overlayPermissionRequested && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            overlayPermissionRequested = false;
            startOverlayService();
        }
    }

    private Display externalDisplay(){DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);Display[] p=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);if(p!=null)for(Display d:p)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;for(Display d:dm.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return null;}

    private void requestCapture(){
        if(anchorRunning||projection!=null){status.setText("Already running — STOP first");return;}
        Display d=externalDisplay(); if(d==null){status.setText("No external RayNeo display detected");return;}
        status.setText("Requesting Android screen capture…"); startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(req!=REQ_CAPTURE)return;
        if(result!=RESULT_OK||data==null){status.setText("Capture permission cancelled");return;}
        projection=projectionManager.getMediaProjection(result,data); if(projection==null){status.setText("MediaProjection failed");return;}
        projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(!stopping){anchorRunning=false;status.setText("Capture stopped by Android");}});}};
        projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper()));
        startSpatialDisplay();
    }

    private void startSpatialDisplay(){
        Display d=externalDisplay(); if(d==null){status.setText("RayNeo display disappeared");stopAnchor();return;}
        try{presentation=new SpatialPresentation(this,d);presentation.show();}catch(Throwable t){status.setText("Presentation failed: "+t.getMessage());stopAnchor();return;}
        presentation.root.post(()->{layoutWorld(); attachCapture(); pinHere();});
    }

    private void attachCapture(){
        if(presentation==null)return;
        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startVirtualDisplay(st);}
            public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseVD();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(presentation.texture.isAvailable())startVirtualDisplay(presentation.texture.getSurfaceTexture());
    }

    private void startVirtualDisplay(SurfaceTexture st){
        releaseVD(); if(stopping||projection==null||st==null)return;
        DisplayMetrics m=new DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(m);
        float ds=Math.min(1f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(m.widthPixels,m.heightPixels));
        int w=Math.max(320,Math.round(m.widthPixels*ds)),h=Math.max(240,Math.round(m.heightPixels*ds)),dpi=Math.max(160,Math.round(m.densityDpi*ds));
        st.setDefaultBufferSize(w,h); captureSurface=new Surface(st);
        virtualDisplay=projection.createVirtualDisplay("RayNeoSpatialCapture",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,captureSurface,null,null);
        anchorRunning=virtualDisplay!=null;
        status.setText(anchorRunning?"SPATIAL DESKTOP ACTIVE — three world positions":"Virtual display failed");
    }

    private void layoutWorld(){
        if(presentation==null||presentation.root==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight(); if(vw<=0||vh<=0)return;
        int worldW=vw*7;
        FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)presentation.world.getLayoutParams();wlp.width=worldW;wlp.height=vh;wlp.gravity=Gravity.TOP|Gravity.LEFT;presentation.world.setLayoutParams(wlp);
        int pw=Math.max(320,Math.round(vw*panelScale));int ph=Math.max(240,Math.round(vh*panelScale));
        float cx=worldW/2f;
        // Initialise fixed base panel dimensions once; gesture movement uses X/Y only and does not resize surfaces.
        preparePanel(presentation.leftPanel,pw,ph);
        preparePanel(presentation.centerPanel,pw,ph);
        preparePanel(presentation.rightPanel,pw,ph);
        presentation.worldCenterX=cx;
        applyPanelPositions();
        applyPanelScales();
        updateCamera();
        updateSoftwareCursor();
    }

    private void preparePanel(View v,int w,int h){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();if(lp.width!=w||lp.height!=h){lp.width=w;lp.height=h;lp.gravity=Gravity.TOP|Gravity.LEFT;v.setLayoutParams(lp);}v.setPivotX(w/2f);v.setPivotY(h/2f);}

    private void applyPanelPositions(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float cx=presentation.worldCenterX; if(cx==0f)cx=(vw*7)/2f;
        float gap=panelSpacingScreens*vw;
        placePanelPosition(presentation.leftPanel,cx-gap+panelOffsetX[SCREEN_LEFT]*vw,vh/2f+panelOffsetY[SCREEN_LEFT]*vh);
        placePanelPosition(presentation.centerPanel,cx+panelOffsetX[SCREEN_CENTRE]*vw,vh/2f+panelOffsetY[SCREEN_CENTRE]*vh);
        placePanelPosition(presentation.rightPanel,cx+gap+panelOffsetX[SCREEN_RIGHT]*vw,vh/2f+panelOffsetY[SCREEN_RIGHT]*vh);
    }

    private void placePanelPosition(View v,float centerX,float centerY){
        int w=v.getWidth()>0?v.getWidth():((FrameLayout.LayoutParams)v.getLayoutParams()).width;
        int h=v.getHeight()>0?v.getHeight():((FrameLayout.LayoutParams)v.getLayoutParams()).height;
        v.setX(centerX-w/2f);v.setY(centerY-h/2f);v.setPivotX(w/2f);v.setPivotY(h/2f);
    }

    private void pinHere(){
        if(!havePose&&TrackingService.livePoseValid){latestPitch=(float)TrackingService.livePitch;latestYaw=(float)TrackingService.liveYaw;filteredPitch=latestPitch;filteredYaw=latestYaw;havePose=true;}
        if(!havePose){status.setText("Start head tracking first — no IMU pose yet");return;}
        filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;updateCamera();status.setText("PINNED — centre is straight ahead");
    }

    private void updateCamera(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float yaw=filteredYaw-anchorYaw,pitch=filteredPitch-anchorPitch;
        float dx=(invertX?1f:-1f)*(yaw/hFovDeg)*vw;
        float dy=(invertY?1f:-1f)*(pitch/vFovDeg)*vh;
        float baseX=vw/2f-presentation.worldCenterX;
        presentation.world.setTranslationX(baseX+dx);
        presentation.world.setTranslationY(dy);
        lastDx=dx;lastDy=dy;
    }


    /**
     * v0.9.1 diagnostic: create ONE ordinary app-owned VirtualDisplay only when requested.
     * This deliberately does not use MediaProjection and does not launch another app yet.
     * Any failure is caught and printed in the UI rather than allowed to take down Anchor Mode.
     */
    private void createLabDisplay(boolean left){
        if (stopping) { setLabStatus("BLOCKED: Anchor is stopping"); return; }
        if (!anchorRunning || presentation == null) { setLabStatus("BLOCKED: Start Anchor normally first"); return; }
        if (left ? leftLabDisplay != null : rightLabDisplay != null) {
            setLabStatus((left?"LEFT":"RIGHT") + " already exists — destroy it first");
            return;
        }

        final TextureView tv = left ? presentation.leftLabTexture : presentation.rightLabTexture;
        final TextView label = left ? presentation.leftLabel : presentation.rightLabel;
        final String side = left ? "LEFT" : "RIGHT";
        if (tv == null) { setLabStatus(side + " failed: diagnostic TextureView missing"); return; }

        try {
            label.setText(side + "\nVIRTUAL DISPLAY\nWAITING FOR SURFACE");
            label.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){
                    startLabVirtualDisplay(left, st, w, h);
                }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){
                    releaseLabDisplay(left, side + " surface destroyed");
                    return true;
                }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture st){}
            });
            if (tv.isAvailable()) startLabVirtualDisplay(left, tv.getSurfaceTexture(), tv.getWidth(), tv.getHeight());
            else setLabStatus(side + ": waiting for TextureView surface…");
        } catch (Throwable t) {
            showLabError(side + " setup", t);
            releaseLabDisplay(left, null);
        }
    }

    private void startLabVirtualDisplay(boolean left, SurfaceTexture st, int surfaceW, int surfaceH){
        final String side = left ? "LEFT" : "RIGHT";
        if (stopping || presentation == null || st == null) return;
        if (left ? leftLabDisplay != null : rightLabDisplay != null) return;
        try {
            int w = Math.max(320, surfaceW > 0 ? surfaceW : 640);
            int h = Math.max(240, surfaceH > 0 ? surfaceH : 360);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int dpi = Math.max(160, metrics.densityDpi);
            st.setDefaultBufferSize(w,h);
            Surface surface = new Surface(st);

            int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;
            DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
            VirtualDisplay vd=dm.createVirtualDisplay("RayNeoLab"+side,w,h,dpi,surface,flags);
            if(vd==null){
                try{surface.release();}catch(Throwable ignored){}
                setLabStatus(side + " FAILED: DisplayManager returned null");
                return;
            }
            if(left){leftLabDisplay=vd;leftLabSurface=surface;leftLabWidth=w;leftLabHeight=h;}
            else{rightLabDisplay=vd;rightLabSurface=surface;rightLabWidth=w;rightLabHeight=h;}
            Display disp=vd.getDisplay();
            int id=disp!=null?disp.getDisplayId():-1;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            label.setText(side + "\nVIRTUAL DISPLAY CREATED\nDisplay ID " + id + "\n(no app launched yet)");
            label.bringToFront();
            setLabStatus(side + " SUCCESS — VirtualDisplay ID " + id + ". Tracking should remain smooth.");
        }catch(Throwable t){
            showLabError(side + " createVirtualDisplay",t);
            releaseLabDisplay(left,null);
        }
    }


    private static class AppChoice {
        final String label;
        final String packageName;
        AppChoice(String label,String packageName){this.label=label;this.packageName=packageName;}
    }

    private void chooseAndLaunchApp(boolean left){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus("BLOCKED: CREATE " + side + " DISPLAY first");return;}
        try{
            PackageManager pm=getPackageManager();
            Intent main=new Intent(Intent.ACTION_MAIN,null); main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris=pm.queryIntentActivities(main,0);
            final ArrayList<AppChoice> apps=new ArrayList<>();
            for(ResolveInfo ri:ris){
                if(ri==null||ri.activityInfo==null)continue;
                String pkg=ri.activityInfo.packageName;
                if(pkg==null||pkg.equals(getPackageName()))continue;
                CharSequence cs=ri.loadLabel(pm); String label=cs!=null?cs.toString():pkg;
                boolean duplicate=false; for(AppChoice a:apps)if(a.packageName.equals(pkg)){duplicate=true;break;}
                if(!duplicate)apps.add(new AppChoice(label,pkg));
            }
            Collections.sort(apps,new Comparator<AppChoice>(){
                @Override public int compare(AppChoice a,AppChoice b){return a.label.compareToIgnoreCase(b.label);}
            });
            if(apps.isEmpty()){setLabStatus(side + " app list is empty");return;}
            String[] labels=new String[apps.size()]; for(int i=0;i<apps.size();i++)labels[i]=apps.get(i).label;
            new AlertDialog.Builder(this).setTitle("Launch app on " + side)
                    .setItems(labels,(dialog,which)->prepareBridgeLaunch(left,apps.get(which)))
                    .setNegativeButton("CANCEL",null).show();
        }catch(Throwable t){showLabError(side + " app picker",t);}
    }

    private void prepareBridgeLaunch(boolean left,AppChoice app){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus(side + " display disappeared before launch");return;}
        try{
            PackageManager pm=getPackageManager();
            Intent launch=pm.getLaunchIntentForPackage(app.packageName);
            if(launch==null){setLabStatus(side + " FAILED: no launch intent for " + app.label);return;}
            ComponentName component=launch.getComponent();
            if(component==null){
                ResolveInfo ri=pm.resolveActivity(launch,0);
                if(ri!=null&&ri.activityInfo!=null)component=new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name);
            }
            if(component==null){setLabStatus(side + " FAILED: could not resolve component for " + app.label);return;}
            int displayId=vd.getDisplay().getDisplayId();
            if(left){leftAppPackage=app.packageName;leftAppComponent=component.flattenToString();}
            else{rightAppPackage=app.packageName;rightAppComponent=component.flattenToString();}
            setLabStatus(side + " → isolated Shizuku launch " + app.label + " on Display " + displayId);
            startShizukuBridge(ShizukuBridgeActivity.MODE_LAUNCH,side,displayId,component.flattenToString(),app.packageName,-1,-1);
        }catch(Throwable t){showLabError(side + " bridge launch",t);}
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component){
        startShizukuBridge(mode,side,displayId,component,null,-1,-1);
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component,int x,int y){
        startShizukuBridge(mode,side,displayId,component,null,x,y);
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component,String packageName,int x,int y){
        try{
            Intent i=new Intent(this,ShizukuBridgeActivity.class).putExtra(ShizukuBridgeActivity.EXTRA_MODE,mode);
            if(side!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_SIDE,side);
            if(displayId>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_DISPLAY_ID,displayId);
            if(component!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_COMPONENT,component);
            if(packageName!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_PACKAGE,packageName);
            if(x>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_X,x);
            if(y>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_Y,y);
            startActivity(i);
        }catch(Throwable t){showLabError("start isolated Shizuku bridge",t);}
    }

    private void setCentreMouseEnabled(boolean enabled){
        try{
            Intent i=new Intent(this,TrackingService.class).setAction(TrackingService.ACTION_CONFIG).putExtra("mouse",enabled);
            startService(i);
        }catch(Throwable t){showLabError("switch centre mouse",t);}
    }

    private void selectControlTarget(int target){
        if(target==1&&(leftLabDisplay==null||leftLabDisplay.getDisplay()==null)){setLabStatus("CREATE LEFT DISPLAY first");return;}
        if(target==2&&(rightLabDisplay==null||rightLabDisplay.getDisplay()==null)){setLabStatus("CREATE RIGHT DISPLAY first");return;}
        controlTarget=target;
        if(target==0){
            setCentreMouseEnabled(true);
            if(presentation!=null){presentation.leftCursor.setCursor(0,0,false,false);presentation.rightCursor.setCursor(0,0,false,false);}
            setLabStatus("CONTROL CENTRE — normal /dev/uinput head mouse restored");
        }else{
            setCentreMouseEnabled(false);
            updateSoftwareCursor();
            setLabStatus("CONTROL "+(target==1?"LEFT":"RIGHT")+" — white software cursor follows the centre of your gaze");
        }
    }

    private void clickSelectedDisplay(){
        if(controlTarget==0){setLabStatus("CENTRE uses the normal /dev/uinput mouse");return;}
        boolean left=controlTarget==1;
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus("Selected side display is not available");return;}
        boolean inside=left?leftCursorInside:rightCursorInside;
        if(!inside){setLabStatus("LOOK AT the selected panel first — cursor is outside its active area");return;}
        int x=left?leftCursorDisplayX:rightCursorDisplayX;
        int y=left?leftCursorDisplayY:rightCursorDisplayY;
        String pkg=left?leftAppPackage:rightAppPackage;
        setLabStatus("TOUCH TAP → Display "+vd.getDisplay().getDisplayId()+" @ "+x+","+y+(stickySideApps&&pkg!=null?" • sticky "+pkg:""));
        startShizukuBridge(ShizukuBridgeActivity.MODE_TAP,null,vd.getDisplay().getDisplayId(),null,stickySideApps?pkg:null,x,y);
    }

    private void backSelectedDisplay(){
        if(controlTarget==0){setLabStatus("CENTRE uses normal Android controls");return;}
        VirtualDisplay vd=controlTarget==1?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null)return;
        setLabStatus("BACK → Display "+vd.getDisplay().getDisplayId());
        startShizukuBridge(ShizukuBridgeActivity.MODE_BACK,null,vd.getDisplay().getDisplayId(),null,-1,-1);
    }

    private void repinSideApp(boolean left){
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        String pkg=left?leftAppPackage:rightAppPackage;
        String component=left?leftAppComponent:rightAppComponent;
        String side=left?"LEFT":"RIGHT";
        if(vd==null||vd.getDisplay()==null){setLabStatus("CREATE "+side+" DISPLAY first");return;}
        if(pkg==null){setLabStatus("Launch a "+side+" app first");return;}
        setLabStatus("RETURN "+side+" → "+pkg+" to Display "+vd.getDisplay().getDisplayId());
        startShizukuBridge(ShizukuBridgeActivity.MODE_REPIN,side,vd.getDisplay().getDisplayId(),component,pkg,-1,-1);
    }

    private void updateSoftwareCursor(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(), vh=presentation.root.getHeight();
        if(vw<=0||vh<=0)return;
        updateCursorForPanel(true,vw,vh);
        updateCursorForPanel(false,vw,vh);
    }

    private void updateCursorForPanel(boolean left,int vw,int vh){
        if(presentation==null)return;
        int wanted=left?1:2;
        CursorOverlay cursor=left?presentation.leftCursor:presentation.rightCursor;
        FrameLayout panel=left?presentation.leftPanel:presentation.rightPanel;
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        int dw=left?leftLabWidth:rightLabWidth, dh=left?leftLabHeight:rightLabHeight;
        if(cursor==null||panel==null||controlTarget!=wanted||vd==null||dw<=0||dh<=0){
            if(cursor!=null)cursor.setCursor(0,0,false,false);
            if(left)leftCursorInside=false;else rightCursorInside=false;
            return;
        }
        float scale=panel.getScaleX();
        float visualW=Math.max(1f,panel.getWidth()*scale), visualH=Math.max(1f,panel.getHeight()*scale);
        float visualLeft=presentation.world.getTranslationX()+panel.getX()+(panel.getWidth()-visualW)/2f;
        float visualTop=presentation.world.getTranslationY()+panel.getY()+(panel.getHeight()-visualH)/2f;
        float nx=(vw/2f-visualLeft)/visualW;
        float ny=(vh/2f-visualTop)/visualH;
        boolean inside=nx>=0f&&nx<=1f&&ny>=0f&&ny<=1f;
        float cx=clampf(nx,0f,1f), cy=clampf(ny,0f,1f);
        float localX=cx*panel.getWidth(), localY=cy*panel.getHeight();
        cursor.setCursor(localX,localY,true,inside);
        int tx=Math.round(cx*(dw-1)), ty=Math.round(cy*(dh-1));
        if(left){leftCursorDisplayX=tx;leftCursorDisplayY=ty;leftCursorInside=inside;}
        else{rightCursorDisplayX=tx;rightCursorDisplayY=ty;rightCursorInside=inside;}
    }

    private static float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private void showLabError(String stage, Throwable t){
        String msg=t.getMessage();
        if(msg==null||msg.trim().isEmpty())msg="(no message)";
        String text="ERROR at " + stage + "\n" + t.getClass().getName() + "\n" + msg;
        setLabStatus(text);
        android.util.Log.e("RayNeoV091",text,t);
    }

    private void setLabStatus(String text){
        if(labInfo!=null)labInfo.setText("LAB: " + text);
    }

    private void releaseLabDisplay(boolean left,String message){
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if((left&&controlTarget==1)||(!left&&controlTarget==2))selectControlTarget(0);
        if(left){leftLabDisplay=null;leftLabWidth=leftLabHeight=0;leftAppPackage=null;leftAppComponent=null;}else{rightLabDisplay=null;rightLabWidth=rightLabHeight=0;rightAppPackage=null;rightAppComponent=null;}
        if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}
        Surface sf=left?leftLabSurface:rightLabSurface;
        if(left)leftLabSurface=null;else rightLabSurface=null;
        if(sf!=null)try{sf.release();}catch(Throwable ignored){}
        if(presentation!=null){
            TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            if(tv!=null){try{tv.setSurfaceTextureListener(null);}catch(Throwable ignored){}tv.setVisibility(View.GONE);}
            if(label!=null){label.setText(left?"LEFT\nSNAPSHOT":"RIGHT\nSNAPSHOT");label.setVisibility(View.VISIBLE);}
        }
        if(message!=null)setLabStatus(message);
    }

    private void snapshot(boolean left){
        if(presentation==null||!presentation.texture.isAvailable()){status.setText("Start Anchor first");return;}
        try{Bitmap b=presentation.texture.getBitmap();if(b==null){status.setText("Snapshot empty");return;}ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView label=left?presentation.leftLabel:presentation.rightLabel;iv.setImageBitmap(b);iv.setVisibility(View.VISIBLE);label.setVisibility(View.GONE);status.setText(left?"LEFT panel saved":"RIGHT panel saved");}catch(Throwable t){status.setText("Snapshot failed: "+t.getMessage());}
    }
    private void clear(boolean left){if(presentation==null)return;ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView l=left?presentation.leftLabel:presentation.rightLabel;iv.setImageDrawable(null);iv.setVisibility(View.GONE);l.setVisibility(View.VISIBLE);}

    private void releaseVD(){VirtualDisplay vd=virtualDisplay;virtualDisplay=null;if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}Surface s=captureSurface;captureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){} }
    private void stopAnchor(){
        if(stopping)return;stopping=true;anchorRunning=false;
        setCentreMouseEnabled(true); controlTarget=0;
        releaseLabDisplay(true,null); releaseLabDisplay(false,null);
        releaseVD();
        SpatialPresentation p=presentation;presentation=null;if(p!=null){try{p.texture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        MediaProjection mp=projection;projection=null;if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}
        projectionCallback=null;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");
    }
    @Override protected void onDestroy(){
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        try{unregisterReceiver(overlayReceiver);}catch(Throwable ignored){}
        try{unregisterReceiver(shizukuResultReceiver);}catch(Throwable ignored){}
        try{stopService(new Intent(this,OverlayControlService.class));}catch(Throwable ignored){}
        stopAnchor();
        super.onDestroy();
    }


    private interface LayoutPadListener {
        void onMove(float dxNorm,float dyNorm);
        float getScale();
        void onScale(float scale);
        void onGestureEnd();
    }

    /** Circular direct-manipulation pad for positioning and resizing one spatial screen. */
    private static class LayoutPadView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final LayoutPadListener listener;
        private float lastX,lastY,startPinchDistance,startPinchScale=1f;
        private boolean pinching,locked;
        private float indicatorX,indicatorY,indicatorScale=1f;
        private String selectedName="CENTRE";

        LayoutPadView(Context c,LayoutPadListener listener){
            super(c); this.listener=listener; setWillNotDraw(false); setFocusable(true); setClickable(true);
        }

        void setLocked(boolean locked){this.locked=locked;invalidate();}
        void setPanelState(float xScreens,float yScreens,float scale,String name){
            indicatorX=clampf(xScreens/1.50f,-1f,1f);
            indicatorY=clampf(yScreens/1.20f,-1f,1f);
            indicatorScale=clampf(scale,0.45f,1.60f);
            selectedName=name==null?"SCREEN":name;
            invalidate();
        }

        private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
        @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
            int w=MeasureSpec.getSize(widthMeasureSpec);
            if(w<=0)w=dp(340);
            int desired=Math.min(w,dp(360));
            setMeasuredDimension(w,desired);
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()/2f,cy=getHeight()/2f;
            float r=Math.max(20f,Math.min(getWidth(),getHeight())/2f-dp(14));
            paint.setStyle(Paint.Style.FILL); paint.setColor(locked?0xff25282c:0xff1e252b); c.drawCircle(cx,cy,r,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setColor(locked?0xff666666:0xff8fa3b2); c.drawCircle(cx,cy,r,paint);
            paint.setStrokeWidth(dp(1)); paint.setColor(0xff45515a); c.drawLine(cx-r,cy,cx+r,cy,paint); c.drawLine(cx,cy-r,cx,cy+r,paint);

            float hx=cx+indicatorX*r*0.62f, hy=cy+indicatorY*r*0.62f;
            float halfW=dp(34)*indicatorScale, halfH=dp(20)*indicatorScale;
            paint.setStyle(Paint.Style.FILL); paint.setColor(locked?0xff555555:0xff355f82);
            c.drawRoundRect(hx-halfW,hy-halfH,hx+halfW,hy+halfH,dp(6),dp(6),paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(Color.WHITE);
            c.drawRoundRect(hx-halfW,hy-halfH,hx+halfW,hy+halfH,dp(6),dp(6),paint);

            paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(dp(13));
            c.drawText(selectedName,hx,hy+dp(5),paint);
            paint.setTextSize(dp(12));paint.setColor(0xffcbd4da);
            c.drawText(locked?"LAYOUT LOCKED":"DRAG • PINCH",cx,cy+r-dp(12),paint);
        }

        private float spacing(MotionEvent e){
            if(e.getPointerCount()<2)return 0f;
            float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);
            return (float)Math.sqrt(dx*dx+dy*dy);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(locked){
                if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL)getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    lastX=e.getX();lastY=e.getY();pinching=false;return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    if(e.getPointerCount()>=2){
                        pinching=true;startPinchDistance=Math.max(1f,spacing(e));startPinchScale=listener.getScale();
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(e.getPointerCount()>=2){
                        if(!pinching){pinching=true;startPinchDistance=Math.max(1f,spacing(e));startPinchScale=listener.getScale();}
                        float ratio=spacing(e)/Math.max(1f,startPinchDistance);
                        listener.onScale(startPinchScale*ratio);
                    }else if(!pinching){
                        float r=Math.max(1f,Math.min(getWidth(),getHeight())/2f-dp(14));
                        float x=e.getX(),y=e.getY();
                        listener.onMove((x-lastX)/r,(y-lastY)/r);
                        lastX=x;lastY=y;
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    pinching=false;
                    if(e.getPointerCount()>1){
                        int remaining=e.getActionIndex()==0?1:0;
                        lastX=e.getX(remaining);lastY=e.getY(remaining);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pinching=false;getParent().requestDisallowInterceptTouchEvent(false);listener.onGestureEnd();performClick();return true;
            }
            return true;
        }

        @Override public boolean performClick(){super.performClick();return true;}
    }

    private static class SpatialPresentation extends Presentation {
        FrameLayout root,world,leftPanel,centerPanel,rightPanel;TextureView texture,leftLabTexture,rightLabTexture;ImageView leftImage,rightImage;TextView leftLabel,rightLabel;CursorOverlay leftCursor,rightCursor;float worldCenterX;
        SpatialPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){
            super.onCreate(b);getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(true);
            world=new FrameLayout(getContext());world.setBackgroundColor(Color.BLACK);world.setClipChildren(false);world.setClipToPadding(false);root.addView(world,new FrameLayout.LayoutParams(1,-1,Gravity.TOP|Gravity.LEFT));
            leftPanel=panel(getContext(),0xff171b22);centerPanel=panel(getContext(),Color.BLACK);rightPanel=panel(getContext(),0xff171b22);
            world.addView(leftPanel,new FrameLayout.LayoutParams(1,1));world.addView(centerPanel,new FrameLayout.LayoutParams(1,1));world.addView(rightPanel,new FrameLayout.LayoutParams(1,1));
            leftImage=image(getContext());leftPanel.addView(leftImage,new FrameLayout.LayoutParams(-1,-1));leftLabTexture=new TextureView(getContext());leftLabTexture.setOpaque(true);leftLabTexture.setVisibility(View.GONE);leftPanel.addView(leftLabTexture,new FrameLayout.LayoutParams(-1,-1));leftLabel=label(getContext(),"LEFT\nSNAPSHOT");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1));leftCursor=new CursorOverlay(getContext());leftPanel.addView(leftCursor,new FrameLayout.LayoutParams(-1,-1));
            texture=new TextureView(getContext());texture.setOpaque(true);centerPanel.addView(texture,new FrameLayout.LayoutParams(-1,-1));TextView ct=tag(getContext(),"CENTRE • LIVE");FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=10;centerPanel.addView(ct,ctlp);
            rightImage=image(getContext());rightPanel.addView(rightImage,new FrameLayout.LayoutParams(-1,-1));rightLabTexture=new TextureView(getContext());rightLabTexture.setOpaque(true);rightLabTexture.setVisibility(View.GONE);rightPanel.addView(rightLabTexture,new FrameLayout.LayoutParams(-1,-1));rightLabel=label(getContext(),"RIGHT\nSNAPSHOT");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1));rightCursor=new CursorOverlay(getContext());rightPanel.addView(rightCursor,new FrameLayout.LayoutParams(-1,-1));
            setContentView(root);
        }
        private static FrameLayout panel(Context c,int bg){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(bg);f.setClipChildren(true);f.setElevation(2f);return f;}
        private static ImageView image(Context c){ImageView i=new ImageView(c);i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);i.setVisibility(View.GONE);return i;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(28);v.setGravity(Gravity.CENTER);v.setTextColor(0xffe0e0e0);v.setBackgroundColor(0xff171b22);return v;}
        private static TextView tag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(13);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }

    private static class CursorOverlay extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x,y; private boolean visible,inside;
        CursorOverlay(Context c){super(c);setWillNotDraw(false);setClickable(false);setFocusable(false);}
        void setCursor(float x,float y,boolean visible,boolean inside){this.x=x;this.y=y;this.visible=visible;this.inside=inside;invalidate();}
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas); if(!visible)return;
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(5f);paint.setColor(inside?Color.WHITE:0xffb0b0b0);
            canvas.drawCircle(x,y,15f,paint);canvas.drawLine(x-24f,y,x+24f,y,paint);canvas.drawLine(x,y-24f,x,y+24f,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(0xff111111);canvas.drawCircle(x,y,4f,paint);
        }
    }
}
