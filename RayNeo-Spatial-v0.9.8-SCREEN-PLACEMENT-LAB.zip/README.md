# RayNeo Spatial v0.9.8 — Screen Placement LAB

Experimental build based on the working v0.9.7 fixed-panel / sticky-side-app architecture.

## New in this build
- Select LEFT, CENTRE or RIGHT independently.
- Large circular placement touch pad.
- One-finger drag moves only the selected screen in X/Y.
- Two-finger pinch shrinks/grows only the selected screen.
- No automatic gaze zoom or depth effect.
- RESET SELECTED and RESET ALL.
- LOCK LAYOUT prevents accidental edits.
- Layout is saved automatically and restored next time.
- Existing isolated-Shizuku launch, software cursor/click, independent VirtualDisplays and sticky side-app repinning are retained.

## Test order
1. Keep Shizuku running.
2. Start tracking and confirm smoothness.
3. Start Spatial Desktop.
4. Select LEFT in SCREEN PLACEMENT.
5. Drag around the circular pad and confirm only LEFT moves.
6. Pinch on the pad and confirm only LEFT changes size.
7. Repeat for CENTRE and RIGHT.
8. Lock the layout.
9. Create/launch side apps and verify cursor/click still works.

Public v0.8 remains the stable release; this is a LAB build.
