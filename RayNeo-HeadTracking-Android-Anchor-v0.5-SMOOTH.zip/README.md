# RayNeo Head Tracker + 3DoF Anchor v0.5

Experimental smooth-anchor build.

Changes from v0.4:
- Fixes vertical anchor direction by default.
- Adds independent horizontal and vertical anchor inversion controls.
- Removes the ~10 Hz pose-update bottleneck: AnchorActivity reads the latest pose directly from TrackingService every display frame, while the Air 4 Pro IMU continues running at full rate.
- Uses time-based smoothing for consistent response across 60/90/120 Hz displays.
- Retains v0.4 capture downscaling and crash-safe Stop teardown.

Build with the same GitHub Actions workflow used for previous versions.
