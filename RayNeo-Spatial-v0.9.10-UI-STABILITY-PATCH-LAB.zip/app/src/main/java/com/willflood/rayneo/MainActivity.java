package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import android.graphics.Color;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VID=0x1BBB, PID=0xAF50;
    private static final String USB_PERMISSION="com.willflood.rayneo.USB_PERMISSION";
    private TextView status, live, sensLabel, deadLabel, smoothLabel;
    private SeekBar sens, dead, smooth;
    private Switch mouse, invX, invY;

    // v0.9.10 setup-screen stability: keep the foreground UI actively paced even on
    // handheld firmware that drops the app to a very low render/performance state when
    // there is no touch input. Sensor/USB work remains in TrackingService.
    private static final long SETUP_UI_INTERVAL_MS = 100L; // diagnostics max 10 Hz
    private boolean uiHeartbeatActive = false;
    private long lastSetupUiMs = 0L;
    private String pendingStatusText = null;
    private boolean pendingLive = false;
    private double pendingPitch, pendingYaw, pendingRoll, pendingTemp;
    private long pendingFrames;

    private final Choreographer.FrameCallback setupFrameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (!uiHeartbeatActive || isFinishing() || isDestroyed()) return;

            // Force a lightweight foreground draw cadence. On the test handheld this is
            // intentionally similar to the touch-driven boost that keeps the setup UI smooth.
            View decor = getWindow().getDecorView();
            if (decor != null) decor.postInvalidateOnAnimation();

            long now = SystemClock.uptimeMillis();
            if (now - lastSetupUiMs >= SETUP_UI_INTERVAL_MS) {
                lastSetupUiMs = now;
                if (pendingStatusText != null && status != null) {
                    status.setText(pendingStatusText);
                    pendingStatusText = null;
                }
                if (pendingLive && live != null) {
                    live.setText(String.format(Locale.UK,
                            "PITCH  %+7.2f°\nYAW    %+7.2f°\nROLL   %+7.2f°\nTEMP   %5.1f°C\nFRAMES %d",
                            pendingPitch,pendingYaw,pendingRoll,pendingTemp,pendingFrames));
                    pendingLive = false;
                }
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    private final BroadcastReceiver usbReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            if (USB_PERMISSION.equals(i.getAction())) {
                UsbDevice d=i.getParcelableExtra(UsbManager.EXTRA_DEVICE);
                if (i.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED,false) && d!=null) startTracking();
                else status.setText("USB permission denied");
            }
        }
    };
    private final BroadcastReceiver statusReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            String t=i.getStringExtra("text");
            if (t!=null) pendingStatusText=t;
            pendingPitch=i.getDoubleExtra("pitch",0);
            pendingYaw=i.getDoubleExtra("yaw",0);
            pendingRoll=i.getDoubleExtra("roll",0);
            pendingTemp=i.getDoubleExtra("temp",0);
            pendingFrames=i.getLongExtra("frames",0);
            pendingLive=true;
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        registerReceiver(usbReceiver,new IntentFilter(USB_PERMISSION));
        registerReceiver(statusReceiver,new IntentFilter(TrackingService.ACTION_STATUS));
        buildUi();
        updateUsbState();
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(28,24,28,32);
        sv.addView(root);

        TextView title=new TextView(this); title.setText("RAYNEO HEAD TRACKER"); title.setTextSize(28); title.setTextColor(Color.BLACK); title.setTypeface(null,1); root.addView(title);
        TextView sub=new TextView(this); sub.setText("Air 4 Pro • native USB IMU → virtual mouse\nBuilt from the proven Termux tracker"); sub.setTextSize(14); sub.setPadding(0,4,0,20); root.addView(sub);

        status=new TextView(this); status.setText("Checking RayNeo…"); status.setTextSize(16); status.setPadding(14,14,14,14); status.setBackgroundColor(0xffe4e7e0); root.addView(status,new LinearLayout.LayoutParams(-1,-2));

        live=new TextView(this); live.setText("PITCH     0.00°\nYAW       0.00°\nROLL      0.00°\nTEMP       0.0°C\nFRAMES 0"); live.setTextSize(18); live.setTypeface(android.graphics.Typeface.MONOSPACE); live.setTextColor(0xff77e49e); live.setBackgroundColor(0xff16241c); live.setPadding(18,18,18,18);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,16,0,18); root.addView(live,lp);

        mouse=new Switch(this); mouse.setText("Virtual mouse output (for Shadow / PC mouse-look)"); mouse.setChecked(true); root.addView(mouse);
        invX=new Switch(this); invX.setText("Invert horizontal"); root.addView(invX);
        invY=new Switch(this); invY.setText("Invert vertical"); root.addView(invY);

        sensLabel=label(root,"Sensitivity: 25 px/degree"); sens=bar(root,5,50,25);
        deadLabel=label(root,"Deadzone: 2.0°/s"); dead=bar(root,0,50,20);
        smoothLabel=label(root,"Smoothing: 0.35"); smooth=bar(root,0,90,35);

        LinearLayout buttons=new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL); buttons.setPadding(0,18,0,8);
        Button start=button("START",0xff2f7d4a); Button stop=button("STOP",0xffa43f35);
        buttons.addView(start,new LinearLayout.LayoutParams(0,-2,1)); buttons.addView(stop,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons);
        LinearLayout buttons2=new LinearLayout(this); buttons2.setOrientation(LinearLayout.HORIZONTAL);
        Button rec=button("RECENTRE",0xff59645b); Button cal=button("RECALIBRATE",0xff59645b);
        buttons2.addView(rec,new LinearLayout.LayoutParams(0,-2,1)); buttons2.addView(cal,new LinearLayout.LayoutParams(0,-2,1)); root.addView(buttons2);

        Button anchor=button("3DoF ANCHOR SCREEN",0xff355f8a);
        LinearLayout.LayoutParams alp=new LinearLayout.LayoutParams(-1,-2); alp.setMargins(0,10,0,0); root.addView(anchor,alp);

        TextView note=new TextView(this); note.setText("Startup calibration: put the glasses down and keep them still for 2 seconds. Once Tracking → virtual mouse appears, open Shadow. For Anchor mode, leave tracking running and tap 3DoF ANCHOR SCREEN. The foreground notification keeps tracking alive in the background."); note.setTextSize(13); note.setPadding(0,20,0,0); root.addView(note);

        start.setOnClickListener(v->ensurePermissionAndStart());
        stop.setOnClickListener(v->sendAction(TrackingService.ACTION_STOP));
        rec.setOnClickListener(v->sendAction(TrackingService.ACTION_RECENTER));
        cal.setOnClickListener(v->sendAction(TrackingService.ACTION_RECALIBRATE));
        anchor.setOnClickListener(v->startActivity(new Intent(this,AnchorActivity.class)));

        SeekBar.OnSeekBarChangeListener listener=new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar s,int p,boolean from) { updateLabels(); }
            public void onStartTrackingTouch(SeekBar s) {}
            public void onStopTrackingTouch(SeekBar s) { sendConfig(); }
        };
        sens.setOnSeekBarChangeListener(listener); dead.setOnSeekBarChangeListener(listener); smooth.setOnSeekBarChangeListener(listener);
        mouse.setOnCheckedChangeListener((b1,c)->sendConfig()); invX.setOnCheckedChangeListener((b1,c)->sendConfig()); invY.setOnCheckedChangeListener((b1,c)->sendConfig());
        setContentView(sv);
    }

    private TextView label(LinearLayout r,String t) { TextView v=new TextView(this); v.setText(t); v.setTextSize(14); v.setPadding(0,14,0,0); r.addView(v); return v; }
    private SeekBar bar(LinearLayout r,int min,int max,int value) { SeekBar b=new SeekBar(this); if(Build.VERSION.SDK_INT>=26)b.setMin(min); b.setMax(max); b.setProgress(value); r.addView(b); return b; }
    private Button button(String text,int colour) { Button b=new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setBackgroundColor(colour); return b; }
    private void updateLabels() {
        sensLabel.setText("Sensitivity: "+sens.getProgress()+" px/degree");
        deadLabel.setText(String.format(Locale.UK,"Deadzone: %.1f°/s",dead.getProgress()/10.0));
        smoothLabel.setText(String.format(Locale.UK,"Smoothing: %.2f",smooth.getProgress()/100.0));
    }

    private UsbDevice findDevice() {
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE);
        for(UsbDevice d:um.getDeviceList().values()) if(d.getVendorId()==VID && d.getProductId()==PID)return d;
        return null;
    }
    private void updateUsbState() { UsbDevice d=findDevice(); status.setText(d==null?"RayNeo not connected":"RayNeo Air 4 Pro detected • press START"); }
    private void ensurePermissionAndStart() {
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE); UsbDevice d=findDevice();
        if(d==null){status.setText("Plug in the RayNeo glasses first");return;}
        if(um.hasPermission(d)){startTracking();return;}
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(USB_PERMISSION).setPackage(getPackageName()),PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        um.requestPermission(d,pi); status.setText("Waiting for USB permission…");
    }
    private Intent configured(String action) {
        return new Intent(this,TrackingService.class).setAction(action)
                .putExtra("sens",(double)sens.getProgress()).putExtra("deadzone",dead.getProgress()/10.0)
                .putExtra("smooth",smooth.getProgress()/100.0).putExtra("invertX",invX.isChecked())
                .putExtra("invertY",invY.isChecked()).putExtra("mouse",mouse.isChecked());
    }
    private void startTracking() {
        Intent i=configured(TrackingService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        status.setText("Starting… keep the glasses still");
    }
    private void sendConfig() { try { startService(configured(TrackingService.ACTION_CONFIG)); } catch(Exception ignored){} }
    private void sendAction(String action) { try { startService(new Intent(this,TrackingService.class).setAction(action)); } catch(Exception ignored){} }

    @Override protected void onResume() {
        super.onResume();
        if (!uiHeartbeatActive) {
            uiHeartbeatActive=true;
            lastSetupUiMs=0L;
            Choreographer.getInstance().postFrameCallback(setupFrameCallback);
        }
    }

    @Override protected void onPause() {
        uiHeartbeatActive=false;
        Choreographer.getInstance().removeFrameCallback(setupFrameCallback);
        super.onPause();
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); updateUsbState(); }
    @Override protected void onDestroy() {
        uiHeartbeatActive=false;
        Choreographer.getInstance().removeFrameCallback(setupFrameCallback);
        try{unregisterReceiver(usbReceiver);}catch(Exception ignored){}
        try{unregisterReceiver(statusReceiver);}catch(Exception ignored){}
        super.onDestroy();
    }
}
