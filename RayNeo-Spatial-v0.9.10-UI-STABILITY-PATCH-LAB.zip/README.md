# RayNeo Spatial v0.9.10 — UI Stability Patch LAB

This is a small stability patch on top of the working v0.9.9 spatial desktop.

## Why this build exists

On the test handheld, the first/setup screens could become extremely slow or unstable when the touchscreen was not being touched, while becoming smooth again as soon as a finger stayed on the display. Spatial Desktop itself remained smooth.

## What changed

- Main setup Activity now uses `FLAG_KEEP_SCREEN_ON`.
- Main setup Activity has a lightweight `Choreographer` heartbeat while it is in the foreground.
- Live setup diagnostics are coalesced and rendered at a maximum of 10 Hz instead of updating directly from each status broadcast.
- Spatial Desktop setup Activity also uses `FLAG_KEEP_SCREEN_ON`.
- Its existing Choreographer loop now explicitly invalidates the foreground window each frame, including before Anchor mode starts.
- The heartbeat is removed when the main setup Activity is paused/destroyed.

## Deliberately unchanged

- RayNeo USB polling and ~118 Hz tracker path
- Tracker filtering / gyro integration
- `/dev/uinput` mouse
- Shizuku isolated process
- independent LEFT/RIGHT VirtualDisplays
- software cursor and click injection
- sticky side-app experiment
- drag/pinch screen placement
- v0.9.9 enlarged vertical spatial world

## Test before publishing

1. Start the app and do **not touch the screen** for 20–30 seconds.
2. Start tracking, then take your hands completely off the handheld.
3. Confirm the setup UI and tracking remain responsive.
4. Open Spatial Desktop and again leave the touchscreen untouched.
5. Confirm that setup remains responsive and does not crash.
6. Start Anchor/Spatial Desktop and verify the known-good v0.9.9 behaviour is unchanged.

If this stays smooth hands-off, this is the candidate build to publish as the next experimental beta.
