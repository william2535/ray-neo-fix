# RayNeo Air 4 Pro Spatial Head Tracking — v0.8 Beta

Experimental standalone Android head tracking and 3DoF anchoring for the RayNeo Air 4 Pro.

## Tested working

- Direct RayNeo Air 4 Pro IMU access over USB
- Android system head mouse
- Smooth 3DoF world-locked screen anchoring
- Pin / recenter
- Adjustable sensitivity and smoothing
- Floating controls over other apps
- Snap Left / Snap Right spatial panels
- Safe stop/restart of Anchor Mode
- No root required
- No Termux required

## Basic setup

1. Install the APK and allow Android to install unknown apps if prompted.
2. Connect the RayNeo Air 4 Pro.
3. Open **RayNeo Spatial Beta**.
4. Start Tracking and grant USB access.
5. Let calibration finish.
6. Start Anchor Mode and approve screen capture.
7. Look where you want the display and press **PIN HERE**.
8. Enable Floating Controls and grant **Display over other apps** when requested.

For the currently tested hardware, both anchor inversion options should be enabled.

## Floating controls

`◀ SNAP | 📌 PIN | SNAP ▶`

These controls stay available while another Android app is open, allowing left/right spatial snapshots without returning to the tracker app.

## Compatibility

This is an experimental beta tested on one Android hardware setup with the RayNeo Air 4 Pro. Android USB, external-display and `/dev/uinput` permissions can vary by device.

If reporting a problem, please include:
- Android device/model
- Android version
- RayNeo glasses model
- whether Head Mouse works
- whether Anchor Mode opens
- whether the external display is detected
- any error shown in the app
