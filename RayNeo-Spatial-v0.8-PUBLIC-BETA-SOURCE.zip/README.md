# RayNeo Air 4 Pro Spatial Head Tracking

Experimental Android head-mouse and 3DoF spatial anchoring for the RayNeo Air 4 Pro.

## Current public beta

**v0.8.0-beta**

The app talks directly to the glasses' USB IMU, provides smooth head tracking, can drive Android's system cursor through `/dev/uinput`, and can pin the captured Android display in a world-fixed 3DoF position.

### Features

- No root required on tested hardware
- No Termux required
- Direct USB IMU decoding
- System-wide head mouse
- Smooth 3DoF anchor mode
- Pin/recenter
- Floating overlay controls
- Left/right spatial snapshots

## Installation

Download the signed APK from the GitHub **Releases** page. Android may ask you to allow installation from unknown sources.

## Important

This is experimental software. It has been hardware-tested with the RayNeo Air 4 Pro on one Android setup, but device-specific permissions and external-display behaviour can differ.

See `RELEASE_NOTES.md` for setup and testing details.
