# RayNeo Spatial v0.9.7 — Vertical Position + Sticky Side Apps LAB

Experimental build based directly on v0.9.6.

## Changes from v0.9.6
- Keeps LEFT/CENTRE/RIGHT panels fixed-size. No gaze zoom/focus scaling.
- Adds **Panel vertical position** slider.
- Slider moves the entire LEFT/CENTRE/RIGHT spatial row up/down together.
- Range is approximately 40% of the display height upward to 40% downward.
- Centre position is the default and does not alter the previous v0.9.6 layout.
- Head-pose vertical anchoring still works around the chosen baseline position.
- Keeps the working RayNeo software crosshair and display-targeted touchscreen taps.
- Keeps isolated Shizuku and experimental sticky side-app repinning / RETURN LEFT APP / RETURN RIGHT APP.

## Suggested test
1. Start Shizuku and leave it running.
2. Start tracking and Spatial Desktop.
3. Create LEFT/RIGHT displays and launch apps.
4. Move **Panel vertical position** from centre toward UP and DOWN.
5. Confirm all three panels move together and remain the same size.
6. Confirm head anchoring remains smooth.
7. Confirm CONTROL LEFT/RIGHT and CLICK SELECTED still work as before.

Public v0.8 should remain the stable release while this is tested.
