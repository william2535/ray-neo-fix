package com.willflood.rayneo;

/** Checks the mouse path sample-for-sample against the original axis mapping and rate filter. */
public final class MouseRateTest {
    public static void main(String[] args) {
        Tracker mouse = new Tracker();
        double bx=.12, by=-.08, bz=.16;
        mouse.setBias(bx,by,bz);
        double[] expected = new double[3];
        for(int i=0;i<120;i++) {
            // Sub-deadzone, ordinary aim, pure opposite Y/Z roll, then release. All in raw axes.
            double gx = i<12 ? .75 : i<55 ? -13 : 0;
            double gy = i<12 ? .25 : i<55 ? 6 : i<80 ? 9 : 0;
            double gz = i<12 ? .25 : i<55 ? 2.5 : i<80 ? -9 : 0;
            mouse.update(gx+bx,gy+by,gz+bz);
            double[] mapped = {gx,gy+gz,gy-gz};
            for(int axis=0;axis<3;axis++) {
                double admitted = Math.abs(mapped[axis])<2 ? 0 : mapped[axis];
                expected[axis] = .35*expected[axis] + (1-.35)*admitted;
                double actual=mouse.rate[axis];
                if (!Double.isFinite(actual) || Math.abs(expected[axis]-actual)>1e-9)
                    throw new AssertionError("mouse rate mismatch at sample "+i+", axis "+axis+": "+actual);
            }
        }
        System.out.println("Mouse rates match the original mapping, deadzone and smoothing over 120 samples.");
    }
}
