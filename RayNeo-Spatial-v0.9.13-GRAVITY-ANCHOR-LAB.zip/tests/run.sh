#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
src=app/src/main/java/com/willflood/rayneo
out=$(mktemp -d)
trap 'rm -rf "$out"' EXIT
javac -d "$out" "$src/SpatialPose.java" "$src/StillCalibration.java" "$src/Tracker.java" tests/*.java
java -cp "$out" com.willflood.rayneo.SpatialPoseTest
java -cp "$out" com.willflood.rayneo.MouseRateTest
