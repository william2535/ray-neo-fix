package com.willflood.rayneo;

import java.util.Locale;

/** Replays synthetic, physically consistent IMU samples. Run with assertions enabled or disabled. */
public final class SpatialPoseTest {
    private static final double G = 9.81;
    private static final double[] RIGHT = {1, 0, 0};
    // Nominal head axes in IMU coordinates. X is pitch, yaw combines Y and Z.
    private static final double NORM = Math.hypot(1, 0.28);
    private static final double[] UP = {0, 1 / NORM, 0.28 / NORM};
    private static final double[] NEGATIVE_FORWARD = {0, 0.28 / NORM, -1 / NORM};
    private static int checks;

    private static void near(String test, double actual, double expected, double tolerance) {
        if (!Double.isFinite(actual) || Math.abs(actual - expected) > tolerance)
            throw new AssertionError(String.format(Locale.ROOT, "%s: expected %.4f ± %.4f, got %.4f",
                    test, expected, tolerance, actual));
        checks++;
    }

    private static double[] scale(double[] vector, double factor) {
        return new double[]{vector[0]*factor, vector[1]*factor, vector[2]*factor};
    }

    // Rodrigues rotation of the gravity vector into a moving sensor frame.
    // The measured world vector rotates opposite to the physical positive body turn.
    private static double[] bodyGravity(double[] axis, double degrees) {
        double radians = Math.toRadians(-degrees), c = Math.cos(radians), s = Math.sin(radians);
        double dot = axis[0]*UP[0] + axis[1]*UP[1] + axis[2]*UP[2];
        return new double[]{
                G*(UP[0]*c + (axis[1]*UP[2] - axis[2]*UP[1])*s + axis[0]*dot*(1-c)),
                G*(UP[1]*c + (axis[2]*UP[0] - axis[0]*UP[2])*s + axis[1]*dot*(1-c)),
                G*(UP[2]*c + (axis[0]*UP[1] - axis[1]*UP[0])*s + axis[2]*dot*(1-c))
        };
    }

    private final SpatialPose pose = new SpatialPose();
    private final double dt;
    private final int hz;

    private SpatialPoseTest(int hz, double[] initialGravity) {
        this.hz = hz;
        dt = 1.0 / hz;
        pose.reset(initialGravity[0], initialGravity[1], initialGravity[2]);
    }

    private void step(double[] rate, double[] gravity) {
        pose.update(rate[0], rate[1], rate[2], gravity[0], gravity[1], gravity[2], dt);
    }

    private void hold(double[] gravity, int seconds) {
        double[] stopped = new double[3];
        for (int i=0; i<hz*seconds; i++) step(stopped, gravity);
    }

    private void rotate(double[] axis, double start, double end, int seconds) {
        double speed = (end-start)/seconds;
        double[] rate = scale(axis, speed);
        for (int i=1; i<=hz*seconds; i++)
            step(rate, bodyGravity(axis, start+speed*i*dt));
    }

    private static void slowPitchAndRecentre(int hz, double start, double end) {
        SpatialPoseTest trace = new SpatialPoseTest(hz, bodyGravity(RIGHT, start));
        trace.rotate(RIGHT, start, end, 5);
        trace.hold(bodyGravity(RIGHT, end), 3);
        near("slow physical nod", trace.pose.pitch, end-start, 0.5);
        near("pitch leaves yaw steady", trace.pose.yaw, 0, 0.1);
        trace.pose.recentre();
        trace.hold(bodyGravity(RIGHT, end), 3);
        near("new tilted centre holds", trace.pose.pitch, 0, 0.15);
        trace.rotate(RIGHT, end, start, 5);
        trace.hold(bodyGravity(RIGHT, start), 3);
        near("opposite signed return from centre", trace.pose.pitch, start-end, 0.5);
    }

    private static void rolled(int hz) {
        SpatialPoseTest trace = new SpatialPoseTest(hz, scale(UP, G));
        trace.rotate(NEGATIVE_FORWARD, 0, 24, 2);
        trace.hold(bodyGravity(NEGATIVE_FORWARD, 24), 3);
        near("right roll sign", trace.pose.roll, 24, 0.5);
        near("roll leaves pitch steady", trace.pose.pitch, 0, 0.15);
        near("roll leaves heading steady", trace.pose.yaw, 0, 0.15);
    }

    private static void yawDuringTilt(int hz) {
        double[] gravity = bodyGravity(RIGHT, 27);
        SpatialPoseTest trace = new SpatialPoseTest(hz, gravity);
        // Yaw in the world rotates around measured gravity, even after nodding.
        double[] yawRate = scale(gravity, 40/G);
        for(int i=0; i<10*hz; i++) trace.step(yawRate, gravity);
        trace.hold(gravity, 4);
        near("relative heading is continuous past 360", trace.pose.yaw, 400, 1);
        near("yaw about vertical preserves elevation", trace.pose.pitch, 0, 0.25);
        trace.pose.recentre();
        trace.hold(gravity, 3);
        near("explicit heading recenter", trace.pose.yaw, 0, 0.1);
        // Gravity cannot distinguish these two trajectories. A yaw bias must still integrate.
        for (int i=0; i<hz*20; i++) trace.step(scale(gravity,0.5/G), gravity);
        near("constant gyro-only yaw remains observable only relatively", trace.pose.yaw, 10, 1);
    }

    private static void rejectAcceleration(int hz) {
        double[] level = scale(UP, G), stopped = new double[3];
        SpatialPoseTest trace = new SpatialPoseTest(hz, level);
        for (int i=0; i<2*hz; i++) trace.step(stopped, scale(RIGHT, 2*G));
        near("high-force translation", trace.pose.pitch, 0, 0.25);
        near("high-force translation roll", trace.pose.roll, 0, 0.25);
        trace.step(stopped, new double[]{Double.NaN, G, 0});
        near("NaN accelerometer leaves pose finite", trace.pose.pitch, 0, 0.5);
        for (int i=0;i<hz;i++) trace.step(scale(RIGHT,25), new double[3]);
        near("gyro survives free-fall", trace.pose.pitch, 25, 1.5);
        trace.hold(bodyGravity(RIGHT,25), 5);
        near("gravity reacquisition", trace.pose.pitch, 25, 0.5);
    }

    private static void burstAndRecovery(int hz) {
        double[] zero = new double[3], level = scale(UP,G), falseTilt = bodyGravity(RIGHT,45);
        SpatialPoseTest trace = new SpatialPoseTest(hz,level);
        for (int i=0;i<hz/3;i++) trace.step(zero,falseTilt);
        near("short same-magnitude false tilt",trace.pose.pitch,0,0.3);
        if (trace.pose.gravityTrusted) throw new AssertionError("brief inconsistent gravity was trusted");
        trace.hold(level,2);
        // Simulate an orientation change during a USB packet gap. No rotation could be integrated.
        trace.pose.update(250,0,0,falseTilt[0],falseTilt[1],falseTilt[2],.45);
        near("long packet gap ignored",trace.pose.pitch,0,.4);
        trace.hold(falseTilt,10);
        near("large consistent discrepancy reacquired",trace.pose.pitch,45,0.8);
        if (!trace.pose.gravityTrusted) throw new AssertionError("stable gravity did not recover");
    }

    // Ground truth is independently prescribed in yaw/elevation/bank coordinates.
    // R = R_up(yaw) R_right(pitch) R_forward(-roll). Differentiate that product
    // for body gyro rates, and inverse-rotate world up for the accelerometer.
    private static void combinedHeadMotion(int hz) {
        SpatialPoseTest t = new SpatialPoseTest(hz,scale(UP,G));
        double maxPitch=0, maxYaw=0, maxRoll=0;
        for (int i=1; i<=20*hz; i++) {
            double now=i*t.dt, mid=(i-.5)*t.dt;
            double pitch=22*Math.sin(.8*now), yaw=62*Math.sin(.51*now), roll=16*Math.sin(1.27*now);
            double p=Math.toRadians(22*Math.sin(.8*mid)), r=Math.toRadians(16*Math.sin(1.27*mid));
            double dp=22*.8*Math.cos(.8*mid), dy=62*.51*Math.cos(.51*mid), dr=16*1.27*Math.cos(1.27*mid);
            double gx=dp*Math.cos(r) - dy*Math.cos(p)*Math.sin(r);
            double gy=dp*Math.sin(r) + dy*Math.cos(p)*Math.cos(r);
            double gz=-dr-dy*Math.sin(p);
            p=Math.toRadians(pitch); r=Math.toRadians(roll);
            double ax=-Math.cos(p)*Math.sin(r)*G, ay=Math.cos(p)*Math.cos(r)*G, az=-Math.sin(p)*G;
            t.pose.update(gx,gy*UP[1]-gz*UP[2],gy*UP[2]+gz*UP[1],
                    ax,ay*UP[1]-az*UP[2],ay*UP[2]+az*UP[1],t.dt);
            maxPitch=Math.max(maxPitch,Math.abs(t.pose.pitch-pitch));
            maxYaw=Math.max(maxYaw,Math.abs(t.pose.yaw-yaw));
            maxRoll=Math.max(maxRoll,Math.abs(t.pose.roll-roll));
        }
        near("combined nod, yaw and roll: worst pitch error",maxPitch,0,.2);
        near("combined nod, yaw and roll: worst yaw error",maxYaw,0,.2);
        near("combined nod, yaw and roll: worst roll error",maxRoll,0,.2);
    }

    private static void measuredMountAndTiming() {
        // Reported Y and Z projections for the project's flat, lenses-down sample.
        double ay=8.24, az=5.29, duration=0;
        SpatialPose pose=new SpatialPose();
        pose.reset(0,ay,az);
        for (int i=0; i<600; i++) {
            double dt=(i%3==0 ? .013 : i%3==1 ? .004 : .008);
            duration+=dt;
            double angle=Math.toRadians(-3*duration);
            double y=ay*Math.cos(angle)-az*Math.sin(angle);
            double z=ay*Math.sin(angle)+az*Math.cos(angle);
            pose.update(3,0,0,0,y,z,dt);
        }
        near("measured mounting angle, jittered cadence",pose.pitch,3*duration,0.3);
        near("measured mounting angle, no yaw leakage",pose.yaw,0,0.3);
        // Reversing accelerometer polarity must not reverse physical pitch.
        pose.reset(0,-ay,-az);
        for (int i=1; i<=240; i++) {
            double angle=Math.toRadians(-i/120.0*6);
            pose.update(6,0,0,0,-ay*Math.cos(angle)+az*Math.sin(angle),
                    -ay*Math.sin(angle)-az*Math.cos(angle),1.0/120);
        }
        near("opposite accelerometer polarity",pose.pitch,12,0.3);
    }

    private static void calibrate(int hz) {
        double dt=1.0/hz;
        StillCalibration c = new StillCalibration();
        double[] up = scale(UP,G);
        boolean ready=false;
        for(int i=0; i<3*hz; i++) ready |= c.add(10,0,0,up[0],up[1],up[2],dt);
        if(ready) throw new AssertionError("head turning during startup must not be calibrated as bias");
        for(int i=0; i<hz/2; i++) c.add(.15,-.1,.05,up[0],up[1],up[2],dt);
        c.add(0,0,0,0,0,0,dt);
        for(int i=0; i<hz; i++) ready |= c.add(.15,-.1,.05,up[0],up[1],up[2],dt);
        if(ready) throw new AssertionError("samples separated by free-fall cannot form one still window");
        for(int i=0; i<3*hz && !ready; i++) ready=c.add(.15,-.1,.05,up[0],up[1],up[2],dt);
        if(!ready) throw new AssertionError("steady valid startup never accepted");
        near("calibrated gyro X",c.gyroBias[0],.15,1e-8);
        near("calibrated gyro Y",c.gyroBias[1],-.1,1e-8);
        near("calibrated gyro Z",c.gyroBias[2],.05,1e-8);
        for(int k=0;k<3;k++) near("calibrated gravity "+k,c.gravity[k],up[k],1e-8);
    }

    // v0.9.12 Tracker.update pitch channel, for these two constant-rate fixtures only.
    // Starts with zero calibrated bias. The first trace is entirely within the deadzone.
    // The second has continuous yaw, so the original stationary adaptation never runs.
    // Original source is in the v0.9.12 ZIP at Git commit bd9f27e.
    private static double originalPitch(double gyroX, double deadzone, int hz, int seconds) {
        double admitted = Math.abs(gyroX) < deadzone ? 0 : gyroX;
        double angle = 0, rate = 0;
        for (int i=0; i<seconds*hz; i++) {
            rate = rate*.35 + admitted*(1-.35);
            angle += rate/hz;
        }
        return angle;
    }

    private static void legacyComparison() {
        final int hz=118;
        double[] level=scale(UP,G);
        SpatialPoseTest trace=new SpatialPoseTest(hz,level);
        double oldSlowPitch=originalPitch(1,2,hz,6);
        for(int i=1;i<=hz*6;i++) {
            double truePitch=i/(double)hz;
            trace.step(RIGHT, bodyGravity(RIGHT,truePitch));
        }
        near("spatial follows slow physical motion",trace.pose.pitch,6,0.4);
        near("original slow nod fixture",oldSlowPitch,0,0.001);
        System.out.printf(Locale.ROOT,"6 s slow nod at 1°/s (default mouse deadzone 2°/s): original %.2f°, fused %.2f°.%n",oldSlowPitch,trace.pose.pitch);

        trace=new SpatialPoseTest(hz,level);
        double oldBiasedPitch=originalPitch(0.5,0,hz,60);
        double[] gyro=scale(UP,6); // Deliberate constant yaw, zero physical pitch.
        gyro[0]=0.5; // Simulated post-calibration pitch bias.
        double peakPitch=0;
        for(int i=0;i<hz*60;i++) {
            trace.step(gyro,level);
            peakPitch=Math.max(peakPitch, Math.abs(trace.pose.pitch));
        }
        near("legacy integrates residual x-rate",oldBiasedPitch,30,0.1);
        near("fused elevation with mixed motion and bias",trace.pose.pitch,0,2.0);
        near("peak tilt error during biased yaw",peakPitch,0,1.5);
        System.out.printf(Locale.ROOT,"60 s yaw at 6°/s, residual pitch bias +0.5°/s, legacy deadzone 0: final error %.2f° original, %.3f° fused (fused peak %.3f°).%n",
                oldBiasedPitch,trace.pose.pitch,peakPitch);
    }

    public static void main(String[] args) {
        for(int hz: new int[]{60,118,240}) {
            slowPitchAndRecentre(hz,0,6);
            slowPitchAndRecentre(hz,-22,-28);
            rolled(hz);
            yawDuringTilt(hz);
            rejectAcceleration(hz);
            calibrate(hz);
            burstAndRecovery(hz);
            combinedHeadMotion(hz);
        }
        measuredMountAndTiming();
        legacyComparison();
        System.out.println("All motion traces passed ("+checks+" numeric checks).");
    }
}
