# Replaying IMU traces

From the unpacked Android project, use a JDK to run the deterministic synthetic traces.

```sh
sh tests/run.sh
```

The suite generates stationary gravity in sensor coordinates and rotates it independently of the fusion implementation. It checks signed pitch and roll, heading through a full turn, recentering, different sample rates, acceleration rejection, and startup calibration. Two traces print a comparison against the v0.9.12 zero-bias pitch-channel recurrence, with the original mouse deadzone specified. Both baseline values were checked against the archived v0.9.12 implementation. These are simulations and do not measure tracking latency or accuracy on physical glasses.
