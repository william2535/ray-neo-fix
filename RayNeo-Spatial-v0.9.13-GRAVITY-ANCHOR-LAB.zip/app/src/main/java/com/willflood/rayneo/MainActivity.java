package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import android.view.*;
import android.widget.*;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int VID=0x1BBB, PID=0xAF50;
    private static final String USB_PERMISSION="com.willflood.rayneo.USB_PERMISSION";
    private TextView status, live, sensLabel, deadLabel, smoothLabel;
    private SeekBar sens, dead, smooth;
    private Switch mouse, invX, invY;

    private final DecimalFormat angles = new DecimalFormat("+0.00;-0.00", DecimalFormatSymbols.getInstance(Locale.UK));
    private final DecimalFormat temperature = new DecimalFormat("0.0", DecimalFormatSymbols.getInstance(Locale.UK));
    private TrackingService.Readings renderedStatus, renderedReadings;
    private boolean startRequested;

    // v0.9.11: lightweight no-touch UI keep-alive. Unlike v0.9.10 this does NOT
    // invalidate the whole window every vsync; it only nudges a 2x2 px view at 20 Hz.
    private final Handler uiKeepAliveHandler = new Handler(Looper.getMainLooper());
    private View uiKeepAliveView;
    private boolean uiKeepAliveRunning = false;
    private boolean uiKeepAliveFlip = false;
    private final Runnable uiKeepAliveTick = new Runnable() {
        @Override public void run() {
            if (!uiKeepAliveRunning || isFinishing() || isDestroyed()) return;
            if (uiKeepAliveView != null) {
                uiKeepAliveFlip = !uiKeepAliveFlip;
                uiKeepAliveView.setTranslationX(uiKeepAliveFlip ? 1f : 0f);
            }
            renderLatestStatus();
            uiKeepAliveHandler.postDelayed(this, 50L);
        }
    };

    private final BroadcastReceiver usbReceiver=new BroadcastReceiver() {
        @Override public void onReceive(Context c,Intent i) {
            if (USB_PERMISSION.equals(i.getAction())) {
                // The immutable permission intent need not carry extras; consult the grant itself.
                UsbDevice d = findDevice();
                UsbManager usb = (UsbManager)getSystemService(USB_SERVICE);
                if (d != null && usb.hasPermission(d)) startTracking();
                else showStatus(d == null ? "RayNeo not connected" : "USB permission denied");
            }
        }
    };

    private void renderLatestStatus() {
        TrackingService.Readings sample = TrackingService.latestReadings;
        if (sample == null || !uiKeepAliveRunning) return;
        if (renderedStatus != sample) {
            renderedStatus = sample;
            startRequested = false;
            if (!sample.status.contentEquals(status.getText())) status.setText(sample.status);
        }
        if (renderedReadings == sample || !live.isShown()) return;
        renderedReadings = sample;
        live.setText("PITCH   " + angles.format(sample.pitch) + "°\n"
                + "YAW     " + angles.format(sample.yaw) + "°\n"
                + "ROLL    " + angles.format(sample.roll) + "°\n"
                + "TEMP    " + temperature.format(sample.temp) + "°C\n"
                + "FRAMES  " + sample.frames);
    }

    private void showStatus(String text) {
        renderedStatus = TrackingService.latestReadings;
        status.setText(text);
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams attrs=getWindow().getAttributes();
        attrs.preferredRefreshRate=60f;
        getWindow().setAttributes(attrs);
        registerReceiver(usbReceiver,new IntentFilter(USB_PERMISSION));
        buildUi();
        updateUsbState();
    }

    private void buildUi() {
        setContentView(R.layout.tracker_main);
        android.content.res.Configuration config = getResources().getConfiguration();
        if (config.screenWidthDp >= 640 && config.fontScale <= 1.3f) {
            LinearLayout columns = findViewById(R.id.setup_columns);
            columns.setOrientation(LinearLayout.HORIZONTAL);
            columns.setBaselineAligned(false);
            LinearLayout.LayoutParams left = new LinearLayout.LayoutParams(0, -2, 1);
            left.setMarginEnd(Math.round(12 * getResources().getDisplayMetrics().density));
            findViewById(R.id.session_column).setLayoutParams(left);
            findViewById(R.id.settings_column).setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1));
        }

        status = findViewById(R.id.tracker_status);
        live = findViewById(R.id.live);
        uiKeepAliveView = findViewById(R.id.keep_alive);
        sensLabel = findViewById(R.id.sensitivity_label);
        deadLabel = findViewById(R.id.deadzone_label);
        smoothLabel = findViewById(R.id.smoothing_label);
        sens = findViewById(R.id.sensitivity);
        dead = findViewById(R.id.deadzone);
        smooth = findViewById(R.id.smoothing);
        mouse = findViewById(R.id.mouse);
        invX = findViewById(R.id.invert_x);
        invY = findViewById(R.id.invert_y);

        SharedPreferences prefs = getPreferences(MODE_PRIVATE);
        mouse.setChecked(prefs.getBoolean("mouse", true));
        invX.setChecked(prefs.getBoolean("invertX", false));
        invY.setChecked(prefs.getBoolean("invertY", false));
        sens.setProgress(prefs.getInt("sensitivity", 25));
        dead.setProgress(prefs.getInt("deadzone", 20));
        smooth.setProgress(prefs.getInt("smoothing", 35));
        updateLabel(sens);
        updateLabel(dead);
        updateLabel(smooth);

        findViewById(R.id.start).setOnClickListener(v -> ensurePermissionAndStart());
        findViewById(R.id.stop).setOnClickListener(v -> sendAction(TrackingService.ACTION_STOP));
        findViewById(R.id.recentre).setOnClickListener(v -> sendAction(TrackingService.ACTION_RECENTER));
        findViewById(R.id.recalibrate).setOnClickListener(v -> sendAction(TrackingService.ACTION_RECALIBRATE));
        findViewById(R.id.open_spatial).setOnClickListener(v -> startActivity(new Intent(this, AnchorActivity.class)));

        Button readings = findViewById(R.id.toggle_readings);
        setReadingsVisible(readings, prefs.getBoolean("showReadings", true));
        readings.setOnClickListener(v -> {
            boolean show = live.getVisibility() != View.VISIBLE;
            setReadingsVisible(readings, show);
            prefs.edit().putBoolean("showReadings", show).apply();
            if (show) renderLatestStatus();
        });

        SeekBar.OnSeekBarChangeListener tune = new SeekBar.OnSeekBarChangeListener() {
            private boolean dragging;
            @Override public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                updateLabel(bar);
                // D-pad and accessibility adjustments do not start a touch gesture.
                if (fromUser && !dragging) saveTuning();
            }
            @Override public void onStartTrackingTouch(SeekBar bar) { dragging = true; }
            @Override public void onStopTrackingTouch(SeekBar bar) { dragging = false; saveTuning(); }
        };
        sens.setOnSeekBarChangeListener(tune);
        dead.setOnSeekBarChangeListener(tune);
        smooth.setOnSeekBarChangeListener(tune);
        CompoundButton.OnCheckedChangeListener toggle = (button, checked) -> saveTuning();
        mouse.setOnCheckedChangeListener(toggle);
        invX.setOnCheckedChangeListener(toggle);
        invY.setOnCheckedChangeListener(toggle);
    }

    private void setReadingsVisible(Button button, boolean show) {
        live.setVisibility(show ? View.VISIBLE : View.GONE);
        button.setText(show ? R.string.tracker_live_hide : R.string.tracker_live_show);
    }

    private void updateLabel(SeekBar bar) {
        if (bar == sens) sensLabel.setText(getString(R.string.tracker_sensitivity, bar.getProgress()));
        else if (bar == dead) deadLabel.setText(getString(R.string.tracker_deadzone, bar.getProgress() / 10.0));
        else smoothLabel.setText(getString(R.string.tracker_smoothing, bar.getProgress() / 100.0));
    }

    private void saveTuning() {
        getPreferences(MODE_PRIVATE).edit()
                .putBoolean("mouse", mouse.isChecked()).putBoolean("invertX", invX.isChecked())
                .putBoolean("invertY", invY.isChecked()).putInt("sensitivity", sens.getProgress())
                .putInt("deadzone", dead.getProgress()).putInt("smoothing", smooth.getProgress()).apply();
        sendConfig();
    }

    private UsbDevice findDevice() {
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE);
        for(UsbDevice d:um.getDeviceList().values()) if(d.getVendorId()==VID && d.getProductId()==PID)return d;
        return null;
    }
    private void updateUsbState() {
        if (TrackingService.isTracking() || startRequested) return;
        // An inactive service can still hold readings from before this activity opened.
        renderedReadings = TrackingService.latestReadings;
        UsbDevice d = findDevice();
        showStatus(d == null ? "RayNeo not connected" : "RayNeo Air 4 Pro detected • press Start");
    }
    private void ensurePermissionAndStart() {
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE); UsbDevice d=findDevice();
        if(d==null){showStatus("Plug in the RayNeo glasses first");return;}
        if(um.hasPermission(d)){startTracking();return;}
        PendingIntent pi=PendingIntent.getBroadcast(this,0,new Intent(USB_PERMISSION).setPackage(getPackageName()),PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        um.requestPermission(d,pi); showStatus("Waiting for USB permission…");
    }
    private Intent configured(String action) {
        return new Intent(this,TrackingService.class).setAction(action)
                .putExtra("sens",(double)sens.getProgress()).putExtra("deadzone",dead.getProgress()/10.0)
                .putExtra("smooth",smooth.getProgress()/100.0).putExtra("invertX",invX.isChecked())
                .putExtra("invertY",invY.isChecked()).putExtra("mouse",mouse.isChecked());
    }
    private void startTracking() {
        Intent i=configured(TrackingService.ACTION_START);
        if(Build.VERSION.SDK_INT>=26) startForegroundService(i); else startService(i);
        startRequested = true;
        showStatus("Starting… keep the glasses still");
    }
    private void sendConfig() {
        if (TrackingService.isTracking() || startRequested) startService(configured(TrackingService.ACTION_CONFIG));
    }
    private void sendAction(String action) {
        if (TrackingService.isTracking() || startRequested) {
            startService(new Intent(this,TrackingService.class).setAction(action));
        } else if (TrackingService.ACTION_STOP.equals(action)) {
            // A failed USB startup can leave the foreground service waiting.
            stopService(new Intent(this, TrackingService.class));
            showStatus("Tracking stopped");
        } else {
            showStatus("Start tracking first");
        }
    }

    @Override protected void onResume() {
        super.onResume();
        uiKeepAliveRunning=true;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        uiKeepAliveHandler.post(uiKeepAliveTick);
        // Returning to the normal setup screen should always restore the proven centre mouse.
        if (mouse!=null && mouse.isChecked()) sendConfig();
    }
    @Override protected void onPause() {
        uiKeepAliveRunning=false;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        super.onPause();
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); updateUsbState(); }
    @Override protected void onDestroy() {
        uiKeepAliveRunning=false;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        try{unregisterReceiver(usbReceiver);}catch(Exception ignored){}
        super.onDestroy();
    }
}
