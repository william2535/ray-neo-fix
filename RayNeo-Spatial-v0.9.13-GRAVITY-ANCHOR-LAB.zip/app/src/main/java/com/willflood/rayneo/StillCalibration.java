package com.willflood.rayneo;

/** Collects one stationary reference in the glasses' raw sensor axes. */
final class StillCalibration {
    private static final double REQUIRED_SECONDS = 1.5;
    private static final int MIN_SAMPLES = 30;
    private static final double MAX_GAP_SECONDS = 0.1;
    private static final double MAX_GYRO_DPS = 3.0;
    private static final double MAX_GYRO_CHANGE_DPS = 1.25;
    private static final double MAX_ACCEL_CHANGE_MS2 = 0.55;

    final double[] gyroBias = new double[3];
    final double[] gravity = new double[3];
    private final double[] firstGyro = new double[3], firstAccel = new double[3];
    private final double[] sumGyro = new double[3], sumAccel = new double[3];
    private int samples;
    private double elapsed;
    private boolean ready;

    // dt is the measured time between packets. A new attempt uses a new instance.
    boolean add(double gx, double gy, double gz, double ax, double ay, double az, double dt) {
        if (ready) return true;
        double gyro2 = gx*gx + gy*gy + gz*gz;
        double accel2 = ax*ax + ay*ay + az*az;
        // Comparisons written this way also reject NaN, infinities, and overflow.
        if (!(dt > 0 && dt <= MAX_GAP_SECONDS && gyro2 <= MAX_GYRO_DPS*MAX_GYRO_DPS
                && accel2 >= 8.81*8.81 && accel2 <= 10.81*10.81)) {
            samples = 0;
            return false;
        }

        if (samples == 0 || changed(firstGyro, gx, gy, gz, MAX_GYRO_CHANGE_DPS)
                || changed(firstAccel, ax, ay, az, MAX_ACCEL_CHANGE_MS2)) {
            // The current plausible sample can start a new window after a shift.
            firstGyro[0] = sumGyro[0] = gx;
            firstGyro[1] = sumGyro[1] = gy;
            firstGyro[2] = sumGyro[2] = gz;
            firstAccel[0] = sumAccel[0] = ax;
            firstAccel[1] = sumAccel[1] = ay;
            firstAccel[2] = sumAccel[2] = az;
            samples = 1;
            elapsed = 0;
            return false;
        }

        sumGyro[0] += gx;
        sumGyro[1] += gy;
        sumGyro[2] += gz;
        sumAccel[0] += ax;
        sumAccel[1] += ay;
        sumAccel[2] += az;
        samples++;
        elapsed += dt;
        if (elapsed < REQUIRED_SECONDS || samples < MIN_SAMPLES) return false;
        for (int i = 0; i < 3; i++) {
            gyroBias[i] = sumGyro[i] / samples;
            gravity[i] = sumAccel[i] / samples;
        }
        ready = true;
        return true;
    }

    private static boolean changed(double[] first, double x, double y, double z, double limit) {
        double dx = x - first[0], dy = y - first[1], dz = z - first[2];
        return dx*dx + dy*dy + dz*dz > limit*limit;
    }
}
