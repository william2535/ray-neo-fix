package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/**
 * RayNeo Spatial Desktop v0.9.11 UI STABILITY + MOUSE RESTORE LAB.
 *
 * Important architectural change from v0.6:
 * v0.6 translated full-display child views outside a display-sized parent. On some Android
 * compositors that effectively behaves like one moving panel. v0.7 instead creates a large
 * world canvas (~5 display widths), places three real panels at fixed world coordinates, and
 * moves the camera (the world container) from the Air 4 Pro head pose.
 *
 * Centre = live Android capture. Left/right = independent app-owned VirtualDisplays.
 * v0.9.9 keeps the proven RayNeo-drawn software cursor, sticky side-app path, and v0.9.8 placement gestures, but expands the spatial world vertically so panels are not clipped at the original display-height boundary.
 * It replaces the rigid row-layout sliders with a direct placement editor:
 * select LEFT/CENTRE/RIGHT, drag on a circular touch pad to place that screen in X/Y,
 * and pinch on the pad to resize only the selected screen. Layout changes are user-driven only.
 */
public class AnchorActivity extends Activity {
    public static final String ACTION_OVERLAY = "com.willflood.rayneo.ANCHOR_OVERLAY_ACTION";
    public static final String EXTRA_COMMAND = "command";
    public static final String CMD_SNAP_LEFT = "snap_left";
    public static final String CMD_SNAP_RIGHT = "snap_right";
    public static final String CMD_PIN = "pin";
    public static final String CMD_STOP = "stop";

    private static final int REQ_CAPTURE = 4401;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;
    private static final long UI_INTERVAL_MS = 250L;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;

    // v0.9.1 LAB ONLY. These are never created automatically.
    // Keeping them completely idle preserves the proven v0.8 tracking path until a test button is pressed.
    private VirtualDisplay leftLabDisplay, rightLabDisplay;
    private Surface leftLabSurface, rightLabSurface;
    private int leftLabWidth, leftLabHeight, rightLabWidth, rightLabHeight;
    private SpatialPresentation presentation;

    private TextView status, poseInfo, renderInfo, labInfo;
    private boolean overlayPermissionRequested;

    // Tiny setup-only UI keep-alive. This avoids v0.9.10's full-window every-vsync invalidation.
    private final Handler uiKeepAliveHandler = new Handler(Looper.getMainLooper());
    private View uiKeepAliveView;
    private boolean uiKeepAliveRunning=false, uiKeepAliveFlip=false;
    private final Runnable uiKeepAliveTick=new Runnable(){
        @Override public void run(){
            if(!uiKeepAliveRunning||isFinishing()||isDestroyed())return;
            if(uiKeepAliveView!=null){uiKeepAliveFlip=!uiKeepAliveFlip;uiKeepAliveView.setTranslationX(uiKeepAliveFlip?1f:0f);}
            uiKeepAliveHandler.postDelayed(this,50L);
        }
    };

    // v0.9.6 fixed panels + software-cursor control. No focus scaling or depth code.
    private boolean stickySideApps = true;
    private String leftAppPackage, rightAppPackage;
    private String leftAppComponent, rightAppComponent;
    private int controlTarget = 0; // 0 = centre/native uinput, 1 = left, 2 = right
    private int leftCursorDisplayX, leftCursorDisplayY, rightCursorDisplayX, rightCursorDisplayY;
    private boolean leftCursorInside, rightCursorInside;

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_OVERLAY.equals(intent.getAction())) return;
            String command = intent.getStringExtra(EXTRA_COMMAND);
            if (CMD_SNAP_LEFT.equals(command)) snapshot(true);
            else if (CMD_SNAP_RIGHT.equals(command)) snapshot(false);
            else if (CMD_PIN.equals(command)) pinHere();
            else if (CMD_STOP.equals(command)) stopAnchor();
        }
    };

    private final BroadcastReceiver shizukuResultReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ShizukuBridgeActivity.ACTION_RESULT.equals(intent.getAction())) return;
            boolean ok=intent.getBooleanExtra(ShizukuBridgeActivity.EXTRA_OK,false);
            String result=intent.getStringExtra(ShizukuBridgeActivity.EXTRA_RESULT);
            String side=intent.getStringExtra(ShizukuBridgeActivity.EXTRA_SIDE);
            setLabStatus((ok?"SHIZUKU OK — ":"SHIZUKU ERROR — ") + (result==null?"(no result)":result));
            if(ok && side!=null && presentation!=null){
                boolean left="LEFT".equals(side);
                TextView label=left?presentation.leftLabel:presentation.rightLabel;
                TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
                if(tv!=null)tv.setVisibility(View.VISIBLE);
                if(label!=null)label.setVisibility(View.GONE);
            }
        }
    };

    private volatile float latestPitch, latestYaw;
    private float filteredPitch, filteredYaw;
    private float anchorPitch, anchorYaw;
    private boolean havePose;

    private boolean anchorRunning, stopping;
    private boolean invertX = true, invertY = true; // proven on user's Air 4 Pro

    // v0.9.8 direct screen placement. The base geometry matches the comfortable v0.9.7 layout.
    private static final int SCREEN_LEFT = 0, SCREEN_CENTRE = 1, SCREEN_RIGHT = 2;
    private int layoutSelected = SCREEN_CENTRE;
    private boolean layoutLocked = false;
    private final float[] panelOffsetX = new float[]{0f,0f,0f}; // screen-width units from each default position
    private final float[] panelOffsetY = new float[]{0f,0f,0f}; // screen-height units from each default position
    private final float[] panelUserScale = new float[]{1f,1f,1f};
    private final float panelScale = 0.712f;
    private final float panelSpacingScreens = 1.17f;
    private LayoutPadView layoutPad;
    private TextView layoutInfo;
    private Button layoutLockButton;

    private float hFovDeg = 46f, vFovDeg = 27f;
    private long lastFrameNs, lastUiMs;
    private float lastDx, lastDy;

    private static final long DRIFT_CHECK_MS = 60_000, MAX_SAMPLE_GAP_MS = 750;
    private Button driftButton;
    private TextView driftResult;
    private boolean measuringDrift;
    private long driftStartMs, lastDriftSampleMs, lastDriftSequence, shownSeconds;
    private double initialPitch, initialYaw;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (isFinishing() || isDestroyed()) return;

            if (TrackingService.livePoseValid) {
                latestPitch = (float) TrackingService.livePitch;
                latestYaw = (float) TrackingService.liveYaw;
                if (!havePose) {
                    filteredPitch = latestPitch;
                    filteredYaw = latestYaw;
                    anchorPitch = filteredPitch;
                    anchorYaw = filteredYaw;
                    havePose = true;
                }
            }

            if (havePose) {
                float dt = lastFrameNs == 0 ? 1f/60f : Math.min(.05f,(frameTimeNanos-lastFrameNs)/1_000_000_000f);
                float alpha = 1f-(float)Math.exp(-dt*30f);
                filteredPitch += (latestPitch-filteredPitch)*alpha;
                filteredYaw += (latestYaw-filteredYaw)*alpha;
            }
            lastFrameNs = frameTimeNanos;

            if (anchorRunning && !stopping) updateCamera();
            updateSoftwareCursor();

            if (measuringDrift) sampleDrift(SystemClock.elapsedRealtime());
            long now = SystemClock.uptimeMillis();
            if (uiKeepAliveRunning && now - lastUiMs >= UI_INTERVAL_MS) {
                lastUiMs = now;
                if (poseInfo.isShown()) updateDiagnostics();
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    private void toggleDriftCheck() {
        if (measuringDrift) {
            finishDriftCheck("Check cancelled.");
            return;
        }
        if (!anchorRunning || !TrackingService.livePoseValid) {
            driftResult.setText("Start tracking and the anchor before measuring drift.");
            return;
        }
        measuringDrift = true;
        driftStartMs = -1;
        shownSeconds = -1;
        lastDriftSequence = TrackingService.livePoseSequence;
        lastDriftSampleMs = SystemClock.elapsedRealtime();
        driftButton.setText("Cancel check");
        driftResult.setText("Waiting for a fresh tracking sample…");
    }

    private void sampleDrift(long now) {
        long sequence = TrackingService.livePoseSequence;
        if (!anchorRunning || !TrackingService.livePoseValid || sequence < lastDriftSequence
                || now - lastDriftSampleMs > MAX_SAMPLE_GAP_MS) {
            finishDriftCheck("Tracking was interrupted. Start another check.");
            return;
        }
        if (sequence == lastDriftSequence) return;
        lastDriftSequence = sequence;
        lastDriftSampleMs = now;
        double pitch = TrackingService.livePitch, yaw = TrackingService.liveYaw;
        if (!Double.isFinite(pitch) || !Double.isFinite(yaw)) {
            finishDriftCheck("Invalid tracking sample. Start another check.");
            return;
        }
        if (driftStartMs < 0) {
            driftStartMs = now;
            initialPitch = pitch;
            initialYaw = yaw;
        }
        long remaining = DRIFT_CHECK_MS - (now - driftStartMs);
        if (remaining <= 0) {
            double deltaPitch = pitch - initialPitch;
            String report = String.format(Locale.UK, "60 s change   Pitch %+.2f°   Yaw %+.2f°", deltaPitch, yaw - initialYaw);
            if (presentation != null && presentation.root != null && presentation.root.getHeight() > 0) {
                double dy = (invertY ? 1 : -1) * deltaPitch * presentation.root.getHeight() / vFovDeg;
                report += String.format(Locale.UK, "\nScreen Y %+.1f px  (+ is down)", dy);
            }
            finishDriftCheck(report);
        } else {
            long seconds = (remaining + 999) / 1000;
            if (seconds != shownSeconds) {
                shownSeconds = seconds;
                driftResult.setText("Keep the glasses still · " + seconds + " s remaining");
            }
        }
    }

    private void finishDriftCheck(String message) {
        measuringDrift = false;
        driftButton.setText("Measure drift");
        driftResult.setText(message);
    }

    private void updateDiagnostics() {
        if (TrackingService.livePoseValid) {
            poseInfo.setText(String.format(Locale.UK, "Pitch %+.2f°   Yaw %+.2f°\nPin    %+.2f°   %+.2f°\n%s",
                    filteredPitch, filteredYaw, anchorPitch, anchorYaw,
                    TrackingService.liveGravityTrusted ? "Gravity correction active" : "Gravity correction paused"));
        } else if (!"Waiting for head tracking…".contentEquals(poseInfo.getText())) {
            poseInfo.setText("Waiting for head tracking…");
        }
        if (anchorRunning) {
            renderInfo.setText(String.format(Locale.UK, "Camera   X %+.0f px   Y %+.0f px", lastDx, lastDy));
        } else if (!"Spatial canvas idle".contentEquals(renderInfo.getText())) {
            renderInfo.setText("Spatial canvas idle");
        }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        WindowManager.LayoutParams attrs=getWindow().getAttributes();
        attrs.preferredRefreshRate=60f;
        getWindow().setAttributes(attrs);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        loadLayoutState();
        registerReceiver(overlayReceiver, new IntentFilter(ACTION_OVERLAY));
        registerReceiver(shizukuResultReceiver, new IntentFilter(ShizukuBridgeActivity.ACTION_RESULT));
        buildUi();
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(16), dp(16), dp(24));
        scroll.addView(root);

        TextView title = text(root, "Spatial desktop", 26, R.color.tracker_text);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text(root, "Start the anchor, then look straight ahead and pin your centre screen.", 15, R.color.tracker_muted);
        status = text(root, "Ready to anchor", 16, R.color.tracker_accent);
        status.setPadding(0, dp(12), 0, dp(4));
        status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);

        Button start = action("Start anchor", v -> requestCapture());
        start.setBackgroundTintList(android.content.res.ColorStateList.valueOf(getColor(R.color.tracker_accent)));
        start.setTextColor(getColor(R.color.tracker_ink));
        row(root, start, action("Pin here", v -> pinHere()));
        row(root, action("Floating controls", v -> enableFloatingControls()), action("Stop anchor", v -> stopAnchor()));

        LinearLayout placement = section(root, "Screen placement", true);
        layoutInfo = text(placement, "", 15, R.color.tracker_text);

        // Single-selection buttons also expose the selected panel to accessibility services.
        RadioGroup screens = new RadioGroup(this);
        screens.setOrientation(RadioGroup.HORIZONTAL);
        placement.addView(screens);
        String[] names = {"Left", "Centre", "Right"};
        for (int i = 0; i < names.length; i++) {
            final int panel = i;
            RadioButton choice = new RadioButton(this);
            choice.setId(View.generateViewId());
            choice.setText(names[i]);
            choice.setTextSize(14);
            choice.setMinHeight(dp(48));
            screens.addView(choice, new RadioGroup.LayoutParams(0, -2, 1));
            if (layoutSelected == panel) screens.check(choice.getId());
            choice.setOnClickListener(v -> selectLayoutPanel(panel));
        }
        layoutPad = new LayoutPadView(this, new LayoutPadListener() {
            @Override public void onMove(float dxNorm, float dyNorm) {
                if (layoutLocked) return;
                panelOffsetX[layoutSelected] = clampf(panelOffsetX[layoutSelected] + dxNorm * 0.85f, -1.50f, 1.50f);
                panelOffsetY[layoutSelected] = clampf(panelOffsetY[layoutSelected] + dyNorm * 0.65f, -1.20f, 1.20f);
                applyPanelPositions(); updateLayoutPad(); updateSoftwareCursor();
            }
            @Override public float getScale() { return panelUserScale[layoutSelected]; }
            @Override public void onScale(float scale) {
                if (layoutLocked) return;
                panelUserScale[layoutSelected] = clampf(scale, 0.45f, 1.60f);
                applyPanelScales(); updateLayoutPad(); updateSoftwareCursor();
            }
            @Override public void onGestureEnd() { updateLayoutInfo(); saveLayoutState(); }
        });
        layoutPad.setContentDescription("Screen placement pad. Drag to move the selected screen. Pinch to resize.");
        placement.addView(layoutPad, new LinearLayout.LayoutParams(-1, -2));
        text(placement, "Drag to move your selected screen. Pinch to resize it.", 14, R.color.tracker_muted);
        layoutLockButton = action(layoutLocked ? "Unlock layout" : "Lock layout", v -> {
            layoutLocked = !layoutLocked;
            layoutLockButton.setText(layoutLocked ? "Unlock layout" : "Lock layout");
            updateLayoutInfo();
            saveLayoutState();
        });
        row(placement, layoutLockButton);
        row(placement, action("Reset selected", v -> resetSelectedLayout()), action("Reset all", v -> resetAllLayout()));
        toggle(placement, "Invert horizontal anchor", invertX, (v, checked) -> invertX = checked);
        toggle(placement, "Invert vertical anchor", invertY, (v, checked) -> invertY = checked);
        updateLayoutInfo();

        LinearLayout apps = section(root, "Side displays and apps", false);
        text(apps, "Connect Shizuku, create a display and choose which app to open on it.", 14, R.color.tracker_muted);
        labInfo = text(apps, "Ready to connect", 15, R.color.tracker_accent);
        labInfo.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);
        row(apps, action("Connect Shizuku", v -> startShizukuBridge(ShizukuBridgeActivity.MODE_CONNECT, null, -1, null)));
        row(apps, action("Create left display", v -> createLabDisplay(true)), action("Create right display", v -> createLabDisplay(false)));
        row(apps, action("Launch left app", v -> chooseAndLaunchApp(true)), action("Launch right app", v -> chooseAndLaunchApp(false)));
        toggle(apps, "Keep side apps on their displays", stickySideApps, (v, checked) -> stickySideApps = checked);

        TextView cursor = text(apps, "Cursor target", 17, R.color.tracker_text);
        cursor.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        text(apps, "Look at a side screen to aim the crosshair. Choose Centre to use the Android mouse.", 14, R.color.tracker_muted);
        row(apps, action("Left", v -> selectControlTarget(1)), action("Centre", v -> selectControlTarget(0)), action("Right", v -> selectControlTarget(2)));
        row(apps, action("Click selected", v -> clickSelectedDisplay()), action("Back", v -> backSelectedDisplay()));
        row(apps, action("Return left app", v -> repinSideApp(true)), action("Return right app", v -> repinSideApp(false)));
        row(apps, action("Release left display", v -> releaseLabDisplay(true, "Left display released")),
                  action("Release right display", v -> releaseLabDisplay(false, "Right display released")));

        LinearLayout diagnostics = section(root, "Live diagnostics", false);
        poseInfo = text(diagnostics, "Waiting for head tracking…", 14, R.color.tracker_text);
        renderInfo = text(diagnostics, "Spatial canvas idle", 14, R.color.tracker_muted);
        poseInfo.setTypeface(Typeface.MONOSPACE);
        renderInfo.setTypeface(Typeface.MONOSPACE);
        text(diagnostics, "Rest the glasses on a steady surface for 60 seconds. If they move, cancel and start again.", 14, R.color.tracker_muted);
        driftButton = action("Measure drift", v -> toggleDriftCheck());
        row(diagnostics, driftButton);
        driftResult = text(diagnostics, "", 15, R.color.tracker_text);

        // Keep the original tiny no-touch pulse on screen, even when scrolling a long section.
        FrameLayout page = new FrameLayout(this);
        page.addView(scroll);
        uiKeepAliveView = new View(this);
        uiKeepAliveView.setBackgroundColor(0x01000000);
        uiKeepAliveView.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        page.addView(uiKeepAliveView, new FrameLayout.LayoutParams(2, 2));
        setContentView(page);
    }

    private int dp(int size) {
        return Math.round(size * getResources().getDisplayMetrics().density);
    }

    private TextView text(LinearLayout parent, String value, int size, int colour) {
        TextView label = new TextView(this);
        label.setText(value);
        label.setTextSize(size);
        label.setTextColor(getColor(colour));
        label.setPadding(0, dp(3), 0, dp(3));
        parent.addView(label);
        return label;
    }

    private Button action(String label, View.OnClickListener listener) {
        Button button = new Button(this);
        button.setText(label);
        button.setAllCaps(false);
        button.setMinWidth(0);
        button.setMinHeight(dp(48));
        button.setPadding(dp(8), dp(4), dp(8), dp(4));
        button.setOnClickListener(listener);
        return button;
    }

    private void row(LinearLayout parent, Button... buttons) {
        LinearLayout row = new LinearLayout(this);
        parent.addView(row);
        for (Button button : buttons) {
            row.addView(button, new LinearLayout.LayoutParams(0, -1, 1));
        }
    }

    private void toggle(LinearLayout parent, String label, boolean checked, CompoundButton.OnCheckedChangeListener listener) {
        CheckBox box = new CheckBox(this);
        box.setText(label);
        box.setMinHeight(dp(48));
        box.setChecked(checked);
        box.setOnCheckedChangeListener(listener);
        parent.addView(box);
    }

    private LinearLayout section(LinearLayout parent, String label, boolean expanded) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setBackgroundResource(R.drawable.tracker_card);
        card.setPadding(dp(10), dp(4), dp(10), dp(4));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(-1, -2);
        params.topMargin = dp(12);
        parent.addView(card, params);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(4), 0, dp(4), dp(10));
        Button header = action("", v -> {
            boolean open = content.getVisibility() != View.VISIBLE;
            setSectionState((Button) v, content, label, open);
        });
        header.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        header.setTextSize(17);
        android.util.TypedValue selectable = new android.util.TypedValue();
        getTheme().resolveAttribute(android.R.attr.selectableItemBackground, selectable, true);
        header.setBackgroundResource(selectable.resourceId);
        card.addView(header);
        card.addView(content);
        setSectionState(header, content, label, expanded);
        return content;
    }

    private void setSectionState(Button header, LinearLayout content, String label, boolean expanded) {
        content.setVisibility(expanded ? View.VISIBLE : View.GONE);
        header.setText((expanded ? "▾   " : "▸   ") + label);
        header.setContentDescription(label + (expanded ? ", expanded" : ", collapsed"));
    }

    private String screenName(int index){
        if(index==SCREEN_LEFT)return "LEFT";
        if(index==SCREEN_RIGHT)return "RIGHT";
        return "CENTRE";
    }

    private FrameLayout panelForIndex(int index){
        if(presentation==null)return null;
        if(index==SCREEN_LEFT)return presentation.leftPanel;
        if(index==SCREEN_RIGHT)return presentation.rightPanel;
        return presentation.centerPanel;
    }

    private void selectLayoutPanel(int index){
        layoutSelected=Math.max(SCREEN_LEFT,Math.min(SCREEN_RIGHT,index));
        updateLayoutInfo(); saveLayoutState();
    }

    private void applyPanelScales(){
        if(presentation==null)return;
        for(int i=SCREEN_LEFT;i<=SCREEN_RIGHT;i++){
            FrameLayout p=panelForIndex(i);
            if(p!=null){
                float sc=clampf(panelUserScale[i],0.45f,1.60f);
                p.setScaleX(sc); p.setScaleY(sc);
            }
        }
    }

    private void updateLayoutInfo(){
        if(layoutInfo!=null){
            layoutInfo.setText(String.format(Locale.UK,
                    "%s%s  •  %.0f%%\nX %+.2f    Y %+.2f",
                    screenName(layoutSelected),layoutLocked?" • Locked":"",
                    panelUserScale[layoutSelected]*100f,panelOffsetX[layoutSelected],panelOffsetY[layoutSelected]));
        }
        updateLayoutPad();
    }

    private void updateLayoutPad(){
        if(layoutPad!=null){
            layoutPad.setPanelState(panelOffsetX[layoutSelected],panelOffsetY[layoutSelected],panelUserScale[layoutSelected],screenName(layoutSelected));
            layoutPad.setLocked(layoutLocked);
        }
    }

    private void resetSelectedLayout(){
        panelOffsetX[layoutSelected]=0f; panelOffsetY[layoutSelected]=0f; panelUserScale[layoutSelected]=1f;
        applyPanelPositions(); applyPanelScales(); updateSoftwareCursor(); updateLayoutInfo(); saveLayoutState();
    }

    private void resetAllLayout(){
        for(int i=0;i<3;i++){panelOffsetX[i]=0f;panelOffsetY[i]=0f;panelUserScale[i]=1f;}
        layoutLocked=false;
        if(layoutPad!=null)layoutPad.setLocked(false);
        if(layoutLockButton!=null)layoutLockButton.setText("Lock layout");
        applyPanelPositions(); applyPanelScales(); updateSoftwareCursor(); updateLayoutInfo(); saveLayoutState();
    }

    private void loadLayoutState(){
        try{
            android.content.SharedPreferences p=getSharedPreferences("spatial_layout_v098",MODE_PRIVATE);
            for(int i=0;i<3;i++){
                panelOffsetX[i]=p.getFloat("x"+i,0f);
                panelOffsetY[i]=p.getFloat("y"+i,0f);
                panelUserScale[i]=clampf(p.getFloat("s"+i,1f),0.45f,1.60f);
            }
            layoutSelected=Math.max(SCREEN_LEFT,Math.min(SCREEN_RIGHT,p.getInt("selected",SCREEN_CENTRE)));
            layoutLocked=p.getBoolean("locked",false);
        }catch(Throwable ignored){}
    }

    private void saveLayoutState(){
        try{
            android.content.SharedPreferences.Editor e=getSharedPreferences("spatial_layout_v098",MODE_PRIVATE).edit();
            for(int i=0;i<3;i++)e.putFloat("x"+i,panelOffsetX[i]).putFloat("y"+i,panelOffsetY[i]).putFloat("s"+i,panelUserScale[i]);
            e.putInt("selected",layoutSelected).putBoolean("locked",layoutLocked).apply();
        }catch(Throwable ignored){}
    }


    private void enableFloatingControls() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlayPermissionRequested = true;
            status.setText("Allow ‘Display over other apps’, then return here");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        try {
            Intent i = new Intent(this, OverlayControlService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("FLOATING CONTROLS ACTIVE — switch to another app");
        } catch (Throwable t) {
            status.setText("Could not start floating controls: " + t.getMessage());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        uiKeepAliveRunning=true;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        uiKeepAliveHandler.post(uiKeepAliveTick);
        if (overlayPermissionRequested && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            overlayPermissionRequested = false;
            startOverlayService();
        }
    }

    @Override protected void onPause(){
        if (measuringDrift) finishDriftCheck("Check cancelled when you left the setup screen.");
        uiKeepAliveRunning=false;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        super.onPause();
    }

    private Display externalDisplay(){DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);Display[] p=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);if(p!=null)for(Display d:p)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;for(Display d:dm.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return null;}

    private void requestCapture(){
        if(anchorRunning||projection!=null){status.setText("Already running — STOP first");return;}
        Display d=externalDisplay(); if(d==null){status.setText("No external RayNeo display detected");return;}
        status.setText("Requesting Android screen capture…"); startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(req!=REQ_CAPTURE)return;
        if(result!=RESULT_OK||data==null){status.setText("Capture permission cancelled");return;}
        projection=projectionManager.getMediaProjection(result,data); if(projection==null){status.setText("MediaProjection failed");return;}
        projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(!stopping){anchorRunning=false;status.setText("Capture stopped by Android");}});}};
        projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper()));
        startSpatialDisplay();
    }

    private void startSpatialDisplay(){
        Display d=externalDisplay(); if(d==null){status.setText("RayNeo display disappeared");stopAnchor();return;}
        try{presentation=new SpatialPresentation(this,d);presentation.show();}catch(Throwable t){status.setText("Presentation failed: "+t.getMessage());stopAnchor();return;}
        presentation.root.post(()->{layoutWorld(); attachCapture(); pinHere();});
    }

    private void attachCapture(){
        if(presentation==null)return;
        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startVirtualDisplay(st);}
            public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseVD();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(presentation.texture.isAvailable())startVirtualDisplay(presentation.texture.getSurfaceTexture());
    }

    private void startVirtualDisplay(SurfaceTexture st){
        releaseVD(); if(stopping||projection==null||st==null)return;
        DisplayMetrics m=new DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(m);
        float ds=Math.min(1f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(m.widthPixels,m.heightPixels));
        int w=Math.max(320,Math.round(m.widthPixels*ds)),h=Math.max(240,Math.round(m.heightPixels*ds)),dpi=Math.max(160,Math.round(m.densityDpi*ds));
        st.setDefaultBufferSize(w,h); captureSurface=new Surface(st);
        virtualDisplay=projection.createVirtualDisplay("RayNeoSpatialCapture",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,captureSurface,null,null);
        anchorRunning=virtualDisplay!=null;
        status.setText(anchorRunning?"SPATIAL DESKTOP ACTIVE — three world positions":"Virtual display failed");
    }

    private void layoutWorld(){
        if(presentation==null||presentation.root==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight(); if(vw<=0||vh<=0)return;
        int worldW=vw*7;
        int worldH=vh*7;
        FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)presentation.world.getLayoutParams();
        wlp.width=worldW; wlp.height=worldH; wlp.gravity=Gravity.TOP|Gravity.LEFT;
        presentation.world.setLayoutParams(wlp);
        int pw=Math.max(320,Math.round(vw*panelScale));int ph=Math.max(240,Math.round(vh*panelScale));
        float cx=worldW/2f;
        float cy=worldH/2f;
        // Initialise fixed base panel dimensions once; gesture movement uses X/Y only and does not resize surfaces.
        preparePanel(presentation.leftPanel,pw,ph);
        preparePanel(presentation.centerPanel,pw,ph);
        preparePanel(presentation.rightPanel,pw,ph);
        presentation.worldCenterX=cx;
        presentation.worldCenterY=cy;
        applyPanelPositions();
        applyPanelScales();
        updateCamera();
        updateSoftwareCursor();
    }

    private void preparePanel(View v,int w,int h){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();if(lp.width!=w||lp.height!=h){lp.width=w;lp.height=h;lp.gravity=Gravity.TOP|Gravity.LEFT;v.setLayoutParams(lp);}v.setPivotX(w/2f);v.setPivotY(h/2f);}

    private void applyPanelPositions(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float cx=presentation.worldCenterX; if(cx==0f)cx=(vw*7)/2f;
        float cy=presentation.worldCenterY; if(cy==0f)cy=(vh*7)/2f;
        float gap=panelSpacingScreens*vw;
        placePanelPosition(presentation.leftPanel,cx-gap+panelOffsetX[SCREEN_LEFT]*vw,cy+panelOffsetY[SCREEN_LEFT]*vh);
        placePanelPosition(presentation.centerPanel,cx+panelOffsetX[SCREEN_CENTRE]*vw,cy+panelOffsetY[SCREEN_CENTRE]*vh);
        placePanelPosition(presentation.rightPanel,cx+gap+panelOffsetX[SCREEN_RIGHT]*vw,cy+panelOffsetY[SCREEN_RIGHT]*vh);
    }

    private void placePanelPosition(View v,float centerX,float centerY){
        int w=v.getWidth()>0?v.getWidth():((FrameLayout.LayoutParams)v.getLayoutParams()).width;
        int h=v.getHeight()>0?v.getHeight():((FrameLayout.LayoutParams)v.getLayoutParams()).height;
        v.setX(centerX-w/2f);v.setY(centerY-h/2f);v.setPivotX(w/2f);v.setPivotY(h/2f);
    }

    private void pinHere(){
        if(!havePose&&TrackingService.livePoseValid){latestPitch=(float)TrackingService.livePitch;latestYaw=(float)TrackingService.liveYaw;filteredPitch=latestPitch;filteredYaw=latestYaw;havePose=true;}
        if(!havePose){status.setText("Start head tracking first — no IMU pose yet");return;}
        filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;updateCamera();status.setText("PINNED — centre is straight ahead");
    }

    // Only the camera displacement wraps. Its ±180° seam is behind the viewer, outside the panel field.
    static float cameraYawDelta(float yaw, float pinnedYaw) {
        float delta = (yaw - pinnedYaw) % 360f;
        if (delta >= 180f) return delta - 360f;
        if (delta < -180f) return delta + 360f;
        return delta;
    }

    private void updateCamera(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float yaw=cameraYawDelta(filteredYaw, anchorYaw),pitch=filteredPitch-anchorPitch;
        float dx=(invertX?1f:-1f)*(yaw/hFovDeg)*vw;
        float dy=(invertY?1f:-1f)*(pitch/vFovDeg)*vh;
        float baseX=vw/2f-presentation.worldCenterX;
        float baseY=vh/2f-presentation.worldCenterY;
        presentation.world.setTranslationX(baseX+dx);
        presentation.world.setTranslationY(baseY+dy);
        lastDx=dx;lastDy=dy;
    }


    /**
     * v0.9.1 diagnostic: create ONE ordinary app-owned VirtualDisplay only when requested.
     * This deliberately does not use MediaProjection and does not launch another app yet.
     * Any failure is caught and printed in the UI rather than allowed to take down Anchor Mode.
     */
    private void createLabDisplay(boolean left){
        if (stopping) { setLabStatus("BLOCKED: Anchor is stopping"); return; }
        if (!anchorRunning || presentation == null) { setLabStatus("BLOCKED: Start Anchor normally first"); return; }
        if (left ? leftLabDisplay != null : rightLabDisplay != null) {
            setLabStatus((left?"LEFT":"RIGHT") + " already exists — destroy it first");
            return;
        }

        final TextureView tv = left ? presentation.leftLabTexture : presentation.rightLabTexture;
        final TextView label = left ? presentation.leftLabel : presentation.rightLabel;
        final String side = left ? "LEFT" : "RIGHT";
        if (tv == null) { setLabStatus(side + " failed: diagnostic TextureView missing"); return; }

        try {
            label.setText(side + "\nVIRTUAL DISPLAY\nWAITING FOR SURFACE");
            label.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){
                    startLabVirtualDisplay(left, st, w, h);
                }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){
                    releaseLabDisplay(left, side + " surface destroyed");
                    return true;
                }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture st){}
            });
            if (tv.isAvailable()) startLabVirtualDisplay(left, tv.getSurfaceTexture(), tv.getWidth(), tv.getHeight());
            else setLabStatus(side + ": waiting for TextureView surface…");
        } catch (Throwable t) {
            showLabError(side + " setup", t);
            releaseLabDisplay(left, null);
        }
    }

    private void startLabVirtualDisplay(boolean left, SurfaceTexture st, int surfaceW, int surfaceH){
        final String side = left ? "LEFT" : "RIGHT";
        if (stopping || presentation == null || st == null) return;
        if (left ? leftLabDisplay != null : rightLabDisplay != null) return;
        try {
            int w = Math.max(320, surfaceW > 0 ? surfaceW : 640);
            int h = Math.max(240, surfaceH > 0 ? surfaceH : 360);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int dpi = Math.max(160, metrics.densityDpi);
            st.setDefaultBufferSize(w,h);
            Surface surface = new Surface(st);

            int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;
            DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
            VirtualDisplay vd=dm.createVirtualDisplay("RayNeoLab"+side,w,h,dpi,surface,flags);
            if(vd==null){
                try{surface.release();}catch(Throwable ignored){}
                setLabStatus(side + " FAILED: DisplayManager returned null");
                return;
            }
            if(left){leftLabDisplay=vd;leftLabSurface=surface;leftLabWidth=w;leftLabHeight=h;}
            else{rightLabDisplay=vd;rightLabSurface=surface;rightLabWidth=w;rightLabHeight=h;}
            Display disp=vd.getDisplay();
            int id=disp!=null?disp.getDisplayId():-1;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            label.setText(side + "\nVIRTUAL DISPLAY CREATED\nDisplay ID " + id + "\n(no app launched yet)");
            label.bringToFront();
            setLabStatus(side + " SUCCESS — VirtualDisplay ID " + id + ". Tracking should remain smooth.");
        }catch(Throwable t){
            showLabError(side + " createVirtualDisplay",t);
            releaseLabDisplay(left,null);
        }
    }


    private static class AppChoice {
        final String label;
        final String packageName;
        AppChoice(String label,String packageName){this.label=label;this.packageName=packageName;}
    }

    private void chooseAndLaunchApp(boolean left){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus("BLOCKED: CREATE " + side + " DISPLAY first");return;}
        try{
            PackageManager pm=getPackageManager();
            Intent main=new Intent(Intent.ACTION_MAIN,null); main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris=pm.queryIntentActivities(main,0);
            final ArrayList<AppChoice> apps=new ArrayList<>();
            for(ResolveInfo ri:ris){
                if(ri==null||ri.activityInfo==null)continue;
                String pkg=ri.activityInfo.packageName;
                if(pkg==null||pkg.equals(getPackageName()))continue;
                CharSequence cs=ri.loadLabel(pm); String label=cs!=null?cs.toString():pkg;
                boolean duplicate=false; for(AppChoice a:apps)if(a.packageName.equals(pkg)){duplicate=true;break;}
                if(!duplicate)apps.add(new AppChoice(label,pkg));
            }
            Collections.sort(apps,new Comparator<AppChoice>(){
                @Override public int compare(AppChoice a,AppChoice b){return a.label.compareToIgnoreCase(b.label);}
            });
            if(apps.isEmpty()){setLabStatus(side + " app list is empty");return;}
            String[] labels=new String[apps.size()]; for(int i=0;i<apps.size();i++)labels[i]=apps.get(i).label;
            new AlertDialog.Builder(this).setTitle("Launch app on " + side)
                    .setItems(labels,(dialog,which)->prepareBridgeLaunch(left,apps.get(which)))
                    .setNegativeButton("CANCEL",null).show();
        }catch(Throwable t){showLabError(side + " app picker",t);}
    }

    private void prepareBridgeLaunch(boolean left,AppChoice app){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus(side + " display disappeared before launch");return;}
        try{
            PackageManager pm=getPackageManager();
            Intent launch=pm.getLaunchIntentForPackage(app.packageName);
            if(launch==null){setLabStatus(side + " FAILED: no launch intent for " + app.label);return;}
            ComponentName component=launch.getComponent();
            if(component==null){
                ResolveInfo ri=pm.resolveActivity(launch,0);
                if(ri!=null&&ri.activityInfo!=null)component=new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name);
            }
            if(component==null){setLabStatus(side + " FAILED: could not resolve component for " + app.label);return;}
            int displayId=vd.getDisplay().getDisplayId();
            if(left){leftAppPackage=app.packageName;leftAppComponent=component.flattenToString();}
            else{rightAppPackage=app.packageName;rightAppComponent=component.flattenToString();}
            setLabStatus(side + " → isolated Shizuku launch " + app.label + " on Display " + displayId);
            startShizukuBridge(ShizukuBridgeActivity.MODE_LAUNCH,side,displayId,component.flattenToString(),app.packageName,-1,-1);
        }catch(Throwable t){showLabError(side + " bridge launch",t);}
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component){
        startShizukuBridge(mode,side,displayId,component,null,-1,-1);
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component,int x,int y){
        startShizukuBridge(mode,side,displayId,component,null,x,y);
    }

    private void startShizukuBridge(String mode,String side,int displayId,String component,String packageName,int x,int y){
        try{
            Intent i=new Intent(this,ShizukuBridgeActivity.class).putExtra(ShizukuBridgeActivity.EXTRA_MODE,mode);
            if(side!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_SIDE,side);
            if(displayId>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_DISPLAY_ID,displayId);
            if(component!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_COMPONENT,component);
            if(packageName!=null)i.putExtra(ShizukuBridgeActivity.EXTRA_PACKAGE,packageName);
            if(x>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_X,x);
            if(y>=0)i.putExtra(ShizukuBridgeActivity.EXTRA_Y,y);
            startActivity(i);
        }catch(Throwable t){showLabError("start isolated Shizuku bridge",t);}
    }

    private void setCentreMouseEnabled(boolean enabled){
        try{
            Intent i=new Intent(this,TrackingService.class).setAction(TrackingService.ACTION_CONFIG).putExtra("mouse",enabled);
            startService(i);
        }catch(Throwable t){showLabError("switch centre mouse",t);}
    }

    private void selectControlTarget(int target){
        if(target==1&&(leftLabDisplay==null||leftLabDisplay.getDisplay()==null)){setLabStatus("CREATE LEFT DISPLAY first");return;}
        if(target==2&&(rightLabDisplay==null||rightLabDisplay.getDisplay()==null)){setLabStatus("CREATE RIGHT DISPLAY first");return;}
        controlTarget=target;
        if(target==0){
            setCentreMouseEnabled(true);
            if(presentation!=null){presentation.leftCursor.setCursor(0,0,false,false);presentation.rightCursor.setCursor(0,0,false,false);}
            setLabStatus("CONTROL CENTRE — normal /dev/uinput head mouse restored");
        }else{
            setCentreMouseEnabled(false);
            updateSoftwareCursor();
            setLabStatus("CONTROL "+(target==1?"LEFT":"RIGHT")+" — white software cursor follows the centre of your gaze");
        }
    }

    private void clickSelectedDisplay(){
        if(controlTarget==0){setLabStatus("CENTRE uses the normal /dev/uinput mouse");return;}
        boolean left=controlTarget==1;
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus("Selected side display is not available");return;}
        boolean inside=left?leftCursorInside:rightCursorInside;
        if(!inside){setLabStatus("LOOK AT the selected panel first — cursor is outside its active area");return;}
        int x=left?leftCursorDisplayX:rightCursorDisplayX;
        int y=left?leftCursorDisplayY:rightCursorDisplayY;
        String pkg=left?leftAppPackage:rightAppPackage;
        setLabStatus("TOUCH TAP → Display "+vd.getDisplay().getDisplayId()+" @ "+x+","+y+(stickySideApps&&pkg!=null?" • sticky "+pkg:""));
        startShizukuBridge(ShizukuBridgeActivity.MODE_TAP,null,vd.getDisplay().getDisplayId(),null,stickySideApps?pkg:null,x,y);
    }

    private void backSelectedDisplay(){
        if(controlTarget==0){setLabStatus("CENTRE uses normal Android controls");return;}
        VirtualDisplay vd=controlTarget==1?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null)return;
        setLabStatus("BACK → Display "+vd.getDisplay().getDisplayId());
        startShizukuBridge(ShizukuBridgeActivity.MODE_BACK,null,vd.getDisplay().getDisplayId(),null,-1,-1);
    }

    private void repinSideApp(boolean left){
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        String pkg=left?leftAppPackage:rightAppPackage;
        String component=left?leftAppComponent:rightAppComponent;
        String side=left?"LEFT":"RIGHT";
        if(vd==null||vd.getDisplay()==null){setLabStatus("CREATE "+side+" DISPLAY first");return;}
        if(pkg==null){setLabStatus("Launch a "+side+" app first");return;}
        setLabStatus("RETURN "+side+" → "+pkg+" to Display "+vd.getDisplay().getDisplayId());
        startShizukuBridge(ShizukuBridgeActivity.MODE_REPIN,side,vd.getDisplay().getDisplayId(),component,pkg,-1,-1);
    }

    private void updateSoftwareCursor(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(), vh=presentation.root.getHeight();
        if(vw<=0||vh<=0)return;
        updateCursorForPanel(true,vw,vh);
        updateCursorForPanel(false,vw,vh);
    }

    private void updateCursorForPanel(boolean left,int vw,int vh){
        if(presentation==null)return;
        int wanted=left?1:2;
        CursorOverlay cursor=left?presentation.leftCursor:presentation.rightCursor;
        FrameLayout panel=left?presentation.leftPanel:presentation.rightPanel;
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        int dw=left?leftLabWidth:rightLabWidth, dh=left?leftLabHeight:rightLabHeight;
        if(cursor==null||panel==null||controlTarget!=wanted||vd==null||dw<=0||dh<=0){
            if(cursor!=null)cursor.setCursor(0,0,false,false);
            if(left)leftCursorInside=false;else rightCursorInside=false;
            return;
        }
        float scale=panel.getScaleX();
        float visualW=Math.max(1f,panel.getWidth()*scale), visualH=Math.max(1f,panel.getHeight()*scale);
        float visualLeft=presentation.world.getTranslationX()+panel.getX()+(panel.getWidth()-visualW)/2f;
        float visualTop=presentation.world.getTranslationY()+panel.getY()+(panel.getHeight()-visualH)/2f;
        float nx=(vw/2f-visualLeft)/visualW;
        float ny=(vh/2f-visualTop)/visualH;
        boolean inside=nx>=0f&&nx<=1f&&ny>=0f&&ny<=1f;
        float cx=clampf(nx,0f,1f), cy=clampf(ny,0f,1f);
        float localX=cx*panel.getWidth(), localY=cy*panel.getHeight();
        cursor.setCursor(localX,localY,true,inside);
        int tx=Math.round(cx*(dw-1)), ty=Math.round(cy*(dh-1));
        if(left){leftCursorDisplayX=tx;leftCursorDisplayY=ty;leftCursorInside=inside;}
        else{rightCursorDisplayX=tx;rightCursorDisplayY=ty;rightCursorInside=inside;}
    }

    private static float clampf(float v,float lo,float hi){return Math.max(lo,Math.min(hi,v));}

    private void showLabError(String stage, Throwable t){
        String msg=t.getMessage();
        if(msg==null||msg.trim().isEmpty())msg="(no message)";
        String text="ERROR at " + stage + "\n" + t.getClass().getName() + "\n" + msg;
        setLabStatus(text);
        android.util.Log.e("RayNeoV091",text,t);
    }

    private void setLabStatus(String text){
        if(labInfo!=null)labInfo.setText("LAB: " + text);
    }

    private void releaseLabDisplay(boolean left,String message){
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if((left&&controlTarget==1)||(!left&&controlTarget==2))selectControlTarget(0);
        if(left){leftLabDisplay=null;leftLabWidth=leftLabHeight=0;leftAppPackage=null;leftAppComponent=null;}else{rightLabDisplay=null;rightLabWidth=rightLabHeight=0;rightAppPackage=null;rightAppComponent=null;}
        if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}
        Surface sf=left?leftLabSurface:rightLabSurface;
        if(left)leftLabSurface=null;else rightLabSurface=null;
        if(sf!=null)try{sf.release();}catch(Throwable ignored){}
        if(presentation!=null){
            TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            if(tv!=null){try{tv.setSurfaceTextureListener(null);}catch(Throwable ignored){}tv.setVisibility(View.GONE);}
            if(label!=null){label.setText(left?"LEFT\nSNAPSHOT":"RIGHT\nSNAPSHOT");label.setVisibility(View.VISIBLE);}
        }
        if(message!=null)setLabStatus(message);
    }

    private void snapshot(boolean left){
        if(presentation==null||!presentation.texture.isAvailable()){status.setText("Start Anchor first");return;}
        try{Bitmap b=presentation.texture.getBitmap();if(b==null){status.setText("Snapshot empty");return;}ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView label=left?presentation.leftLabel:presentation.rightLabel;iv.setImageBitmap(b);iv.setVisibility(View.VISIBLE);label.setVisibility(View.GONE);status.setText(left?"LEFT panel saved":"RIGHT panel saved");}catch(Throwable t){status.setText("Snapshot failed: "+t.getMessage());}
    }
    private void clear(boolean left){if(presentation==null)return;ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView l=left?presentation.leftLabel:presentation.rightLabel;iv.setImageDrawable(null);iv.setVisibility(View.GONE);l.setVisibility(View.VISIBLE);}

    private void releaseVD(){VirtualDisplay vd=virtualDisplay;virtualDisplay=null;if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}Surface s=captureSurface;captureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){} }
    private void stopAnchor(){
        if(stopping)return;stopping=true;anchorRunning=false;
        setCentreMouseEnabled(true); controlTarget=0;
        releaseLabDisplay(true,null); releaseLabDisplay(false,null);
        releaseVD();
        SpatialPresentation p=presentation;presentation=null;if(p!=null){try{p.texture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        MediaProjection mp=projection;projection=null;if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}
        projectionCallback=null;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");
    }
    @Override protected void onDestroy(){
        uiKeepAliveRunning=false;
        uiKeepAliveHandler.removeCallbacks(uiKeepAliveTick);
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        try{unregisterReceiver(overlayReceiver);}catch(Throwable ignored){}
        try{unregisterReceiver(shizukuResultReceiver);}catch(Throwable ignored){}
        try{stopService(new Intent(this,OverlayControlService.class));}catch(Throwable ignored){}
        stopAnchor();
        super.onDestroy();
    }


    private interface LayoutPadListener {
        void onMove(float dxNorm,float dyNorm);
        float getScale();
        void onScale(float scale);
        void onGestureEnd();
    }

    /** Circular direct-manipulation pad for positioning and resizing one spatial screen. */
    private static class LayoutPadView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final LayoutPadListener listener;
        private float lastX,lastY,startPinchDistance,startPinchScale=1f;
        private boolean pinching,locked;
        private float indicatorX,indicatorY,indicatorScale=1f;
        private String selectedName="CENTRE";

        LayoutPadView(Context c,LayoutPadListener listener){
            super(c); this.listener=listener; setWillNotDraw(false); setFocusable(true); setClickable(true);
        }

        void setLocked(boolean locked){if(this.locked!=locked){this.locked=locked;invalidate();}}
        void setPanelState(float xScreens,float yScreens,float scale,String name){
            indicatorX=clampf(xScreens/1.50f,-1f,1f);
            indicatorY=clampf(yScreens/1.20f,-1f,1f);
            indicatorScale=clampf(scale,0.45f,1.60f);
            selectedName=name==null?"SCREEN":name;
            invalidate();
        }

        private int dp(float v){return Math.round(v*getResources().getDisplayMetrics().density);}
        @Override protected void onMeasure(int widthMeasureSpec,int heightMeasureSpec){
            int w=MeasureSpec.getSize(widthMeasureSpec);
            if(w<=0)w=dp(340);
            int desired=Math.min(w,dp(360));
            setMeasuredDimension(w,desired);
        }

        @Override protected void onDraw(Canvas c){
            super.onDraw(c);
            float cx=getWidth()/2f,cy=getHeight()/2f;
            float r=Math.max(20f,Math.min(getWidth(),getHeight())/2f-dp(14));
            paint.setStyle(Paint.Style.FILL); paint.setColor(locked?0xff25282c:0xff1e252b); c.drawCircle(cx,cy,r,paint);
            paint.setStyle(Paint.Style.STROKE); paint.setStrokeWidth(dp(2)); paint.setColor(locked?0xff666666:0xff8fa3b2); c.drawCircle(cx,cy,r,paint);
            paint.setStrokeWidth(dp(1)); paint.setColor(0xff45515a); c.drawLine(cx-r,cy,cx+r,cy,paint); c.drawLine(cx,cy-r,cx,cy+r,paint);

            float hx=cx+indicatorX*r*0.62f, hy=cy+indicatorY*r*0.62f;
            float halfW=dp(34)*indicatorScale, halfH=dp(20)*indicatorScale;
            paint.setStyle(Paint.Style.FILL); paint.setColor(locked?0xff555555:0xff355f82);
            c.drawRoundRect(hx-halfW,hy-halfH,hx+halfW,hy+halfH,dp(6),dp(6),paint);
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(dp(2));paint.setColor(Color.WHITE);
            c.drawRoundRect(hx-halfW,hy-halfH,hx+halfW,hy+halfH,dp(6),dp(6),paint);

            paint.setStyle(Paint.Style.FILL);paint.setColor(Color.WHITE);paint.setTextAlign(Paint.Align.CENTER);paint.setTextSize(dp(13));
            c.drawText(selectedName,hx,hy+dp(5),paint);
            paint.setTextSize(dp(12));paint.setColor(0xffcbd4da);
            c.drawText(locked?"LAYOUT LOCKED":"DRAG • PINCH",cx,cy+r-dp(12),paint);
        }

        private float spacing(MotionEvent e){
            if(e.getPointerCount()<2)return 0f;
            float dx=e.getX(0)-e.getX(1),dy=e.getY(0)-e.getY(1);
            return (float)Math.sqrt(dx*dx+dy*dy);
        }

        @Override public boolean onTouchEvent(MotionEvent e){
            if(locked){
                if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL)getParent().requestDisallowInterceptTouchEvent(false);
                return true;
            }
            switch(e.getActionMasked()){
                case MotionEvent.ACTION_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    lastX=e.getX();lastY=e.getY();pinching=false;return true;
                case MotionEvent.ACTION_POINTER_DOWN:
                    getParent().requestDisallowInterceptTouchEvent(true);
                    if(e.getPointerCount()>=2){
                        pinching=true;startPinchDistance=Math.max(1f,spacing(e));startPinchScale=listener.getScale();
                    }
                    return true;
                case MotionEvent.ACTION_MOVE:
                    if(e.getPointerCount()>=2){
                        if(!pinching){pinching=true;startPinchDistance=Math.max(1f,spacing(e));startPinchScale=listener.getScale();}
                        float ratio=spacing(e)/Math.max(1f,startPinchDistance);
                        listener.onScale(startPinchScale*ratio);
                    }else if(!pinching){
                        float r=Math.max(1f,Math.min(getWidth(),getHeight())/2f-dp(14));
                        float x=e.getX(),y=e.getY();
                        listener.onMove((x-lastX)/r,(y-lastY)/r);
                        lastX=x;lastY=y;
                    }
                    return true;
                case MotionEvent.ACTION_POINTER_UP:
                    pinching=false;
                    if(e.getPointerCount()>1){
                        int remaining=e.getActionIndex()==0?1:0;
                        lastX=e.getX(remaining);lastY=e.getY(remaining);
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    pinching=false;getParent().requestDisallowInterceptTouchEvent(false);listener.onGestureEnd();performClick();return true;
            }
            return true;
        }

        @Override public boolean performClick(){super.performClick();return true;}
    }

    private static class SpatialPresentation extends Presentation {
        FrameLayout root,world,leftPanel,centerPanel,rightPanel;TextureView texture,leftLabTexture,rightLabTexture;ImageView leftImage,rightImage;TextView leftLabel,rightLabel;CursorOverlay leftCursor,rightCursor;float worldCenterX,worldCenterY;
        SpatialPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){
            super.onCreate(b);getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(true);root.setClipToPadding(false);
            world=new FrameLayout(getContext());world.setBackgroundColor(Color.BLACK);world.setClipChildren(false);world.setClipToPadding(false);root.addView(world,new FrameLayout.LayoutParams(1,1,Gravity.TOP|Gravity.LEFT));
            leftPanel=panel(getContext(),0xff171b22);centerPanel=panel(getContext(),Color.BLACK);rightPanel=panel(getContext(),0xff171b22);
            world.addView(leftPanel,new FrameLayout.LayoutParams(1,1));world.addView(centerPanel,new FrameLayout.LayoutParams(1,1));world.addView(rightPanel,new FrameLayout.LayoutParams(1,1));
            leftImage=image(getContext());leftPanel.addView(leftImage,new FrameLayout.LayoutParams(-1,-1));leftLabTexture=new TextureView(getContext());leftLabTexture.setOpaque(true);leftLabTexture.setVisibility(View.GONE);leftPanel.addView(leftLabTexture,new FrameLayout.LayoutParams(-1,-1));leftLabel=label(getContext(),"LEFT\nSNAPSHOT");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1));leftCursor=new CursorOverlay(getContext());leftPanel.addView(leftCursor,new FrameLayout.LayoutParams(-1,-1));
            texture=new TextureView(getContext());texture.setOpaque(true);centerPanel.addView(texture,new FrameLayout.LayoutParams(-1,-1));TextView ct=tag(getContext(),"CENTRE • LIVE");FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=10;centerPanel.addView(ct,ctlp);
            rightImage=image(getContext());rightPanel.addView(rightImage,new FrameLayout.LayoutParams(-1,-1));rightLabTexture=new TextureView(getContext());rightLabTexture.setOpaque(true);rightLabTexture.setVisibility(View.GONE);rightPanel.addView(rightLabTexture,new FrameLayout.LayoutParams(-1,-1));rightLabel=label(getContext(),"RIGHT\nSNAPSHOT");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1));rightCursor=new CursorOverlay(getContext());rightPanel.addView(rightCursor,new FrameLayout.LayoutParams(-1,-1));
            setContentView(root);
        }
        private static FrameLayout panel(Context c,int bg){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(bg);f.setClipChildren(true);f.setElevation(2f);return f;}
        private static ImageView image(Context c){ImageView i=new ImageView(c);i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);i.setVisibility(View.GONE);return i;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(28);v.setGravity(Gravity.CENTER);v.setTextColor(0xffe0e0e0);v.setBackgroundColor(0xff171b22);return v;}
        private static TextView tag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(13);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }

    private static class CursorOverlay extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private float x,y; private boolean visible,inside;
        CursorOverlay(Context c){super(c);setWillNotDraw(false);setClickable(false);setFocusable(false);}
        void setCursor(float x, float y, boolean visible, boolean inside) {
            if (this.visible == visible && (!visible || (this.x == x && this.y == y && this.inside == inside))) return;
            this.x = x;
            this.y = y;
            this.visible = visible;
            this.inside = inside;
            invalidate();
        }
        @Override protected void onDraw(Canvas canvas){
            super.onDraw(canvas); if(!visible)return;
            paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(5f);paint.setColor(inside?Color.WHITE:0xffb0b0b0);
            canvas.drawCircle(x,y,15f,paint);canvas.drawLine(x-24f,y,x+24f,y,paint);canvas.drawLine(x,y-24f,x,y+24f,paint);
            paint.setStyle(Paint.Style.FILL);paint.setColor(0xff111111);canvas.drawCircle(x,y,4f,paint);
        }
    }
}
