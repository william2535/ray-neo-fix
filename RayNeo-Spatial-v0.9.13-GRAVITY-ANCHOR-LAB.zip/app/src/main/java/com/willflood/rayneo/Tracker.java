package com.willflood.rayneo;

/** Rate filter for the virtual mouse, separate from the spatial orientation estimator. */
final class Tracker {
    volatile double deadzone = 2.0;
    volatile double smooth = 0.35;
    private final double[] bias = new double[3];
    private final double[] raw = new double[3];
    final double[] rate = new double[3];
    private long stillSinceNs;

    void setBias(double gx, double gy, double gz) {
        bias[0] = gx;
        bias[1] = gy + gz;
        bias[2] = gy - gz;
        rate[0] = rate[1] = rate[2] = 0;
        stillSinceNs = 0;
    }

    void update(double gx, double gy, double gz) {
        raw[0] = gx;
        raw[1] = gy + gz;
        raw[2] = gy - gz;
        boolean moving = false;
        for (int i = 0; i < 3; i++) {
            double r = raw[i] - bias[i];
            if (Math.abs(r) < deadzone) r = 0;
            else moving = true;
            rate[i] = rate[i] * smooth + r * (1 - smooth);
        }

        long now = System.nanoTime();
        if (moving) stillSinceNs = 0;
        else if (stillSinceNs == 0) stillSinceNs = now;
        else if (now - stillSinceNs > 1_000_000_000L) {
            for (int i = 0; i < 3; i++) {
                bias[i] += (raw[i] - bias[i]) * 0.02;
                rate[i] = 0;
            }
        }
    }
}
