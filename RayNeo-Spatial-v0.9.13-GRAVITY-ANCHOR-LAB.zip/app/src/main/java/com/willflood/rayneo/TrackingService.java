package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.hardware.usb.*;
import android.os.*;
import java.nio.*;
import java.util.concurrent.atomic.AtomicBoolean;

public class TrackingService extends Service {
    // Same-process high-rate pose bridge for AnchorActivity.
    // Avoids pushing ~118 Hz IMU updates through Android broadcasts.
    public static volatile double livePitch = 0.0;
    public static volatile double liveYaw = 0.0;
    public static volatile double liveRoll = 0.0;
    public static volatile long livePoseSequence = 0L;
    public static volatile boolean livePoseValid = false;
    public static volatile boolean liveGravityTrusted = false;
    public static final String ACTION_START = "com.willflood.rayneo.START";
    public static final String ACTION_STOP = "com.willflood.rayneo.STOP";
    public static final String ACTION_RECENTER = "com.willflood.rayneo.RECENTER";
    public static final String ACTION_RECALIBRATE = "com.willflood.rayneo.RECALIBRATE";
    public static final String ACTION_CONFIG = "com.willflood.rayneo.CONFIG";
    // The dashboard and tracker share a process. Only the newest sample matters.
    static final class Readings {
        final String status;
        final double pitch, yaw, roll, temp;
        final long frames;

        Readings(String status, double pitch, double yaw, double roll, double temp, long frames) {
            this.status = status;
            this.pitch = pitch;
            this.yaw = yaw;
            this.roll = roll;
            this.temp = temp;
            this.frames = frames;
        }
    }
    static volatile Readings latestReadings;
    private static TrackingService instance;

    // Called from the main thread, like the service lifecycle callbacks.
    static boolean isTracking() {
        return instance != null && instance.running;
    }

    private static final int VID=0x1BBB, PID=0xAF50;
    private static final byte[] ENABLE=new byte[]{0x66,0x01};
    private static final long CALIBRATION_TIMEOUT_NS = 12_000_000_000L;
    private static final String CALIBRATING = "Calibrating • face forward and hold still for 2 seconds";
    private final AtomicBoolean recalibrate = new AtomicBoolean(), recentre = new AtomicBoolean();
    private volatile boolean running=false;
    private volatile Thread worker;
    private UsbDeviceConnection conn;
    private UsbRequest request;
    private UsbInterface intf;
    private UsbEndpoint inEp;
    private int mouseFd=-1;
    private final Tracker tracker=new Tracker();
    private volatile double sens=25.0;
    private volatile boolean invertX=false, invertY=false, mouseEnabled=true;
    private volatile long lastMouseRetryMs=0L;
    private double liveTemperature;
    private double carryX=0, carryY=0;
    private PowerManager.WakeLock wakeLock;

    @Override public void onCreate() {
        super.onCreate();
        instance = this;
        createChannel();
        startForeground(7, makeNotification("Waiting for RayNeo"));
        PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);
        wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"RayNeo:Tracking");
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent==null) return START_STICKY;
        String a=intent.getAction();
        if (ACTION_STOP.equals(a)) { stopTracking(); return START_NOT_STICKY; }
        if (ACTION_RECENTER.equals(a)) { recentre.set(true); return START_STICKY; }
        if (ACTION_RECALIBRATE.equals(a)) { recalibrate.set(true); return START_STICKY; }
        if (ACTION_CONFIG.equals(a) || ACTION_START.equals(a)) applyConfig(intent);
        if (ACTION_START.equals(a) && !running) startTracking();
        return START_STICKY;
    }

    private void applyConfig(Intent i) {
        sens=i.getDoubleExtra("sens",sens);
        tracker.deadzone=i.getDoubleExtra("deadzone",tracker.deadzone);
        tracker.smooth=i.getDoubleExtra("smooth",tracker.smooth);
        invertX=i.getBooleanExtra("invertX",invertX);
        invertY=i.getBooleanExtra("invertY",invertY);
        boolean previousMouseEnabled=mouseEnabled;
        mouseEnabled=i.getBooleanExtra("mouse",mouseEnabled);
        // v0.9.11: if side-screen control or an app lifecycle transition disabled the
        // centre mouse, turning it back on now also re-opens /dev/uinput if necessary.
        if (mouseEnabled && !previousMouseEnabled) lastMouseRetryMs = 0;
    }

    private synchronized void startTracking() {
        if (!wakeLock.isHeld()) wakeLock.acquire();
        startForeground(7, makeNotification("Starting RayNeo tracking"));
        livePoseValid=false;
        livePoseSequence=0L;
        liveGravityTrusted=false;
        recalibrate.set(false);
        recentre.set(false);
        carryX = carryY = liveTemperature = 0;
        running=true;
        latestReadings = new Readings("Starting… face forward and hold still", 0, 0, 0, 0, 0);
        worker=new Thread(this::runLoop,"RayNeo-IMU");
        worker.start();
    }

    private UsbDevice findDevice(UsbManager um) {
        for (UsbDevice d: um.getDeviceList().values())
            if (d.getVendorId()==VID && d.getProductId()==PID) return d;
        return null;
    }

    private synchronized boolean openUsb() {
        if (!running || worker != Thread.currentThread()) return false;
        UsbManager um=(UsbManager)getSystemService(USB_SERVICE);
        UsbDevice dev=findDevice(um);
        if (dev==null) { fail("RayNeo not connected"); return false; }
        if (!um.hasPermission(dev)) { fail("USB permission missing - reopen app and press Start"); return false; }

        conn=um.openDevice(dev);
        if (conn==null) { fail("Could not open RayNeo USB device"); return false; }
        intf=null; inEp=null;
        for (int i=0;i<dev.getInterfaceCount();i++) {
            UsbInterface ui=dev.getInterface(i);
            for (int e=0;e<ui.getEndpointCount();e++) {
                UsbEndpoint ep=ui.getEndpoint(e);
                if (ep.getAddress()==0x81) { intf=ui; inEp=ep; break; }
            }
            if (inEp!=null) break;
        }
        if (intf==null || inEp==null) { fail("Could not find HID endpoint 0x81"); return false; }
        if (!conn.claimInterface(intf,true)) { fail("Could not claim RayNeo interface"); return false; }
        request=new UsbRequest();
        if (!request.initialize(conn,inEp)) { fail("Could not initialise interrupt endpoint"); return false; }

        return true;
    }

    private void runLoop() {
        if (!openUsb()) return;
        if (mouseEnabled) openMouse();

        SpatialPose pose = new SpatialPose();
        double[] gyroBias = null;
        StillCalibration calibration = new StillCalibration();
        long deadline = System.nanoTime() + CALIBRATION_TIMEOUT_NS;
        long lastPacket = 0, lastUi = 0, lastValid = 0, frames = 0;
        String statusNote = CALIBRATING;
        sendStatus(statusNote, 0, 0, 0, 0, 0);

        while (running && worker == Thread.currentThread()) {
            long now = System.nanoTime();
            if (recalibrate.getAndSet(false)) {
                calibration = new StillCalibration();
                deadline = now + CALIBRATION_TIMEOUT_NS;
                statusNote = gyroBias == null ? CALIBRATING : "Recalibrating • keep your head still";
                sendStatus(statusNote, pose.pitch, pose.yaw, pose.roll, liveTemperature, frames);
            }
            if (calibration != null && now >= deadline) {
                if (gyroBias == null) {
                    fail("Calibration timed out. Face forward, hold still and press Start to retry.");
                    return;
                }
                calibration = null;
                statusNote = "Recalibration timed out • previous calibration active. Tap Recalibrate to retry.";
                sendStatus(statusNote, pose.pitch, pose.yaw, pose.roll, liveTemperature, frames);
            }
            ByteBuffer frame = pollFrame();
            if (!running || worker != Thread.currentThread()) return;
            now = System.nanoTime();
            if (frame == null) {
                // Ignore non-IMU reports; dt spans real IMU packets and rejects long gaps.
                if (lastValid != 0 && now - lastValid > 250_000_000L && livePoseValid) {
                    invalidateStalePose();
                    sendStatus(statusNote != null ? statusNote : "Waiting for fresh IMU data",
                            pose.pitch, pose.yaw, pose.roll, liveTemperature, frames);
                }
                continue;
            }
            double dt = lastPacket == 0 ? 0 : (now - lastPacket) * 1e-9;
            lastPacket = now;
            double ax = frame.getFloat(4), ay = frame.getFloat(8), az = frame.getFloat(12);
            double gx = frame.getFloat(16), gy = frame.getFloat(20), gz = frame.getFloat(24);
            double temp = frame.getFloat(28);
            if (Double.isFinite(temp)) liveTemperature = temp;
            if (calibration != null && calibration.add(gx, gy, gz, ax, ay, az, dt)) {
                if (gyroBias == null) {
                    pose.reset(calibration.gravity[0], calibration.gravity[1], calibration.gravity[2]);
                    updateNotification("Head tracking active");
                } else {
                    // Keep the current orientation, pin and recenter offsets across a bias change.
                    pose.clearBias();
                }
                gyroBias = calibration.gyroBias;
                tracker.setBias(gyroBias[0], gyroBias[1], gyroBias[2]);
                calibration = null;
                statusNote = null;
            }
            if (gyroBias == null) continue;
            double cx = gx - gyroBias[0], cy = gy - gyroBias[1], cz = gz - gyroBias[2];
            boolean valid = dt > 0 && dt <= 0.1 && SpatialPose.validGyro(gx, gy, gz) && SpatialPose.validGyro(cx, cy, cz);
            pose.update(cx, cy, cz, ax, ay, az, valid ? dt : 0);
            if (!valid) {
                invalidateStalePose();
                continue;
            }
            if (recentre.getAndSet(false)) {
                pose.recentre();
                carryX = carryY = 0;
            }
            tracker.update(gx, gy, gz);
            if (!publishPose(pose, ++frames)) return;
            lastValid = now;

            if (mouseEnabled && mouseFd<0) {
                long retryNow=SystemClock.uptimeMillis();
                if(retryNow-lastMouseRetryMs>2000L){lastMouseRetryMs=retryNow;openMouse();}
            }
            moveMouse(dt);
            if (now-lastUi>100_000_000L) {
                lastUi=now;
                String text = statusNote != null ? statusNote :
                        (mouseEnabled && mouseFd>=0 ? "Tracking → virtual mouse" : "Tracking → angles");
                sendStatus(text, pose.pitch, pose.yaw, pose.roll, liveTemperature, frames);
            }
        }
    }

    private synchronized boolean publishPose(SpatialPose pose, long frames) {
        if (!running || worker != Thread.currentThread()) return false;
        livePitch = pose.pitch;
        liveYaw = pose.yaw;
        liveRoll = pose.roll;
        liveGravityTrusted = pose.gravityTrusted;
        livePoseSequence = frames;
        livePoseValid = true;
        return true;
    }

    private synchronized void invalidateStalePose() {
        if (worker == Thread.currentThread()) {
            livePoseValid = false;
            liveGravityTrusted = false;
        }
    }

    private ByteBuffer pollFrame() {
        // Stop may close the USB handles while this worker is waiting.
        UsbDeviceConnection connection = conn;
        UsbRequest readRequest = request;
        if (connection == null || readRequest == null) return null;
        try {
            int rc=connection.controlTransfer(0x21,0x09,0x0301,0,ENABLE,2,600);
            if (rc<0) return null;
            ByteBuffer b=ByteBuffer.allocateDirect(64).order(ByteOrder.LITTLE_ENDIAN);
            if (!readRequest.queue(b) || connection.requestWait(100) != readRequest) return null;
            if (b.position()<32 || (b.get(0)&0xff)!=0x99 || (b.get(1)&0xff)!=0x65) return null;
            return b;
        } catch (Exception e) {
            return null;
        }
    }

    private void openMouse() {
        synchronized (this) {
            if (!running || worker != Thread.currentThread() || mouseFd >= 0) return;
            try { mouseFd = NativeUInput.openMouse(); }
            catch (Throwable t) { mouseFd = -99999; }
            if (mouseFd < 0) {
                sendStatus("IMU works, but /dev/uinput mouse failed: " + mouseFd, 0, 0, 0, 0, 0);
                return;
            }
        }
        SystemClock.sleep(300);
    }

    private synchronized void moveMouse(double dt) {
        if (!running || worker != Thread.currentThread() || !mouseEnabled || mouseFd < 0) return;
        double sx = invertX ? -1 : 1, sy = invertY ? -1 : 1;
        carryX -= sx * tracker.rate[1] * dt * sens;
        carryY += sy * tracker.rate[0] * dt * sens;
        int dx = (int)carryX, dy = (int)carryY;
        carryX -= dx;
        carryY -= dy;
        if (dx != 0 || dy != 0) NativeUInput.moveMouse(mouseFd, dx, dy);
    }

    private synchronized void sendStatus(String text,double pitch,double yaw,double roll,double temp,long frames) {
        if (running && (worker == null || worker == Thread.currentThread())) {
            latestReadings = new Readings(text, pitch, yaw, roll, temp, frames);
        }
    }

    private synchronized void markStopped() {
        running = false;
        livePoseValid = false;
        liveGravityTrusted = false;
        latestReadings = new Readings("Tracking stopped", 0, 0, 0, 0, 0);
    }

    private synchronized void fail(String s) {
        if (!running || worker != Thread.currentThread()) return;
        sendStatus(s,0,0,0,0,0);
        running=false;
        livePoseValid=false;
        liveGravityTrusted=false;
        cleanupAll();
        if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        stopForeground(true);
        stopSelf();
    }

    private void stopTracking() {
        markStopped();
        cleanupAll();
        stopForeground(true);
        stopSelf();
    }

    private synchronized void cleanupUsb() {
        try { if (request!=null) request.close(); } catch(Exception ignored) {}
        request=null;
        try { if (conn!=null && intf!=null) conn.releaseInterface(intf); } catch(Exception ignored) {}
        try { if (conn!=null) conn.close(); } catch(Exception ignored) {}
        conn=null; intf=null; inEp=null;
    }

    private synchronized void cleanupAll() {
        if (mouseFd>=0) { try { NativeUInput.closeMouse(mouseFd); } catch(Throwable ignored) {} }
        mouseFd=-1;
        cleanupUsb();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT>=26) {
            NotificationChannel c=new NotificationChannel("tracking","RayNeo head tracking",NotificationManager.IMPORTANCE_LOW);
            ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(c);
        }
    }
    private Notification makeNotification(String text) {
        Intent open=new Intent(this,MainActivity.class);
        PendingIntent pi=PendingIntent.getActivity(this,0,open,PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
        return new Notification.Builder(this,"tracking").setContentTitle("RayNeo Head Tracker")
                .setContentText(text).setSmallIcon(android.R.drawable.ic_menu_compass).setContentIntent(pi).setOngoing(true).build();
    }
    private void updateNotification(String text) { ((NotificationManager)getSystemService(NOTIFICATION_SERVICE)).notify(7,makeNotification(text)); }

    @Override public void onDestroy() {
        if (running) markStopped();
        instance = null;
        cleanupAll();
        if (wakeLock!=null && wakeLock.isHeld()) wakeLock.release();
        super.onDestroy();
    }
    @Override public IBinder onBind(Intent intent) { return null; }
}
