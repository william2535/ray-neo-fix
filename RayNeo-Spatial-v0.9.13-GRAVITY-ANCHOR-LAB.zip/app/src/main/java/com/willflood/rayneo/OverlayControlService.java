package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.content.res.ColorStateList;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;

/**
 * Small draggable system overlay used while another Android app is in the foreground.
 * Snap commands hide the overlay briefly before asking AnchorActivity to grab the
 * current TextureView frame, then restore the overlay afterwards.
 */
public class OverlayControlService extends Service {
    private static final String CHANNEL_ID = "rayneo_anchor_controls";
    private WindowManager wm;
    private LinearLayout bar;
    private WindowManager.LayoutParams params;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override public void onCreate() {
        super.onCreate();
        createChannel();
        Notification n = new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("RayNeo Spatial Controls")
                .setContentText("Floating Snap / Pin controls are active")
                .setOngoing(true)
                .build();
        startForeground(2208, n);
        showOverlay();
    }

    private void createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel c = new NotificationChannel(CHANNEL_ID, "RayNeo Spatial Controls", NotificationManager.IMPORTANCE_LOW);
            c.setDescription("Keeps the floating spatial desktop controls available over other apps");
            getSystemService(NotificationManager.class).createNotificationChannel(c);
        }
    }

    private int dp(int size) {
        return Math.round(size * getResources().getDisplayMetrics().density);
    }

    private Button control(String label, String description) {
        Button button = new Button(new ContextThemeWrapper(this, R.style.TrackerTheme));
        button.setText(label);
        button.setContentDescription(description);
        button.setAllCaps(false);
        button.setTextSize(14);
        button.setMinWidth(dp(48));
        button.setMinimumWidth(dp(48));
        button.setMinHeight(dp(48));
        button.setGravity(Gravity.CENTER);
        button.setPadding(dp(6), dp(2), dp(6), dp(2));
        return button;
    }

    private void showOverlay() {
        if (bar != null) return;
        wm = (WindowManager)getSystemService(WINDOW_SERVICE);
        bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundResource(R.drawable.tracker_card);
        bar.setPadding(dp(2), dp(2), dp(2), dp(2));

        Button left = control("Snap L", "Take a snapshot for the left screen");
        Button pin = control("Pin", "Pin here. Drag to move floating controls.");
        pin.setBackgroundTintList(ColorStateList.valueOf(getColor(R.color.tracker_accent)));
        pin.setTextColor(getColor(R.color.tracker_ink));
        Button right = control("Snap R", "Take a snapshot for the right screen");
        Button close = control("×", "Close floating controls");
        bar.addView(left); bar.addView(pin); bar.addView(right); bar.addView(close);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        params.gravity = Gravity.TOP | Gravity.LEFT;
        params.x = dp(8);
        params.y = dp(48);
        pin.setOnTouchListener(new PinGesture());

        left.setOnClickListener(v -> snapshot(AnchorActivity.CMD_SNAP_LEFT));
        right.setOnClickListener(v -> snapshot(AnchorActivity.CMD_SNAP_RIGHT));
        pin.setOnClickListener(v -> send(AnchorActivity.CMD_PIN));
        close.setOnClickListener(v -> stopSelf());

        try { wm.addView(bar, params); }
        catch (Throwable t) { stopSelf(); }
    }

    private class PinGesture implements View.OnTouchListener {
        private final int slop = ViewConfiguration.get(OverlayControlService.this).getScaledTouchSlop();
        private float downX, downY;
        private int windowX, windowY;
        private boolean dragging, cancelled;

        private boolean moved(float dx, float dy) {
            return dx * dx + dy * dy > slop * slop;
        }

        @Override public boolean onTouch(View view, MotionEvent event) {
            float dx = event.getRawX() - downX;
            float dy = event.getRawY() - downY;
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    downX = event.getRawX();
                    downY = event.getRawY();
                    windowX = params.x;
                    windowY = params.y;
                    dragging = cancelled = false;
                    view.setPressed(true);
                    break;
                case MotionEvent.ACTION_MOVE:
                    if (cancelled) break;
                    if (moved(dx, dy)) dragging = true;
                    if (dragging) {
                        view.setPressed(false);
                        params.x = windowX + Math.round(dx);
                        params.y = windowY + Math.round(dy);
                        if (bar.isAttachedToWindow()) wm.updateViewLayout(bar, params);
                    }
                    break;
                case MotionEvent.ACTION_UP:
                    view.setPressed(false);
                    if (!cancelled && !dragging && !moved(dx, dy)) view.performClick();
                    break;
                case MotionEvent.ACTION_CANCEL:
                case MotionEvent.ACTION_POINTER_DOWN:
                    cancelled = true;
                    view.setPressed(false);
                    break;
            }
            return true;
        }
    }

    private void snapshot(String command) {
        if (bar == null) return;
        bar.setVisibility(View.INVISIBLE);
        // Give SurfaceFlinger two-ish frames to remove the overlay from the captured image.
        handler.postDelayed(() -> send(command), 70);
        handler.postDelayed(() -> { if (bar != null) bar.setVisibility(View.VISIBLE); }, 260);
    }

    private void send(String command) {
        Intent i = new Intent(AnchorActivity.ACTION_OVERLAY)
                .setPackage(getPackageName())
                .putExtra(AnchorActivity.EXTRA_COMMAND, command);
        sendBroadcast(i);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId) { return START_STICKY; }
    @Override public android.os.IBinder onBind(Intent intent) { return null; }

    @Override public void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        if (bar != null && wm != null) {
            try { wm.removeView(bar); } catch (Throwable ignored) {}
        }
        bar = null;
        stopForeground(true);
        super.onDestroy();
    }
}
