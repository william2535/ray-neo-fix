package com.willflood.rayneo;

/** Six-axis attitude for the screen. All sensor inputs are in the original USB sensor axes. */
final class SpatialPose {
    private static final double RAD = Math.PI / 180.0;
    // Nods were about +X. Yaw sweeps gave gz/gy ≈ 0.28 on the measured Air 4 Pro.
    private static final double UP_Y = 1 / Math.hypot(1, 0.28), UP_Z = 0.28 * UP_Y;
    private static final double KP = 2.2, KI = 0.36;
    private static final double MAX_BIAS = 4 * RAD;
    private static final double TRUST_DOT = Math.cos(12 * RAD);
    private static final double REST_DOT = Math.cos(1.5 * RAD);

    // Unit quaternion, sensor to startup world. The world gravity reference never rotates.
    private double w = 1, x, y, z;
    private double refX, refY, refZ, upSign;
    private double rightX, rightY, rightZ, frontX, frontY, frontZ;
    private double biasX, biasY, biasZ; // additional, observable tilt bias, radians/s
    private double stillX, stillY, stillZ, recoveryTime;
    private double elevation, heading, bank, lastHeading, zeroElevation, zeroHeading, zeroBank;
    private boolean ready;
    double pitch, yaw, roll;
    boolean gravityTrusted;

    // Called with the mean from a verified still window, in a normal upright viewing posture.
    void reset(double ax, double ay, double az) {
        double n = norm(ax, ay, az);
        if (!Double.isFinite(n) || n < 1) throw new IllegalArgumentException("Missing gravity reference");
        refX = ax/n; refY = ay/n; refZ = az/n;
        upSign = refY*UP_Y + refZ*UP_Z < 0 ? -1 : 1;
        double ux = refX*upSign, uy = refY*upSign, uz = refZ*upSign;
        // Screen-forward is +X cross nominal head-up. Project onto Earth's horizontal plane.
        rightX = uy*UP_Y + uz*UP_Z;
        rightY = -ux*UP_Y;
        rightZ = -ux*UP_Z;
        n = norm(rightX, rightY, rightZ);
        if (n < 0.01) { // gaze vertical: choose the lateral sensor axis as initial azimuth
            rightX = 1; rightY = rightZ = 0;
        } else {
            rightX /= n; rightY /= n; rightZ /= n;
        }
        frontX = rightY*uz - rightZ*uy;
        frontY = rightZ*ux - rightX*uz;
        frontZ = rightX*uy - rightY*ux;

        w = 1; x = y = z = biasX = biasY = biasZ = recoveryTime = 0;
        heading = lastHeading = zeroElevation = zeroHeading = zeroBank = 0;
        ready = gravityTrusted = true;
        readAngles();
        recentre();
    }

    void update(double gx, double gy, double gz, double ax, double ay, double az, double dt) {
        if (!ready) return;
        if (!(dt > 0 && dt <= 0.1) || !validGyro(gx, gy, gz)) {
            gravityTrusted = false;
            recoveryTime = 0;
            return;
        }
        // Gyro propagation never depends on mouse smoothing or its deadzone.
        rotate((gx*RAD-biasX)*dt, (gy*RAD-biasY)*dt, (gz*RAD-biasZ)*dt);
        double n = norm(ax, ay, az);
        gravityTrusted = false;
        if (n >= 9.1 && n <= 10.5) {
            ax /= n; ay /= n; az /= n;
            // Inverse-rotate the reference gravity into current sensor coordinates.
            double tx = 2*(y*refZ-z*refY), ty = 2*(z*refX-x*refZ), tz = 2*(x*refY-y*refX);
            double px = refX-w*tx+y*tz-z*ty;
            double py = refY-w*ty+z*tx-x*tz;
            double pz = refZ-w*tz+x*ty-y*tx;
            double dot = ax*px + ay*py + az*pz;
            double speed = norm(gx, gy, gz);
            if (dot < TRUST_DOT && speed < 4.0) {
                // Reacquire after missing samples. A single sideways jolt cannot start recovery.
                if (recoveryTime == 0 || ax*stillX+ay*stillY+az*stillZ < REST_DOT) {
                    stillX = ax; stillY = ay; stillZ = az; recoveryTime = 0;
                }
                recoveryTime += dt;
            } else {
                recoveryTime = 0;
            }
            gravityTrusted = dot >= TRUST_DOT || recoveryTime >= 1.5;
            if (gravityTrusted) {
                double ex = ay*pz-az*py, ey = az*px-ax*pz, ez = ax*py-ay*px;
                // Accelerometer innovation has no component about gravity (heading is unobservable).
                if (dot >= TRUST_DOT && speed < 8.0) {
                    biasX = clamp(biasX-KI*ex*dt, MAX_BIAS);
                    biasY = clamp(biasY-KI*ey*dt, MAX_BIAS);
                    biasZ = clamp(biasZ-KI*ez*dt, MAX_BIAS);
                }
                // At an exact half-turn the cross product vanishes. Any perpendicular
                // axis is a valid return path; prefer the pitch axis projected onto that plane.
                if (dot < -0.99999 && norm(ex,ey,ez) < 0.001) {
                    if (Math.abs(px) < 0.8) {
                        ex = 1-px*px; ey = -px*py; ez = -px*pz;
                    } else {
                        ex = -py*px; ey = 1-py*py; ez = -py*pz;
                    }
                }
                double sinError = norm(ex,ey,ez);
                double correctionRate = Math.min(12*RAD, KP*Math.atan2(sinError, dot));
                double step = correctionRate*dt/Math.max(1e-9, sinError);
                rotate(ex*step, ey*step, ez*step);
            }
        } else {
            recoveryTime = 0;
        }
        readAngles();
    }

    static boolean validGyro(double gx, double gy, double gz) {
        return Math.abs(gx) <= 2000 && Math.abs(gy) <= 2000 && Math.abs(gz) <= 2000;
    }

    // After a new measured gyro bias, discard the residual learnt against the old one.
    void clearBias() { biasX = biasY = biasZ = 0; }

    void recentre() {
        zeroElevation = elevation; zeroHeading = heading; zeroBank = bank;
        pitch = yaw = roll = 0;
    }

    private void readAngles() {
        // Rotate the fixed display-forward vector (0,-UP_Z,UP_Y) and display-right (+X).
        double tx = 2*(y*UP_Y+z*UP_Z), ty = -2*x*UP_Y, tz = -2*x*UP_Z;
        double fx = w*tx+y*tz-z*ty;
        double fy = -UP_Z+w*ty+z*tx-x*tz;
        double fz = UP_Y+w*tz+x*ty-y*tx;
        double vertical = upSign*(refX*fx+refY*fy+refZ*fz);
        double lateral = fx*rightX+fy*rightY+fz*rightZ;
        double forward = fx*frontX+fy*frontY+fz*frontZ;
        double horizontal = Math.hypot(lateral, forward);
        elevation = -Math.atan2(vertical, horizontal)/RAD;
        if (horizontal > 0.02) {
            double wrapped = Math.atan2(lateral, forward)/RAD;
            heading += wrap(wrapped-lastHeading);
            lastHeading = wrapped;
            // Our fixed head basis is right × up = forward. Use (forward × right)
            // for head-up so the bank uses the same mounting convention as the gaze.
            double rx = 1-2*(y*y+z*z), ry = 2*(x*y+w*z), rz = 2*(x*z-w*y);
            double rightUp = upSign*(refX*rx + refY*ry + refZ*rz);
            double headUp = upSign*(refX*(fy*rz-fz*ry) + refY*(fz*rx-fx*rz) + refZ*(fx*ry-fy*rx));
            bank = -Math.atan2(rightUp, headUp)/RAD;
        }
        pitch = elevation-zeroElevation;
        yaw = heading-zeroHeading;
        roll = wrap(bank-zeroBank);
    }

    // Post-multiply by the body-frame rotation for this sample, then renormalise.
    private void rotate(double rx, double ry, double rz) {
        double angle = norm(rx, ry, rz);
        double scale = angle < 1e-8 ? 0.5 : Math.sin(angle*0.5)/angle;
        double cw = Math.cos(angle*0.5), cx = rx*scale, cy = ry*scale, cz = rz*scale;
        double nw = w*cw-x*cx-y*cy-z*cz, nx = w*cx+x*cw+y*cz-z*cy;
        double ny = w*cy-x*cz+y*cw+z*cx, nz = w*cz+x*cy-y*cx+z*cw;
        double inv = 1/Math.sqrt(nw*nw+nx*nx+ny*ny+nz*nz);
        w = nw*inv; x = nx*inv; y = ny*inv; z = nz*inv;
    }

    private static double norm(double a,double b,double c) { return Math.sqrt(a*a+b*b+c*c); }
    private static double clamp(double a,double max) { return Math.max(-max,Math.min(max,a)); }
    private static double wrap(double a) { return a > 180 ? a-360 : a < -180 ? a+360 : a; }
}
