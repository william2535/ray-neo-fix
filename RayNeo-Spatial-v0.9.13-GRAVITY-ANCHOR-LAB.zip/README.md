# RayNeo Spatial v0.9.13 LAB

Spatial Desktop now combines raw Air 4 Pro gyroscope and accelerometer samples for the pinned screen. Keep the glasses upright and still at startup. Once tracking begins, open **Spatial Desktop**, start the anchor and select **Pin here**.

To check the slow upward drift, support the glasses on a fixed surface, open **Live diagnostics → Measure drift** and keep the page open for 60 seconds. The result includes signed pitch and yaw change, plus estimated vertical pixels when the external display size is available.

Read the [tracking design, bench procedure and simulated results](https://github.com/william2535/ray-neo-fix/blob/main/docs/spatial-tracking.md). Run the deterministic tests using the instructions in [tests/README.md](tests/README.md).
