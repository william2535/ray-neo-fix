# RayNeo Spatial v0.9.9 — Unbounded Vertical World LAB

This build fixes the v0.9.8 screen-placement clipping bug.

## What changed

- The spatial world is now **7 display-heights tall** instead of only one display-height.
- LEFT / CENTRE / RIGHT are placed around the vertical centre of that larger world.
- Head-pitch camera movement is offset so the normal straight-ahead view looks the same as before.
- Panels can be dragged well above or below the original display-height boundary and should become fully visible when you look toward them instead of being hard-clipped.
- Existing v0.9.8 placement gestures are unchanged: select a panel, drag to position, pinch to resize, lock layout.
- Existing saved v0.9.8 layout preferences are retained.
- Tracking, independent apps, software cursor/click, Shizuku isolation and sticky side-app behaviour are unchanged.

## Test

1. Start tracking and Spatial Desktop normally.
2. Select one panel in the placement editor.
3. Drag it above the height that previously caused clipping.
4. Look upward toward it.
5. Confirm the whole panel can be revealed instead of being chopped at the old world boundary.
6. Repeat below the original display area.

This is still an experimental LAB build. Keep the public v0.8 release unchanged.
