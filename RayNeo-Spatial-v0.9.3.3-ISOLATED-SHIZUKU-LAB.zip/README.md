# RayNeo Spatial v0.9.3.3 — Isolated Shizuku Process LAB

This is a diagnostic follow-up to v0.9.3.2.

## Why this build exists
v0.9.1 proved the tracker + manual LEFT/RIGHT VirtualDisplays are smooth.
v0.9.3.2 placed Shizuku's provider/listeners in the same app process and the device regressed to slow tracking / Anchor crash.

## v0.9.3.3 architecture
- Main process: v0.9.1 tracker, MediaProjection, Presentation and VirtualDisplays.
- `:shizuku` process: ShizukuProvider + tiny transparent ShizukuBridgeActivity only.
- The main process never imports/calls Shizuku.
- CONNECT/LAUNCH starts the isolated bridge and receives only a result broadcast.

## Test order
1. Keep Shizuku running.
2. Start RayNeo tracking. It must be smooth before doing anything else.
3. Open Spatial Desktop. It must open like v0.9.1.
4. Start Anchor and confirm centre tracking is smooth.
5. Press CONNECT SHIZUKU and allow permission if asked.
6. CREATE LEFT DISPLAY, then LAUNCH LEFT APP.
7. Repeat for RIGHT.

If step 2 or 3 regresses, stop: Shizuku is still affecting this device despite process isolation.
