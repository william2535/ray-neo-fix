# RayNeo Spatial v0.9.12 LAB

For the RayNeo Air 4 Pro on Android. Start tracking with the glasses still for the first two seconds. Use **Recentre** to reset the direction or **Recalibrate** to measure the gyro bias again.

The setup screen puts the session controls first and places mouse settings alongside them on wider handhelds. Sensitivity, deadzone, smoothing and axis switches are saved on the device. Use **Hide live readings** to fold away the telemetry.

Open **Spatial Desktop** to start an anchor session, pin the current direction or enable floating controls over another app. Select a screen and use the pad to drag or pinch it. Open **Side displays and apps** for Shizuku and independent app displays. **Live diagnostics** shows the pose and placement readouts.

## Hardware checks

1. Start tracking and check the status and virtual mouse on the handheld.
2. Leave the handheld untouched for 30 seconds, then recentre and adjust a slider.
3. Open Spatial Desktop, start an anchor and enable floating controls. Open another app, then check that head movement, pinning and snapshots still work.
4. Stop the session, reopen the setup screen and check the saved tuning values.
