# RayNeo Spatial v0.9.3.1 — Shizuku Shell LAB

Corrected experimental build. Keeps the proven v0.9.1 tracking and VirtualDisplay path unchanged and removes the AIDL/UserService layer from v0.9.3.

Start Shizuku, press CONNECT SHIZUKU, create LEFT/RIGHT display, then launch an app onto it. Wireless-debugging Shizuku should report server UID 2000.
