# RayNeo Spatial v0.9.1 — VirtualDisplay Diagnostic LAB

Built directly from the hardware-proven v0.8 source. The v0.8 USB/IMU/tracker/render path is preserved; no side VirtualDisplays are created automatically.

## Purpose
The previous v0.9 experiment made tracking slow and crashed entering Spatial Desktop. v0.9.1 isolates the new Android VirtualDisplay work behind manual buttons and catches all creation errors in the UI.

## Test order
1. Start Tracking. Confirm it feels as smooth as v0.8.
2. Start Anchor. Confirm Centre works and does not crash.
3. Press **CREATE LEFT DISPLAY** only.
4. Read the LAB status. It should show either `SUCCESS — VirtualDisplay ID ...` or the exact Java exception.
5. Check whether tracking remains smooth.
6. Press **DESTROY LEFT**.
7. Repeat with RIGHT.
8. Do not create both simultaneously until each side works independently.

No third-party app launching is attempted in this build. That comes only after VirtualDisplay creation itself is proven stable.

## Public release
Do not replace the public v0.8 beta with this lab build.
