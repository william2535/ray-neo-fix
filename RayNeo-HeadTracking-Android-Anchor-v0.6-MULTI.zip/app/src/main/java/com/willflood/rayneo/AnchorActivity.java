package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/**
 * RayNeo 3DoF anchor v0.6 MULTI.
 *
 * Preserves the proven v0.5 full-rate pose path and safe MediaProjection teardown.
 * Adds a three-panel spatial desktop:
 *   - centre panel is the live Android capture
 *   - left/right panels can hold snapshots of different Android content
 *   - all three panels stay fixed in world yaw and are revealed by turning the head
 *
 * The user's proven Air 4 Pro orientation is now the default: X and Y counter-motion inverted.
 */
public class AnchorActivity extends Activity {
    private static final int REQ_CAPTURE = 4401;
    private static final long DIAGNOSTIC_INTERVAL_MS = 250L;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;
    private AnchorPresentation presentation;

    private TextView status, displayInfo, poseInfo, renderInfo;

    private float screenScale = 0.78f;
    private float panelSpacing = 0.92f; // screen-widths from centre, about +/-42 degrees with 46deg HFOV
    private float hFovDeg = 46.0f;
    private float vFovDeg = 27.0f;
    private float anchorPitch = 0f, anchorYaw = 0f;
    private volatile float latestPitch = 0f, latestYaw = 0f;
    private float filteredPitch = 0f, filteredYaw = 0f;
    private volatile boolean havePose = false;
    private boolean surfaceReady = false;
    private boolean virtualDisplayReady = false;
    private volatile long capturedFrames = 0;

    private boolean anchorRunning = false;
    private boolean stopping = false;
    // Proven correct on the user's hardware in v0.5.
    private boolean invertAnchorX = true;
    private boolean invertAnchorY = true;
    private boolean multiMode = true;
    private long lastRenderNanos = 0L;
    private long lastDiagnosticUiMs = 0L;
    private float lastDx = 0f, lastDy = 0f;

    private final Choreographer.FrameCallback renderFrame = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (!isFinishing() && !isDestroyed()) {
                if (TrackingService.livePoseValid) {
                    latestPitch = (float) TrackingService.livePitch;
                    latestYaw = (float) TrackingService.liveYaw;
                    if (!havePose) {
                        filteredPitch = latestPitch;
                        filteredYaw = latestYaw;
                        anchorPitch = latestPitch;
                        anchorYaw = latestYaw;
                        havePose = true;
                    }
                }

                if (havePose) {
                    float dt = lastRenderNanos == 0L ? (1f / 60f)
                            : Math.min(0.05f, (frameTimeNanos - lastRenderNanos) / 1_000_000_000f);
                    float alpha = 1f - (float)Math.exp(-dt * 28f);
                    filteredPitch += (latestPitch - filteredPitch) * alpha;
                    filteredYaw += (latestYaw - filteredYaw) * alpha;
                }
                lastRenderNanos = frameTimeNanos;
                if (anchorRunning && !stopping) updateAnchorTransform(false);

                long now = SystemClock.uptimeMillis();
                if (now - lastDiagnosticUiMs >= DIAGNOSTIC_INTERVAL_MS) {
                    lastDiagnosticUiMs = now;
                    updatePoseText();
                    updateRenderText(lastDx, lastDy);
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        }
    };

    private final BroadcastReceiver poseReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TrackingService.ACTION_STATUS.equals(intent.getAction())) return;
            latestPitch = (float) intent.getDoubleExtra("pitch", 0.0);
            latestYaw = (float) intent.getDoubleExtra("yaw", 0.0);
            if (!havePose) {
                filteredPitch = latestPitch;
                filteredYaw = latestYaw;
                anchorPitch = latestPitch;
                anchorYaw = latestYaw;
                havePose = true;
            }
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(poseReceiver, new IntentFilter(TrackingService.ACTION_STATUS));
        buildUi();
        refreshDisplayInfo();
        Choreographer.getInstance().postFrameCallback(renderFrame);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 32);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("RAYNEO SPATIAL DESKTOP • v0.6 MULTI");
        title.setTextSize(24);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Three anchored panels. CENTRE is live. SNAP LEFT / SNAP RIGHT stores the current view into that world-fixed panel. Turn your head to look between them.");
        help.setTextSize(13);
        help.setPadding(0, 8, 0, 14);
        root.addView(help);

        status = box(root, "Ready • checking displays…", 0xffe4e7e0, Color.BLACK);
        displayInfo = box(root, "DISPLAY DIAGNOSTICS", 0xff20242a, 0xffd8e2ef);
        poseInfo = box(root, "IMU: waiting for TrackingService…", 0xff16241c, 0xff77e49e);
        renderInfo = box(root, "RENDER: not started", 0xff242024, 0xffffd27a);

        Button refresh = button("REFRESH DISPLAYS", 0xff59645b);
        root.addView(refresh, fullButtonLp());

        CheckBox multiBox = new CheckBox(this);
        multiBox.setText("3-panel spatial desktop");
        multiBox.setChecked(true);
        root.addView(multiBox);

        TextView scaleLabel = new TextView(this);
        scaleLabel.setText("Panel size");
        scaleLabel.setPadding(0, 12, 0, 0);
        root.addView(scaleLabel);
        SeekBar scale = new SeekBar(this);
        scale.setMax(90);
        scale.setProgress(62);
        root.addView(scale);
        screenScale = 0.30f + 0.70f * (scale.getProgress() / 90f);

        TextView spacingLabel = new TextView(this);
        spacingLabel.setText("Left / right spacing");
        spacingLabel.setPadding(0, 8, 0, 0);
        root.addView(spacingLabel);
        SeekBar spacing = new SeekBar(this);
        spacing.setMax(100);
        spacing.setProgress(55);
        root.addView(spacing);
        panelSpacing = 0.55f + 0.70f * (spacing.getProgress() / 100f);

        CheckBox invertXBox = new CheckBox(this);
        invertXBox.setText("Invert horizontal anchor");
        invertXBox.setChecked(true);
        root.addView(invertXBox);
        CheckBox invertYBox = new CheckBox(this);
        invertYBox.setText("Invert vertical anchor");
        invertYBox.setChecked(true);
        root.addView(invertYBox);

        LinearLayout startRow = new LinearLayout(this);
        startRow.setOrientation(LinearLayout.HORIZONTAL);
        startRow.setPadding(0, 14, 0, 0);
        Button capture = button("START ANCHOR", 0xff2f7d4a);
        Button recenter = button("PIN HERE", 0xff59645b);
        startRow.addView(capture, new LinearLayout.LayoutParams(0, -2, 1));
        startRow.addView(recenter, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(startRow);

        LinearLayout snapRow = new LinearLayout(this);
        snapRow.setOrientation(LinearLayout.HORIZONTAL);
        snapRow.setPadding(0, 8, 0, 0);
        Button snapLeft = button("SNAP LEFT", 0xff4f638c);
        Button snapRight = button("SNAP RIGHT", 0xff4f638c);
        snapRow.addView(snapLeft, new LinearLayout.LayoutParams(0, -2, 1));
        snapRow.addView(snapRight, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(snapRow);

        LinearLayout clearRow = new LinearLayout(this);
        clearRow.setOrientation(LinearLayout.HORIZONTAL);
        Button clearLeft = button("CLEAR LEFT", 0xff555555);
        Button clearRight = button("CLEAR RIGHT", 0xff555555);
        clearRow.addView(clearLeft, new LinearLayout.LayoutParams(0, -2, 1));
        clearRow.addView(clearRight, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(clearRow);

        Button stop = button("STOP ANCHOR", 0xffa43f35);
        root.addView(stop, fullButtonLp());

        TextView note = new TextView(this);
        note.setText("v0.6 keeps v0.5's full-rate ~118 Hz pose path. Centre is live; side panels are independent saved views so we can prove a real 3-panel spatial layout without tripling MediaProjection/GPU load.");
        note.setTextSize(13);
        note.setPadding(0, 18, 0, 0);
        root.addView(note);

        refresh.setOnClickListener(v -> refreshDisplayInfo());
        capture.setOnClickListener(v -> requestCapture());
        recenter.setOnClickListener(v -> pinHere());
        stop.setOnClickListener(v -> stopAnchor());

        scale.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                screenScale = 0.30f + 0.70f * (progress / 90f);
                updatePanelGeometry();
            }
        });
        spacing.setOnSeekBarChangeListener(new SimpleSeek() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                panelSpacing = 0.55f + 0.70f * (progress / 100f);
                updatePanelGeometry();
            }
        });
        multiBox.setOnCheckedChangeListener((b, checked) -> {
            multiMode = checked;
            updatePanelGeometry();
        });
        invertXBox.setOnCheckedChangeListener((b, checked) -> invertAnchorX = checked);
        invertYBox.setOnCheckedChangeListener((b, checked) -> invertAnchorY = checked);

        snapLeft.setOnClickListener(v -> snapshotPanel(true));
        snapRight.setOnClickListener(v -> snapshotPanel(false));
        clearLeft.setOnClickListener(v -> clearSnapshot(true));
        clearRight.setOnClickListener(v -> clearSnapshot(false));

        setContentView(scroll);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar seekBar) {}
        @Override public void onStopTrackingTouch(SeekBar seekBar) {}
    }

    private TextView box(LinearLayout root, String text, int bg, int fg) {
        TextView v = new TextView(this);
        v.setText(text); v.setTextSize(13); v.setTypeface(Typeface.MONOSPACE);
        v.setTextColor(fg); v.setBackgroundColor(bg); v.setPadding(12,12,12,12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2);
        lp.setMargins(0,7,0,0); root.addView(v,lp); return v;
    }
    private LinearLayout.LayoutParams fullButtonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,8,0,0); return lp;
    }
    private Button button(String text, int colour) {
        Button b = new Button(this); b.setText(text); b.setTextColor(Color.WHITE); b.setBackgroundColor(colour); return b;
    }

    private void refreshDisplayInfo() {
        DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
        StringBuilder s=new StringBuilder();
        Display[] all=dm.getDisplays(); Display[] pres=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        s.append("ALL DISPLAYS: ").append(all==null?0:all.length).append("   PRESENTATION: ").append(pres==null?0:pres.length).append('\n');
        if(all!=null) for(Display d:all){ DisplayMetrics m=new DisplayMetrics(); d.getRealMetrics(m);
            s.append("ID ").append(d.getDisplayId()).append(d.getDisplayId()==Display.DEFAULT_DISPLAY?" [DEFAULT]":"")
             .append("\n  ").append(d.getName()).append("\n  ").append(m.widthPixels).append('x').append(m.heightPixels)
             .append("  state=").append(d.getState()).append("  flags=0x").append(Integer.toHexString(d.getFlags())).append('\n'); }
        Display target=findExternalDisplay();
        if(target!=null)s.append("TARGET → ID ").append(target.getDisplayId()).append(' ').append(target.getName()); else s.append("TARGET → NONE");
        if(displayInfo!=null)displayInfo.setText(s.toString());
    }
    private void updatePoseText(){ if(poseInfo==null)return; poseInfo.setText(String.format(Locale.UK,
            "IMU LIVE\nPITCH %+8.2f°\nYAW   %+8.2f°\nPIN P %+8.2f°\nPIN Y %+8.2f°",filteredPitch,filteredYaw,anchorPitch,anchorYaw)); }
    private void updateRenderText(float dx,float dy){ if(renderInfo==null)return; renderInfo.setText(String.format(Locale.UK,
            "RENDER\npresentation=%s surface=%s\nvirtualDisplay=%s frames=%d\nX %+7.1f px Y %+7.1f px\nscale %.2f spacing %.2f mode=%s",
            presentation!=null?"YES":"NO",surfaceReady?"YES":"NO",virtualDisplayReady?"YES":"NO",capturedFrames,dx,dy,screenScale,panelSpacing,multiMode?"3 PANEL":"SINGLE")); }

    private void requestCapture(){
        if(anchorRunning||projection!=null||presentation!=null){status.setText("Anchor already running. STOP first to restart.");return;}
        refreshDisplayInfo(); Display target=findExternalDisplay();
        if(target==null){status.setText("NO TARGET DISPLAY. RayNeo is not exposed as a separate display.");return;}
        status.setText("Target: "+target.getName()+" • requesting capture permission…");
        startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }
    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data); if(requestCode!=REQ_CAPTURE)return;
        if(resultCode!=RESULT_OK||data==null){status.setText("Screen capture permission cancelled");return;}
        try{
            projection=projectionManager.getMediaProjection(resultCode,data); if(projection==null){status.setText("MediaProjection returned NULL");return;}
            projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(stopping)return;anchorRunning=false;virtualDisplayReady=false;status.setText("Capture stopped by Android");});}};
            projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper())); startPresentationAndCapture();
        }catch(Throwable t){status.setText("Capture setup failed: "+t.getClass().getSimpleName()+": "+t.getMessage());stopAnchor();}
    }
    private Display findExternalDisplay(){
        DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE); Display[] displays=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if(displays!=null&&displays.length>0){for(Display d:displays)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return displays[0];}
        for(Display d:dm.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d; return null;
    }

    private void startPresentationAndCapture(){
        Display target=findExternalDisplay(); if(target==null){status.setText("External display disappeared");stopAnchor();return;}
        try{presentation=new AnchorPresentation(this,target);presentation.show();}catch(Throwable t){status.setText("PRESENTATION FAILED: "+t.getMessage());stopAnchor();return;}
        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int width,int height){if(stopping)return;surfaceReady=true;startVirtualDisplay(st);}
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int width,int height){}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){surfaceReady=false;if(!stopping)releaseVirtualDisplayAndSurface();return true;}
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st){capturedFrames++;}
        });
        if(presentation.texture.isAvailable()){surfaceReady=true;startVirtualDisplay(presentation.texture.getSurfaceTexture());}
        presentation.root.post(this::updatePanelGeometry);
        pinHere(); status.setText("Spatial desktop opened on "+target.getName());
    }

    private void startVirtualDisplay(SurfaceTexture st){
        releaseVirtualDisplayAndSurface(); if(projection==null||st==null||presentation==null||stopping)return;
        DisplayMetrics m=new DisplayMetrics(); getWindowManager().getDefaultDisplay().getRealMetrics(m);
        int sourceW=Math.max(1,m.widthPixels),sourceH=Math.max(1,m.heightPixels);
        float downscale=Math.min(1.0f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(sourceW,sourceH));
        int width=Math.max(320,Math.round(sourceW*downscale)),height=Math.max(240,Math.round(sourceH*downscale));
        int density=Math.max(160,Math.round(m.densityDpi*downscale));
        st.setDefaultBufferSize(width,height); captureSurface=new Surface(st);
        try{
            virtualDisplay=projection.createVirtualDisplay("RayNeoAnchorCapture",width,height,density,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,captureSurface,null,null);
            virtualDisplayReady=virtualDisplay!=null; anchorRunning=virtualDisplayReady; capturedFrames=0;
            status.setText(virtualDisplayReady?"3-PANEL ANCHOR ACTIVE • centre live • snapshot left/right":"createVirtualDisplay returned NULL");
        }catch(Throwable t){virtualDisplayReady=false;anchorRunning=false;status.setText("CAPTURE FAILED: "+t.getMessage());releaseVirtualDisplayAndSurface();}
    }

    private void pinHere(){
        if(havePose){filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;status.setText("Pinned here • LEFT / CENTRE / RIGHT fixed in world");}
        else{anchorPitch=anchorYaw=0;status.setText("No IMU pose yet. Start tracking first.");}
        updateAnchorTransform(true); updatePoseText();
    }

    private void snapshotPanel(boolean left){
        if(presentation==null||presentation.texture==null||!presentation.texture.isAvailable()){if(status!=null)status.setText("Start Anchor before taking a panel snapshot");return;}
        try{
            Bitmap b=presentation.texture.getBitmap();
            if(b==null){status.setText("Snapshot returned empty frame");return;}
            if(left){presentation.leftImage.setImageBitmap(b);presentation.leftImage.setVisibility(View.VISIBLE);presentation.leftLabel.setVisibility(View.GONE);}
            else{presentation.rightImage.setImageBitmap(b);presentation.rightImage.setVisibility(View.VISIBLE);presentation.rightLabel.setVisibility(View.GONE);}
            status.setText(left?"Saved current Android view to LEFT panel":"Saved current Android view to RIGHT panel");
        }catch(Throwable t){status.setText("Snapshot failed: "+t.getClass().getSimpleName()+": "+t.getMessage());}
    }
    private void clearSnapshot(boolean left){
        if(presentation==null)return;
        ImageView image=left?presentation.leftImage:presentation.rightImage; TextView label=left?presentation.leftLabel:presentation.rightLabel;
        if(image.getDrawable()!=null){image.setImageDrawable(null);} image.setVisibility(View.GONE); label.setVisibility(View.VISIBLE);
        status.setText(left?"LEFT panel cleared":"RIGHT panel cleared");
    }

    private void updatePanelGeometry(){
        if(presentation==null||presentation.root==null)return;
        int w=presentation.root.getWidth(); if(w<=0)return;
        float side=panelSpacing*w;
        presentation.centerPanel.setScaleX(screenScale); presentation.centerPanel.setScaleY(screenScale); presentation.centerPanel.setTranslationX(0);
        presentation.leftPanel.setScaleX(screenScale); presentation.leftPanel.setScaleY(screenScale); presentation.leftPanel.setTranslationX(-side);
        presentation.rightPanel.setScaleX(screenScale); presentation.rightPanel.setScaleY(screenScale); presentation.rightPanel.setTranslationX(side);
        int vis=multiMode?View.VISIBLE:View.GONE; presentation.leftPanel.setVisibility(vis);presentation.rightPanel.setVisibility(vis);
    }

    private void updateAnchorTransform(boolean forceUi){
        if(presentation==null||presentation.world==null){if(forceUi)updateRenderText(0,0);return;}
        int w=presentation.root.getWidth(),h=presentation.root.getHeight(); if(w<=0||h<=0)return;
        float yaw=filteredYaw-anchorYaw,pitch=filteredPitch-anchorPitch;
        float xSign=invertAnchorX?+1f:-1f,ySign=invertAnchorY?+1f:-1f;
        float dx=xSign*(yaw/hFovDeg)*w,dy=ySign*(pitch/vFovDeg)*h;
        lastDx=dx;lastDy=dy;
        presentation.world.setTranslationX(dx); presentation.world.setTranslationY(dy);
        if(forceUi)updateRenderText(dx,dy);
    }

    private void releaseVirtualDisplayAndSurface(){
        VirtualDisplay vd=virtualDisplay;virtualDisplay=null;virtualDisplayReady=false;
        if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}
        Surface s=captureSurface;captureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){}
    }
    private void stopAnchor(){
        if(stopping)return;
        if(!anchorRunning&&projection==null&&presentation==null&&virtualDisplay==null&&captureSurface==null){if(status!=null)status.setText("Anchor already stopped");return;}
        stopping=true;anchorRunning=false;releaseVirtualDisplayAndSurface();
        AnchorPresentation p=presentation;presentation=null;if(p!=null){try{if(p.texture!=null)p.texture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        surfaceReady=false; MediaProjection mp=projection;projection=null;
        if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}
        projectionCallback=null;capturedFrames=0;lastDx=lastDy=0;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");updateRenderText(0,0);
    }

    @Override protected void onDestroy(){Choreographer.getInstance().removeFrameCallback(renderFrame);try{unregisterReceiver(poseReceiver);}catch(Throwable ignored){}stopAnchor();super.onDestroy();}

    private static class AnchorPresentation extends Presentation {
        FrameLayout root, world, leftPanel, centerPanel, rightPanel;
        TextureView texture;
        ImageView leftImage,rightImage;
        TextView leftLabel,rightLabel;
        AnchorPresentation(Context outerContext,Display display){super(outerContext,display);}

        @Override protected void onCreate(Bundle savedInstanceState){
            super.onCreate(savedInstanceState); getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(false);root.setClipToPadding(false);
            world=new FrameLayout(getContext());world.setClipChildren(false);world.setClipToPadding(false);world.setLayerType(View.LAYER_TYPE_HARDWARE,null);
            root.addView(world,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

            leftPanel=panel(getContext());centerPanel=panel(getContext());rightPanel=panel(getContext());
            FrameLayout.LayoutParams fill=new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER);
            world.addView(leftPanel,new FrameLayout.LayoutParams(fill));world.addView(centerPanel,new FrameLayout.LayoutParams(fill));world.addView(rightPanel,new FrameLayout.LayoutParams(fill));

            leftImage=image(getContext());leftPanel.addView(leftImage,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            leftLabel=label(getContext(),"LEFT\nSNAP A SCREEN HERE");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));

            texture=new TextureView(getContext());texture.setOpaque(true);centerPanel.addView(texture,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            TextView centreTag=smallTag(getContext(),"CENTRE • LIVE");FrameLayout.LayoutParams tagLp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);tagLp.topMargin=18;centerPanel.addView(centreTag,tagLp);

            rightImage=image(getContext());rightPanel.addView(rightImage,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            rightLabel=label(getContext(),"RIGHT\nSNAP A SCREEN HERE");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1,Gravity.CENTER));
            setContentView(root);
        }
        private static FrameLayout panel(Context c){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(Color.BLACK);f.setClipChildren(true);f.setLayerType(View.LAYER_TYPE_HARDWARE,null);return f;}
        private static ImageView image(Context c){ImageView v=new ImageView(c);v.setScaleType(ImageView.ScaleType.FIT_CENTER);v.setBackgroundColor(Color.BLACK);v.setVisibility(View.GONE);return v;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setGravity(Gravity.CENTER);v.setTextSize(26);v.setTextColor(0xffdddddd);v.setBackgroundColor(0xff101318);return v;}
        private static TextView smallTag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(14);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }
}
