# RayNeo Head Tracker v0.6 MULTI

Experimental three-panel spatial desktop built on the hardware-proven v0.5 smooth anchor engine.

## What changed
- Correct Air 4 Pro anchor directions are now the defaults (both X/Y inversion enabled).
- 3-panel spatial layout: LEFT / CENTRE / RIGHT.
- CENTRE remains the live Android MediaProjection capture.
- SNAP LEFT and SNAP RIGHT save the current live view into independently visible world-fixed side panels.
- Adjustable panel size and left/right spacing.
- Single-screen fallback toggle remains available.
- Preserves v0.5 full-rate in-process pose reads and v0.4 safe teardown.

## Important limitation of this first multi-screen build
Android MediaProjection provides one live capture surface here. v0.6 therefore keeps the centre panel live and uses snapshots for the left/right panels. It proves the spatial multi-panel compositor and head-navigation geometry without tripling capture/GPU load. A later build can investigate independent live app/task surfaces.

## Test flow
1. Start RayNeo tracking and calibrate.
2. Open Spatial Desktop v0.6 and START ANCHOR.
3. PIN HERE facing centre.
4. Put content A on Android and SNAP LEFT.
5. Put content B on Android and SNAP RIGHT.
6. Leave content C live in centre.
7. Turn your head left / centre / right.
