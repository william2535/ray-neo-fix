# RayNeo Spatial v0.9.11 — UI Stability + Mouse Restore LAB

Based on the proven v0.9.9 spatial desktop.

Changes in this patch:
- Removes v0.9.10 full-window Choreographer invalidation.
- Restores the original v0.9.9 setup UI and mouse behaviour.
- Keeps setup screens awake and requests a 60 Hz window refresh rate.
- Uses only a tiny 2x2 px 20 Hz keep-alive view to prevent the handheld entering its no-touch sluggish state.
- Automatically re-sends centre mouse configuration when returning to the main screen.
- Adds a /dev/uinput self-heal: if centre mouse is enabled but the mouse FD is unavailable, TrackingService retries opening it every 2 seconds.
- Spatial world, screen placement, independent apps, Shizuku bridge, side cursor/clicking and sticky-app behaviour remain based on v0.9.9.

## Test order
1. Start tracking and verify `Tracking → virtual mouse`.
2. Keep hands off the handheld for 20–30 seconds and verify the setup UI stays responsive.
3. Verify the normal Android cursor still moves from head tracking.
4. Open Spatial Desktop and repeat the no-touch test.
5. Test LEFT/RIGHT screens only after centre mouse is confirmed.
