package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;

/**
 * RayNeo 3DoF anchor v0.4 PERFORMANCE.
 *
 * Changes from v0.3:
 *  - IMU receiver only stores latest pose; rendering is driven by Choreographer (~display refresh)
 *  - capture resolution is capped around 1280 px on the long edge to reduce GPU/compositor load
 *  - diagnostic text is throttled instead of being rewritten at IMU rate
 *  - Surface is retained and explicitly released
 *  - stop is idempotent and tears down VirtualDisplay -> Surface -> Presentation -> MediaProjection once
 */
public class AnchorActivity extends Activity {
    private static final int REQ_CAPTURE = 4401;
    private static final long DIAGNOSTIC_INTERVAL_MS = 250L;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;
    private AnchorPresentation presentation;

    private TextView status, displayInfo, poseInfo, renderInfo;

    private float screenScale = 0.78f;
    private float hFovDeg = 46.0f;
    private float vFovDeg = 27.0f;
    private float anchorPitch = 0f, anchorYaw = 0f;
    private volatile float latestPitch = 0f, latestYaw = 0f;
    private float filteredPitch = 0f, filteredYaw = 0f;
    private volatile boolean havePose = false;
    private boolean surfaceReady = false;
    private boolean virtualDisplayReady = false;
    private volatile long capturedFrames = 0;
    private float testOffsetX = 0f;
    private boolean testMoved = false;

    private boolean anchorRunning = false;
    private boolean stopping = false;
    private long lastDiagnosticUiMs = 0L;
    private float lastDx = 0f, lastDy = 0f;

    private final Choreographer.FrameCallback renderFrame = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (!isFinishing() && !isDestroyed()) {
                if (havePose) {
                    // Smoothing is performed once per rendered frame, not once per ~118 Hz IMU broadcast.
                    filteredPitch += (latestPitch - filteredPitch) * 0.42f;
                    filteredYaw += (latestYaw - filteredYaw) * 0.42f;
                }
                if (anchorRunning && !stopping) updateAnchorTransform(false);
                long now = SystemClock.uptimeMillis();
                if (now - lastDiagnosticUiMs >= DIAGNOSTIC_INTERVAL_MS) {
                    lastDiagnosticUiMs = now;
                    updatePoseText();
                    updateRenderText(lastDx, lastDy);
                }
                Choreographer.getInstance().postFrameCallback(this);
            }
        }
    };

    private final BroadcastReceiver poseReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!TrackingService.ACTION_STATUS.equals(intent.getAction())) return;
            latestPitch = (float) intent.getDoubleExtra("pitch", 0.0);
            latestYaw = (float) intent.getDoubleExtra("yaw", 0.0);

            if (!havePose) {
                filteredPitch = latestPitch;
                filteredYaw = latestYaw;
                anchorPitch = latestPitch;
                anchorYaw = latestYaw;
                havePose = true;
            }
            // Deliberately do NOT touch views here. TrackingService can report faster than the display can draw.
        }
    };

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        projectionManager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(poseReceiver, new IntentFilter(TrackingService.ACTION_STATUS));
        buildUi();
        refreshDisplayInfo();
        Choreographer.getInstance().postFrameCallback(renderFrame);
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(24, 24, 24, 32);
        scroll.addView(root);

        TextView title = new TextView(this);
        title.setText("RAYNEO 3DoF ANCHOR • v0.4 PERFORMANCE");
        title.setTextSize(24);
        title.setTypeface(null, 1);
        root.addView(title);

        TextView help = new TextView(this);
        help.setText("Performance build: full-rate RayNeo tracking, display-synchronised anchor movement, lighter screen capture and crash-safe Stop. Keep normal Head Tracking running.");
        help.setTextSize(13);
        help.setPadding(0, 8, 0, 14);
        root.addView(help);

        status = box(root, "Ready • checking displays…", 0xffe4e7e0, Color.BLACK);
        displayInfo = box(root, "DISPLAY DIAGNOSTICS", 0xff20242a, 0xffd8e2ef);
        poseInfo = box(root, "IMU: waiting for TrackingService…", 0xff16241c, 0xff77e49e);
        renderInfo = box(root, "RENDER: not started", 0xff242024, 0xffffd27a);

        Button refresh = button("REFRESH DISPLAYS", 0xff59645b);
        root.addView(refresh, fullButtonLp());

        TextView scaleLabel = new TextView(this);
        scaleLabel.setText("Virtual screen size");
        scaleLabel.setPadding(0, 16, 0, 0);
        root.addView(scaleLabel);

        SeekBar scale = new SeekBar(this);
        scale.setMax(90);
        scale.setProgress(62);
        root.addView(scale);
        screenScale = 0.30f + 0.70f * (scale.getProgress() / 90f);
        scale.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                screenScale = 0.30f + 0.70f * (progress / 90f);
                updateAnchorTransform(true);
            }
            public void onStartTrackingTouch(SeekBar seekBar) {}
            public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setPadding(0, 14, 0, 0);
        Button capture = button("START ANCHOR", 0xff2f7d4a);
        Button recenter = button("PIN HERE", 0xff59645b);
        row.addView(capture, new LinearLayout.LayoutParams(0, -2, 1));
        row.addView(recenter, new LinearLayout.LayoutParams(0, -2, 1));
        root.addView(row);

        Button testMove = button("TEST MOVE ↔", 0xff775b9b);
        root.addView(testMove, fullButtonLp());

        Button stop = button("STOP ANCHOR", 0xffa43f35);
        root.addView(stop, fullButtonLp());

        TextView note = new TextView(this);
        note.setText("v0.4 keeps the IMU fast but only moves the visual once per display frame. Capture is downscaled when needed to reduce lag. STOP can safely be pressed more than once.");
        note.setTextSize(13);
        note.setPadding(0, 18, 0, 0);
        root.addView(note);

        refresh.setOnClickListener(v -> refreshDisplayInfo());
        capture.setOnClickListener(v -> requestCapture());
        recenter.setOnClickListener(v -> pinHere());
        testMove.setOnClickListener(v -> {
            testMoved = !testMoved;
            testOffsetX = testMoved ? 220f : -220f;
            updateAnchorTransform(true);
            status.setText("TEST MOVE applied: " + (int)testOffsetX + " px");
        });
        stop.setOnClickListener(v -> stopAnchor());

        setContentView(scroll);
    }

    private TextView box(LinearLayout root, String text, int bg, int fg) {
        TextView v = new TextView(this);
        v.setText(text);
        v.setTextSize(13);
        v.setTypeface(Typeface.MONOSPACE);
        v.setTextColor(fg);
        v.setBackgroundColor(bg);
        v.setPadding(12, 12, 12, 12);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 7, 0, 0);
        root.addView(v, lp);
        return v;
    }

    private LinearLayout.LayoutParams fullButtonLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 8, 0, 0);
        return lp;
    }

    private Button button(String text, int colour) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setBackgroundColor(colour);
        return b;
    }

    private void refreshDisplayInfo() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        StringBuilder s = new StringBuilder();
        Display[] all = dm.getDisplays();
        Display[] pres = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        s.append("ALL DISPLAYS: ").append(all == null ? 0 : all.length)
         .append("   PRESENTATION: ").append(pres == null ? 0 : pres.length).append('\n');
        if (all != null) {
            for (Display d : all) {
                DisplayMetrics m = new DisplayMetrics();
                d.getRealMetrics(m);
                s.append("ID ").append(d.getDisplayId())
                 .append(d.getDisplayId() == Display.DEFAULT_DISPLAY ? " [DEFAULT]" : "")
                 .append("\n  ").append(d.getName())
                 .append("\n  ").append(m.widthPixels).append('x').append(m.heightPixels)
                 .append("  state=").append(d.getState())
                 .append("  flags=0x").append(Integer.toHexString(d.getFlags()))
                 .append('\n');
            }
        }
        Display target = findExternalDisplay();
        if (target != null) s.append("TARGET → ID ").append(target.getDisplayId()).append(" ").append(target.getName());
        else s.append("TARGET → NONE");
        if (displayInfo != null) displayInfo.setText(s.toString());
    }

    private void updatePoseText() {
        if (poseInfo == null) return;
        poseInfo.setText(String.format(Locale.UK,
                "IMU LIVE\nPITCH %+8.2f°\nYAW   %+8.2f°\nPIN P %+8.2f°\nPIN Y %+8.2f°",
                filteredPitch, filteredYaw, anchorPitch, anchorYaw));
    }

    private void updateRenderText(float dx, float dy) {
        if (renderInfo == null) return;
        renderInfo.setText(String.format(Locale.UK,
                "RENDER\npresentation=%s  surface=%s\nvirtualDisplay=%s  frames=%d\nX %+7.1f px   Y %+7.1f px\nscale %.2f",
                presentation != null ? "YES" : "NO",
                surfaceReady ? "YES" : "NO",
                virtualDisplayReady ? "YES" : "NO",
                capturedFrames, dx, dy, screenScale));
    }

    private void requestCapture() {
        if (anchorRunning || projection != null || presentation != null) {
            status.setText("Anchor is already running. Press STOP first if you want to restart it.");
            return;
        }
        refreshDisplayInfo();
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("NO TARGET DISPLAY. Android is not exposing the RayNeo as a separate display.");
            return;
        }
        status.setText("Target: " + target.getName() + " • requesting capture permission…");
        startActivityForResult(projectionManager.createScreenCaptureIntent(), REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_CAPTURE) return;
        if (resultCode != RESULT_OK || data == null) {
            status.setText("Screen capture permission cancelled");
            return;
        }
        try {
            projection = projectionManager.getMediaProjection(resultCode, data);
            if (projection == null) {
                status.setText("MediaProjection returned NULL");
                return;
            }
            projectionCallback = new MediaProjection.Callback() {
                @Override public void onStop() {
                    runOnUiThread(() -> {
                        if (stopping) return;
                        anchorRunning = false;
                        virtualDisplayReady = false;
                        status.setText("Capture stopped by Android");
                        updateRenderText(lastDx, lastDy);
                    });
                }
            };
            projection.registerCallback(projectionCallback, new Handler(Looper.getMainLooper()));
            startPresentationAndCapture();
        } catch (Throwable t) {
            status.setText("Capture setup failed: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            stopAnchor();
        }
    }

    private Display findExternalDisplay() {
        DisplayManager dm = (DisplayManager) getSystemService(DISPLAY_SERVICE);
        Display[] displays = dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);
        if (displays != null && displays.length > 0) {
            for (Display d : displays) if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
            return displays[0];
        }
        for (Display d : dm.getDisplays()) if (d.getDisplayId() != Display.DEFAULT_DISPLAY) return d;
        return null;
    }

    private void startPresentationAndCapture() {
        Display target = findExternalDisplay();
        if (target == null) {
            status.setText("External display disappeared before Presentation opened");
            stopAnchor();
            return;
        }

        try {
            presentation = new AnchorPresentation(this, target);
            presentation.show();
        } catch (Throwable t) {
            status.setText("PRESENTATION FAILED: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            stopAnchor();
            return;
        }

        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {
            @Override public void onSurfaceTextureAvailable(SurfaceTexture st, int width, int height) {
                if (stopping) return;
                surfaceReady = true;
                status.setText("Presentation ready • starting optimised capture…");
                startVirtualDisplay(st);
            }
            @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st, int width, int height) {}
            @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st) {
                surfaceReady = false;
                // If Stop caused this destruction, teardown is already underway.
                if (!stopping) releaseVirtualDisplayAndSurface();
                return true;
            }
            @Override public void onSurfaceTextureUpdated(SurfaceTexture st) {
                capturedFrames++;
            }
        });

        if (presentation.texture.isAvailable()) {
            surfaceReady = true;
            startVirtualDisplay(presentation.texture.getSurfaceTexture());
        }

        pinHere();
        status.setText("Anchor opened on " + target.getName() + " • performance mode");
    }

    private void startVirtualDisplay(SurfaceTexture st) {
        releaseVirtualDisplayAndSurface();
        if (projection == null || st == null || presentation == null || stopping) {
            if (!stopping) status.setText("Capture start blocked: missing projection/surface/presentation");
            return;
        }

        DisplayMetrics m = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getRealMetrics(m);
        int sourceW = Math.max(1, m.widthPixels);
        int sourceH = Math.max(1, m.heightPixels);
        float downscale = Math.min(1.0f, MAX_CAPTURE_LONG_EDGE / (float)Math.max(sourceW, sourceH));
        int width = Math.max(320, Math.round(sourceW * downscale));
        int height = Math.max(240, Math.round(sourceH * downscale));
        int density = Math.max(160, Math.round(m.densityDpi * downscale));

        st.setDefaultBufferSize(width, height);
        captureSurface = new Surface(st);

        try {
            virtualDisplay = projection.createVirtualDisplay(
                    "RayNeoAnchorCapture", width, height, density,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    captureSurface, null, null);
            virtualDisplayReady = virtualDisplay != null;
            anchorRunning = virtualDisplayReady;
            capturedFrames = 0;
            if (virtualDisplayReady) {
                status.setText("ANCHOR ACTIVE • capture " + width + "×" + height + " • turn your head");
            } else {
                status.setText("createVirtualDisplay returned NULL");
            }
        } catch (Throwable t) {
            virtualDisplayReady = false;
            anchorRunning = false;
            status.setText("CAPTURE FAILED: " + t.getClass().getSimpleName() + ": " + t.getMessage());
            releaseVirtualDisplayAndSurface();
        }
    }

    private void pinHere() {
        if (havePose) {
            // Use the latest sample immediately so recenter feels instant.
            filteredPitch = latestPitch;
            filteredYaw = latestYaw;
            anchorPitch = filteredPitch;
            anchorYaw = filteredYaw;
            status.setText("Pinned here • turn your head");
        } else {
            anchorPitch = anchorYaw = 0f;
            status.setText("PIN requested but no IMU pose has arrived. Start tracking first.");
        }
        testOffsetX = 0f;
        testMoved = false;
        updateAnchorTransform(true);
        updatePoseText();
    }

    private void updateAnchorTransform(boolean forceUi) {
        if (presentation == null || presentation.mover == null) {
            if (forceUi) updateRenderText(0, 0);
            return;
        }
        View mover = presentation.mover;
        int w = presentation.root != null ? presentation.root.getWidth() : mover.getWidth();
        int h = presentation.root != null ? presentation.root.getHeight() : mover.getHeight();
        if (w <= 0 || h <= 0) return;

        float yaw = filteredYaw - anchorYaw;
        float pitch = filteredPitch - anchorPitch;
        float dx = -(yaw / hFovDeg) * w + testOffsetX;
        float dy = +(pitch / vFovDeg) * h;
        lastDx = dx;
        lastDy = dy;

        // Hardware-friendly view properties; no layout or bitmap work on each frame.
        mover.setPivotX(w * 0.5f);
        mover.setPivotY(h * 0.5f);
        mover.setScaleX(screenScale);
        mover.setScaleY(screenScale);
        mover.setTranslationX(dx);
        mover.setTranslationY(dy);

        if (forceUi) updateRenderText(dx, dy);
    }

    private void releaseVirtualDisplayAndSurface() {
        VirtualDisplay vd = virtualDisplay;
        virtualDisplay = null;
        virtualDisplayReady = false;
        if (vd != null) {
            try { vd.setSurface(null); } catch (Throwable ignored) {}
            try { vd.release(); } catch (Throwable ignored) {}
        }

        Surface s = captureSurface;
        captureSurface = null;
        if (s != null) {
            try { s.release(); } catch (Throwable ignored) {}
        }
    }

    private void stopAnchor() {
        if (stopping) return;
        if (!anchorRunning && projection == null && presentation == null && virtualDisplay == null && captureSurface == null) {
            if (status != null) status.setText("Anchor already stopped");
            return;
        }

        stopping = true;
        anchorRunning = false;

        // 1) Stop producer from writing into the TextureView.
        releaseVirtualDisplayAndSurface();

        // 2) Dismiss presentation after capture is detached.
        AnchorPresentation p = presentation;
        presentation = null;
        if (p != null) {
            try {
                if (p.texture != null) p.texture.setSurfaceTextureListener(null);
            } catch (Throwable ignored) {}
            try { p.dismiss(); } catch (Throwable ignored) {}
        }
        surfaceReady = false;

        // 3) Unregister callback before stopping projection so our own stop doesn't re-enter teardown.
        MediaProjection mp = projection;
        projection = null;
        if (mp != null) {
            if (projectionCallback != null) {
                try { mp.unregisterCallback(projectionCallback); } catch (Throwable ignored) {}
            }
            try { mp.stop(); } catch (Throwable ignored) {}
        }
        projectionCallback = null;

        capturedFrames = 0;
        testOffsetX = 0f;
        testMoved = false;
        lastDx = lastDy = 0f;
        stopping = false;

        if (status != null) status.setText("Anchor stopped safely");
        updateRenderText(0, 0);
    }

    @Override protected void onDestroy() {
        Choreographer.getInstance().removeFrameCallback(renderFrame);
        try { unregisterReceiver(poseReceiver); } catch (Throwable ignored) {}
        stopAnchor();
        super.onDestroy();
    }

    private static class AnchorPresentation extends Presentation {
        FrameLayout root;
        FrameLayout mover;
        TextureView texture;

        AnchorPresentation(Context outerContext, Display display) {
            super(outerContext, display);
        }

        @Override protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            getWindow().setBackgroundDrawableResource(android.R.color.black);
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            root = new FrameLayout(getContext());
            root.setBackgroundColor(Color.BLACK);

            mover = new FrameLayout(getContext());
            mover.setBackgroundColor(Color.BLACK);
            // Force a hardware layer: only transform this layer while the captured texture updates underneath it.
            mover.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            FrameLayout.LayoutParams fill = new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER);
            root.addView(mover, fill);

            texture = new TextureView(getContext());
            texture.setOpaque(true);
            mover.addView(texture, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));

            setContentView(root);
        }
    }
}
