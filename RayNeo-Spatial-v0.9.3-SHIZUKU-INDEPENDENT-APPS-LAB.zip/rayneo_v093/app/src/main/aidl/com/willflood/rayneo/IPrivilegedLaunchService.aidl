package com.willflood.rayneo;

interface IPrivilegedLaunchService {
    void destroy() = 16777114;
    String launchComponent(String componentName, int displayId) = 1;
    int getUid() = 2;
}
