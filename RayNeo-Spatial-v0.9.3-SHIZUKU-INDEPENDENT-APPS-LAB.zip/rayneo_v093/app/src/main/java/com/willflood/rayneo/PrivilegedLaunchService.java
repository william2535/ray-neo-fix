package com.willflood.rayneo;

import android.os.RemoteException;
import android.system.Os;
import java.io.BufferedReader;
import java.io.InputStreamReader;

/** Runs only inside a Shizuku UserService process (shell/root identity). */
public class PrivilegedLaunchService extends IPrivilegedLaunchService.Stub {
    public PrivilegedLaunchService() {}

    @Override public int getUid() { return Os.getuid(); }

    @Override public String launchComponent(String componentName, int displayId) throws RemoteException {
        if (componentName == null || componentName.trim().isEmpty()) return "ERROR: empty component";
        Process p = null;
        try {
            ProcessBuilder pb = new ProcessBuilder(
                    "am", "start",
                    "--display", Integer.toString(displayId),
                    "-n", componentName);
            pb.redirectErrorStream(true);
            p = pb.start();
            StringBuilder out = new StringBuilder();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    if (out.length() > 0) out.append('\n');
                    out.append(line);
                }
            }
            int rc = p.waitFor();
            return "uid=" + Os.getuid() + " rc=" + rc + "\n" + out;
        } catch (Throwable t) {
            return "ERROR " + t.getClass().getName() + ": " + String.valueOf(t.getMessage());
        } finally {
            if (p != null) try { p.destroy(); } catch (Throwable ignored) {}
        }
    }

    @Override public void destroy() {
        System.exit(0);
    }
}
