# RayNeo Spatial v0.9.3 — Shizuku Independent Apps LAB

Experimental build based on the smooth v0.9.1 VirtualDisplay path.

## What changed

v0.9.2 confirmed that Android permits LEFT/RIGHT app-owned VirtualDisplays on the test handheld, but normal `startActivity(... setLaunchDisplayId())` is blocked by a `SecurityException`.

v0.9.3 keeps the tracker and VirtualDisplay code unchanged and adds Shizuku only for the privileged launch step. The app binds a Shizuku UserService and asks the shell-identity process to execute:

`am start --display <DISPLAY_ID> -n <PACKAGE/ACTIVITY>`

## Setup

1. Install Shizuku.
2. On Android 11+, enable Developer options → Wireless debugging.
3. Start Shizuku using its on-device pairing/start instructions.
4. Open RayNeo Spatial v0.9.3.
5. Start Tracking.
6. Start Anchor.
7. Press CONNECT SHIZUKU and grant RayNeo permission in Shizuku.
8. CREATE LEFT DISPLAY → LAUNCH LEFT APP.
9. CREATE RIGHT DISPLAY → LAUNCH RIGHT APP.

The LAB status box reports Shizuku server UID, UserService UID, command return code and `am` output.

## Expected result

LEFT and RIGHT should be independent VirtualDisplays running different Android activities, while CENTRE remains the normal live Android capture.

## Important

This is a lab build. Keep v0.8 as the public stable beta.
