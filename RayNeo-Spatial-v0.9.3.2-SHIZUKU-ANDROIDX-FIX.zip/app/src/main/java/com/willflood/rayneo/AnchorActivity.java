package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.Locale;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.lang.reflect.Method;
import rikka.shizuku.Shizuku;

/**
 * RayNeo 3DoF Spatial Desktop v0.7.
 *
 * Important architectural change from v0.6:
 * v0.6 translated full-display child views outside a display-sized parent. On some Android
 * compositors that effectively behaves like one moving panel. v0.7 instead creates a large
 * world canvas (~5 display widths), places three real panels at fixed world coordinates, and
 * moves the camera (the world container) from the Air 4 Pro head pose.
 *
 * Centre = live Android capture. Left/right = independent saved views for now.
 */
public class AnchorActivity extends Activity {
    public static final String ACTION_OVERLAY = "com.willflood.rayneo.ANCHOR_OVERLAY_ACTION";
    public static final String EXTRA_COMMAND = "command";
    public static final String CMD_SNAP_LEFT = "snap_left";
    public static final String CMD_SNAP_RIGHT = "snap_right";
    public static final String CMD_PIN = "pin";
    public static final String CMD_STOP = "stop";

    private static final int REQ_CAPTURE = 4401;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;
    private static final long UI_INTERVAL_MS = 250L;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private Surface captureSurface;

    // v0.9.1 LAB ONLY. These are never created automatically.
    // Keeping them completely idle preserves the proven v0.8 tracking path until a test button is pressed.
    private VirtualDisplay leftLabDisplay, rightLabDisplay;
    private Surface leftLabSurface, rightLabSurface;
    private SpatialPresentation presentation;

    // v0.9.3.2: direct Shizuku shell launcher; no AIDL/UserService layer.
    private static final int SHIZUKU_PERMISSION_REQUEST = 9311;
    private volatile boolean shizukuReady;
    private final Shizuku.OnBinderReceivedListener shizukuBinderListener = () -> runOnUiThread(this::refreshShizukuState);
    private final Shizuku.OnBinderDeadListener shizukuDeadListener = () -> runOnUiThread(() -> { shizukuReady=false; setLabStatus("SHIZUKU STOPPED — start Shizuku again"); });
    private final Shizuku.OnRequestPermissionResultListener shizukuPermissionListener = (requestCode, grantResult) -> {
        if(requestCode!=SHIZUKU_PERMISSION_REQUEST) return;
        runOnUiThread(() -> {
            if(grantResult==PackageManager.PERMISSION_GRANTED){ shizukuReady=true; refreshShizukuState(); }
            else { shizukuReady=false; setLabStatus("SHIZUKU PERMISSION DENIED"); }
        });
    };

    private TextView status, poseInfo, renderInfo, labInfo;
    private boolean overlayPermissionRequested;

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_OVERLAY.equals(intent.getAction())) return;
            String command = intent.getStringExtra(EXTRA_COMMAND);
            if (CMD_SNAP_LEFT.equals(command)) snapshot(true);
            else if (CMD_SNAP_RIGHT.equals(command)) snapshot(false);
            else if (CMD_PIN.equals(command)) pinHere();
            else if (CMD_STOP.equals(command)) stopAnchor();
        }
    };

    private volatile float latestPitch, latestYaw;
    private float filteredPitch, filteredYaw;
    private float anchorPitch, anchorYaw;
    private boolean havePose;

    private boolean anchorRunning, stopping;
    private boolean invertX = true, invertY = true; // proven on user's Air 4 Pro
    private float panelScale = 0.72f;
    private float panelSpacingScreens = 1.02f;
    private float hFovDeg = 46f, vFovDeg = 27f;
    private long lastFrameNs, lastUiMs;
    private float lastDx, lastDy;

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (isFinishing() || isDestroyed()) return;

            if (TrackingService.livePoseValid) {
                latestPitch = (float) TrackingService.livePitch;
                latestYaw = (float) TrackingService.liveYaw;
                if (!havePose) {
                    filteredPitch = latestPitch;
                    filteredYaw = latestYaw;
                    anchorPitch = filteredPitch;
                    anchorYaw = filteredYaw;
                    havePose = true;
                }
            }

            if (havePose) {
                float dt = lastFrameNs == 0 ? 1f/60f : Math.min(.05f,(frameTimeNanos-lastFrameNs)/1_000_000_000f);
                float alpha = 1f-(float)Math.exp(-dt*30f);
                filteredPitch += (latestPitch-filteredPitch)*alpha;
                filteredYaw += (latestYaw-filteredYaw)*alpha;
            }
            lastFrameNs = frameTimeNanos;

            if (anchorRunning && !stopping) updateCamera();

            long now = SystemClock.uptimeMillis();
            if (now-lastUiMs >= UI_INTERVAL_MS) {
                lastUiMs=now;
                poseInfo.setText(String.format(Locale.UK,
                        "PITCH %+7.2f°   YAW %+7.2f°\nPIN   %+7.2f°   %+7.2f°",
                        filteredPitch,filteredYaw,anchorPitch,anchorYaw));
                renderInfo.setText(String.format(Locale.UK,
                        "CAMERA X %+7.0f px   Y %+7.0f px\nLEFT / CENTRE / RIGHT fixed in world\nscale %.2f  spacing %.2f screens",
                        lastDx,lastDy,panelScale,panelSpacingScreens));
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        registerReceiver(overlayReceiver, new IntentFilter(ACTION_OVERLAY));
        Shizuku.addBinderReceivedListenerSticky(shizukuBinderListener);
        Shizuku.addBinderDeadListener(shizukuDeadListener);
        Shizuku.addRequestPermissionResultListener(shizukuPermissionListener);
        buildUi();
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,32); sv.addView(root);
        TextView title=new TextView(this); title.setText("RAYNEO SPATIAL DESKTOP • v0.9.3.2 SHIZUKU SHELL LAB"); title.setTextSize(24); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView help=new TextView(this); help.setText("v0.9.1 proved LEFT/RIGHT VirtualDisplays are smooth. v0.9.2 proved normal Android app launch is blocked by SecurityException. v0.9.3.2 keeps the same displays and uses the running Shizuku shell only for the blocked app-launch command."); help.setPadding(0,8,0,12); root.addView(help);
        status=box(root,"Ready");
        poseInfo=box(root,"IMU waiting…");
        renderInfo=box(root,"Spatial canvas not started");
        labInfo=box(root,"LAB: Shizuku not connected yet — tracking/display path remains unchanged");

        TextView sz=new TextView(this); sz.setText("Panel size"); root.addView(sz);
        SeekBar size=new SeekBar(this); size.setMax(100); size.setProgress(60); root.addView(size);
        TextView sp=new TextView(this); sp.setText("Panel spacing"); root.addView(sp);
        SeekBar spacing=new SeekBar(this); spacing.setMax(100); spacing.setProgress(52); root.addView(spacing);

        CheckBox ix=new CheckBox(this); ix.setText("Invert horizontal anchor"); ix.setChecked(true); root.addView(ix);
        CheckBox iy=new CheckBox(this); iy.setText("Invert vertical anchor"); iy.setChecked(true); root.addView(iy);

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button start=button("START ANCHOR",0xff2f7d4a), pin=button("PIN HERE",0xff59645b);
        row.addView(start,new LinearLayout.LayoutParams(0,-2,1)); row.addView(pin,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);

        LinearLayout snap=new LinearLayout(this); snap.setOrientation(LinearLayout.HORIZONTAL);
        Button sl=button("SNAP LEFT",0xff4f638c), sr=button("SNAP RIGHT",0xff4f638c);
        snap.addView(sl,new LinearLayout.LayoutParams(0,-2,1)); snap.addView(sr,new LinearLayout.LayoutParams(0,-2,1)); root.addView(snap);

        TextView labTitle=new TextView(this); labTitle.setText("v0.9.3.2 SHIZUKU INDEPENDENT APP LAB"); labTitle.setTypeface(null,Typeface.BOLD); labTitle.setPadding(0,14,0,4); root.addView(labTitle);
        Button shizuku=button("CONNECT SHIZUKU",0xff6a3f8e); root.addView(shizuku);
        LinearLayout labRow=new LinearLayout(this); labRow.setOrientation(LinearLayout.HORIZONTAL);
        Button createLeft=button("CREATE LEFT DISPLAY",0xff765229), createRight=button("CREATE RIGHT DISPLAY",0xff765229);
        labRow.addView(createLeft,new LinearLayout.LayoutParams(0,-2,1)); labRow.addView(createRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(labRow);
        LinearLayout launchRow=new LinearLayout(this); launchRow.setOrientation(LinearLayout.HORIZONTAL);
        Button launchLeft=button("LAUNCH LEFT APP",0xff355f82), launchRight=button("LAUNCH RIGHT APP",0xff355f82);
        launchRow.addView(launchLeft,new LinearLayout.LayoutParams(0,-2,1)); launchRow.addView(launchRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(launchRow);
        LinearLayout labStopRow=new LinearLayout(this); labStopRow.setOrientation(LinearLayout.HORIZONTAL);
        Button destroyLeft=button("DESTROY LEFT",0xff555555), destroyRight=button("DESTROY RIGHT",0xff555555);
        labStopRow.addView(destroyLeft,new LinearLayout.LayoutParams(0,-2,1)); labStopRow.addView(destroyRight,new LinearLayout.LayoutParams(0,-2,1)); root.addView(labStopRow);

        Button floating=button("ENABLE FLOATING CONTROLS",0xff7b4f9c);
        LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2); flp.setMargins(0,8,0,8); root.addView(floating,flp);

        LinearLayout clr=new LinearLayout(this); clr.setOrientation(LinearLayout.HORIZONTAL);
        Button cl=button("CLEAR LEFT",0xff555555), cr=button("CLEAR RIGHT",0xff555555);
        clr.addView(cl,new LinearLayout.LayoutParams(0,-2,1)); clr.addView(cr,new LinearLayout.LayoutParams(0,-2,1)); root.addView(clr);

        Button stop=button("STOP ANCHOR",0xffa43f35); root.addView(stop);
        TextView note=new TextView(this); note.setText("TEST ORDER: 1) Install/start Shizuku using Wireless debugging. 2) Start Tracking + Anchor. 3) CONNECT SHIZUKU and allow permission. 4) CREATE LEFT DISPLAY then LAUNCH LEFT APP. 5) Repeat for RIGHT with a different app. Tracking and VirtualDisplay code are unchanged from the smooth diagnostic build."); note.setPadding(0,16,0,0); root.addView(note);

        start.setOnClickListener(v->requestCapture()); pin.setOnClickListener(v->pinHere()); stop.setOnClickListener(v->stopAnchor());
        sl.setOnClickListener(v->snapshot(true)); sr.setOnClickListener(v->snapshot(false)); cl.setOnClickListener(v->clear(true)); cr.setOnClickListener(v->clear(false));
        shizuku.setOnClickListener(v->connectShizuku());
        createLeft.setOnClickListener(v->createLabDisplay(true));
        createRight.setOnClickListener(v->createLabDisplay(false));
        launchLeft.setOnClickListener(v->chooseAndLaunchApp(true));
        launchRight.setOnClickListener(v->chooseAndLaunchApp(false));
        destroyLeft.setOnClickListener(v->releaseLabDisplay(true, "LEFT lab display released"));
        destroyRight.setOnClickListener(v->releaseLabDisplay(false, "RIGHT lab display released"));
        floating.setOnClickListener(v->enableFloatingControls());
        ix.setOnCheckedChangeListener((b2,c)->invertX=c); iy.setOnCheckedChangeListener((b2,c)->invertY=c);
        size.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelScale=.46f+.42f*(p/100f);layoutWorld();}});
        spacing.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelSpacingScreens=.78f+.75f*(p/100f);layoutWorld();}});
        panelScale=.46f+.42f*.60f; panelSpacingScreens=.78f+.75f*.52f;
        setContentView(sv);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener { public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }
    private TextView box(LinearLayout r,String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(13);v.setTypeface(Typeface.MONOSPACE);v.setTextColor(0xffe8eee8);v.setBackgroundColor(0xff20242a);v.setPadding(12,12,12,12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);r.addView(v,lp);return v;}
    private Button button(String t,int c){Button b=new Button(this);b.setText(t);b.setTextColor(Color.WHITE);b.setBackgroundColor(c);return b;}


    private void enableFloatingControls() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlayPermissionRequested = true;
            status.setText("Allow ‘Display over other apps’, then return here");
            Intent i = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(i);
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        try {
            Intent i = new Intent(this, OverlayControlService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(i); else startService(i);
            status.setText("FLOATING CONTROLS ACTIVE — switch to another app");
        } catch (Throwable t) {
            status.setText("Could not start floating controls: " + t.getMessage());
        }
    }

    @Override protected void onResume() {
        super.onResume();
        if (overlayPermissionRequested && (Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this))) {
            overlayPermissionRequested = false;
            startOverlayService();
        }
    }

    private Display externalDisplay(){DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);Display[] p=dm.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);if(p!=null)for(Display d:p)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;for(Display d:dm.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return null;}

    private void requestCapture(){
        if(anchorRunning||projection!=null){status.setText("Already running — STOP first");return;}
        Display d=externalDisplay(); if(d==null){status.setText("No external RayNeo display detected");return;}
        status.setText("Requesting Android screen capture…"); startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(req!=REQ_CAPTURE)return;
        if(result!=RESULT_OK||data==null){status.setText("Capture permission cancelled");return;}
        projection=projectionManager.getMediaProjection(result,data); if(projection==null){status.setText("MediaProjection failed");return;}
        projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(!stopping){anchorRunning=false;status.setText("Capture stopped by Android");}});}};
        projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper()));
        startSpatialDisplay();
    }

    private void startSpatialDisplay(){
        Display d=externalDisplay(); if(d==null){status.setText("RayNeo display disappeared");stopAnchor();return;}
        try{presentation=new SpatialPresentation(this,d);presentation.show();}catch(Throwable t){status.setText("Presentation failed: "+t.getMessage());stopAnchor();return;}
        presentation.root.post(()->{layoutWorld(); attachCapture(); pinHere();});
    }

    private void attachCapture(){
        if(presentation==null)return;
        presentation.texture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startVirtualDisplay(st);}
            public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
            public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseVD();return true;}
            public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(presentation.texture.isAvailable())startVirtualDisplay(presentation.texture.getSurfaceTexture());
    }

    private void startVirtualDisplay(SurfaceTexture st){
        releaseVD(); if(stopping||projection==null||st==null)return;
        DisplayMetrics m=new DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(m);
        float ds=Math.min(1f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(m.widthPixels,m.heightPixels));
        int w=Math.max(320,Math.round(m.widthPixels*ds)),h=Math.max(240,Math.round(m.heightPixels*ds)),dpi=Math.max(160,Math.round(m.densityDpi*ds));
        st.setDefaultBufferSize(w,h); captureSurface=new Surface(st);
        virtualDisplay=projection.createVirtualDisplay("RayNeoSpatialCapture",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,captureSurface,null,null);
        anchorRunning=virtualDisplay!=null;
        status.setText(anchorRunning?"SPATIAL DESKTOP ACTIVE — three world positions":"Virtual display failed");
    }

    private void layoutWorld(){
        if(presentation==null||presentation.root==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight(); if(vw<=0||vh<=0)return;
        int worldW=vw*5;
        FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)presentation.world.getLayoutParams();wlp.width=worldW;wlp.height=vh;wlp.gravity=Gravity.TOP|Gravity.LEFT;presentation.world.setLayoutParams(wlp);
        int pw=Math.max(320,Math.round(vw*panelScale));int ph=Math.max(240,Math.round(vh*panelScale));
        float cx=worldW/2f;
        float gap=panelSpacingScreens*vw;
        placePanel(presentation.leftPanel,pw,ph,cx-gap, vh/2f);
        placePanel(presentation.centerPanel,pw,ph,cx, vh/2f);
        placePanel(presentation.rightPanel,pw,ph,cx+gap, vh/2f);
        presentation.worldCenterX=cx;
        updateCamera();
    }

    private void placePanel(View v,int w,int h,float centerX,float centerY){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();lp.width=w;lp.height=h;lp.gravity=Gravity.TOP|Gravity.LEFT;v.setLayoutParams(lp);v.setX(centerX-w/2f);v.setY(centerY-h/2f);}

    private void pinHere(){
        if(!havePose&&TrackingService.livePoseValid){latestPitch=(float)TrackingService.livePitch;latestYaw=(float)TrackingService.liveYaw;filteredPitch=latestPitch;filteredYaw=latestYaw;havePose=true;}
        if(!havePose){status.setText("Start head tracking first — no IMU pose yet");return;}
        filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;updateCamera();status.setText("PINNED — centre is straight ahead");
    }

    private void updateCamera(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float yaw=filteredYaw-anchorYaw,pitch=filteredPitch-anchorPitch;
        float dx=(invertX?1f:-1f)*(yaw/hFovDeg)*vw;
        float dy=(invertY?1f:-1f)*(pitch/vFovDeg)*vh;
        float baseX=vw/2f-presentation.worldCenterX;
        presentation.world.setTranslationX(baseX+dx);
        presentation.world.setTranslationY(dy);
        lastDx=dx;lastDy=dy;
    }


    /**
     * v0.9.2: create an ordinary app-owned VirtualDisplay only when requested.
     * This deliberately does not use MediaProjection. App launch remains a separate manual action.
     * Any failure is caught and printed in the UI rather than allowed to take down Anchor Mode.
     */
    private void createLabDisplay(boolean left){
        if (stopping) { setLabStatus("BLOCKED: Anchor is stopping"); return; }
        if (!anchorRunning || presentation == null) { setLabStatus("BLOCKED: Start Anchor normally first"); return; }
        if (left ? leftLabDisplay != null : rightLabDisplay != null) {
            setLabStatus((left?"LEFT":"RIGHT") + " already exists — destroy it first");
            return;
        }

        final TextureView tv = left ? presentation.leftLabTexture : presentation.rightLabTexture;
        final TextView label = left ? presentation.leftLabel : presentation.rightLabel;
        final String side = left ? "LEFT" : "RIGHT";
        if (tv == null) { setLabStatus(side + " failed: diagnostic TextureView missing"); return; }

        try {
            label.setText(side + "\nVIRTUAL DISPLAY\nWAITING FOR SURFACE");
            label.setVisibility(View.VISIBLE);
            tv.setVisibility(View.VISIBLE);
            tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
                @Override public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){
                    startLabVirtualDisplay(left, st, w, h);
                }
                @Override public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){}
                @Override public boolean onSurfaceTextureDestroyed(SurfaceTexture st){
                    releaseLabDisplay(left, side + " surface destroyed");
                    return true;
                }
                @Override public void onSurfaceTextureUpdated(SurfaceTexture st){}
            });
            if (tv.isAvailable()) startLabVirtualDisplay(left, tv.getSurfaceTexture(), tv.getWidth(), tv.getHeight());
            else setLabStatus(side + ": waiting for TextureView surface…");
        } catch (Throwable t) {
            showLabError(side + " setup", t);
            releaseLabDisplay(left, null);
        }
    }

    private void startLabVirtualDisplay(boolean left, SurfaceTexture st, int surfaceW, int surfaceH){
        final String side = left ? "LEFT" : "RIGHT";
        if (stopping || presentation == null || st == null) return;
        if (left ? leftLabDisplay != null : rightLabDisplay != null) return;
        try {
            int w = Math.max(320, surfaceW > 0 ? surfaceW : 640);
            int h = Math.max(240, surfaceH > 0 ? surfaceH : 360);
            DisplayMetrics metrics = getResources().getDisplayMetrics();
            int dpi = Math.max(160, metrics.densityDpi);
            st.setDefaultBufferSize(w,h);
            Surface surface = new Surface(st);

            int flags = DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION
                    | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY;
            DisplayManager dm=(DisplayManager)getSystemService(DISPLAY_SERVICE);
            VirtualDisplay vd=dm.createVirtualDisplay("RayNeoLab"+side,w,h,dpi,surface,flags);
            if(vd==null){
                try{surface.release();}catch(Throwable ignored){}
                setLabStatus(side + " FAILED: DisplayManager returned null");
                return;
            }
            if(left){leftLabDisplay=vd;leftLabSurface=surface;}
            else{rightLabDisplay=vd;rightLabSurface=surface;}
            Display disp=vd.getDisplay();
            int id=disp!=null?disp.getDisplayId():-1;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            label.setText(side + "\nVIRTUAL DISPLAY CREATED\nDisplay ID " + id + "\nready for app launch");
            label.bringToFront();
            setLabStatus(side + " SUCCESS — VirtualDisplay ID " + id + ". Tracking should remain smooth.");
        }catch(Throwable t){
            showLabError(side + " createVirtualDisplay",t);
            releaseLabDisplay(left,null);
        }
    }

    private static class AppChoice {
        final String label;
        final String packageName;
        AppChoice(String label,String packageName){this.label=label;this.packageName=packageName;}
    }

    /**
     * Shows launchable installed apps only after the requested side VirtualDisplay exists.
     * Launch is explicit and isolated so a blocked activity cannot affect the proven tracker path.
     */
    private void chooseAndLaunchApp(boolean left){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){
            setLabStatus("BLOCKED: CREATE " + side + " DISPLAY first");
            return;
        }
        try{
            PackageManager pm=getPackageManager();
            Intent main=new Intent(Intent.ACTION_MAIN,null);
            main.addCategory(Intent.CATEGORY_LAUNCHER);
            List<ResolveInfo> ris=pm.queryIntentActivities(main,0);
            final ArrayList<AppChoice> apps=new ArrayList<>();
            for(ResolveInfo ri:ris){
                if(ri==null||ri.activityInfo==null)continue;
                String pkg=ri.activityInfo.packageName;
                if(pkg==null||pkg.equals(getPackageName()))continue;
                CharSequence cs=ri.loadLabel(pm);
                String label=cs!=null?cs.toString():pkg;
                boolean duplicate=false;
                for(AppChoice a:apps)if(a.packageName.equals(pkg)){duplicate=true;break;}
                if(!duplicate)apps.add(new AppChoice(label,pkg));
            }
            Collections.sort(apps,new Comparator<AppChoice>(){
                @Override public int compare(AppChoice a,AppChoice b){return a.label.compareToIgnoreCase(b.label);}
            });
            if(apps.isEmpty()){setLabStatus(side + " app list is empty");return;}
            String[] labels=new String[apps.size()];
            for(int i=0;i<apps.size();i++)labels[i]=apps.get(i).label;
            new AlertDialog.Builder(this)
                    .setTitle("Launch app on " + side)
                    .setItems(labels,(dialog,which)->launchAppOnSide(left,apps.get(which)))
                    .setNegativeButton("CANCEL",null)
                    .show();
        }catch(Throwable t){
            showLabError(side + " app picker",t);
        }
    }

    private void launchAppOnSide(boolean left,AppChoice app){
        final String side=left?"LEFT":"RIGHT";
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(vd==null||vd.getDisplay()==null){setLabStatus(side + " display disappeared before launch");return;}
        final int displayId=vd.getDisplay().getDisplayId();
        if(!shizukuReady){setLabStatus("BLOCKED: CONNECT SHIZUKU first, then retry " + side + " launch");return;}
        try{
            PackageManager pm=getPackageManager();
            Intent launch=pm.getLaunchIntentForPackage(app.packageName);
            if(launch==null){setLabStatus(side + " FAILED: no launch intent for " + app.label);return;}
            ComponentName component=launch.getComponent();
            if(component==null){
                ResolveInfo ri=pm.resolveActivity(launch,0);
                if(ri!=null&&ri.activityInfo!=null)component=new ComponentName(ri.activityInfo.packageName,ri.activityInfo.name);
            }
            if(component==null){setLabStatus(side + " FAILED: could not resolve launch component for " + app.label);return;}
            final String flat=component.flattenToString();
            setLabStatus(side + " SHIZUKU LAUNCH → " + app.label + " on Display ID " + displayId + "…");
            new Thread(() -> {
                try{
                    final String result=runShizukuShell(new String[]{"am","start","--display",Integer.toString(displayId),"-n",flat});
                    runOnUiThread(() -> {
                        if(presentation!=null){
                            TextView label=left?presentation.leftLabel:presentation.rightLabel;
                            TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
                            if(tv!=null)tv.setVisibility(View.VISIBLE);
                            if(label!=null)label.setVisibility(View.GONE);
                        }
                        setLabStatus(side + " SHIZUKU RESULT — " + app.label + " → Display " + displayId + "\n" + result);
                    });
                }catch(Throwable t){ runOnUiThread(() -> showLabError(side + " Shizuku launch " + app.label,t)); }
            },"RayNeo-ShizukuLaunch").start();
        }catch(Throwable t){showLabError(side + " prepare Shizuku launch",t);}
    }

    private String runShizukuShell(String[] command) throws Exception {
        Method m=Shizuku.class.getDeclaredMethod("newProcess", String[].class, String[].class, String.class);
        m.setAccessible(true);
        Object remote=m.invoke(null, command, null, null);
        if(remote==null)return "ERROR: Shizuku returned no process";
        Class<?> cls=remote.getClass();
        java.io.InputStream stdout=(java.io.InputStream)cls.getMethod("getInputStream").invoke(remote);
        java.io.InputStream stderr=(java.io.InputStream)cls.getMethod("getErrorStream").invoke(remote);
        String out=readStream(stdout);
        String err=readStream(stderr);
        int rc=((Number)cls.getMethod("waitFor").invoke(remote)).intValue();
        try{cls.getMethod("destroy").invoke(remote);}catch(Throwable ignored){}
        return "serverUid=" + Shizuku.getUid() + " rc=" + rc + (out.isEmpty()?"":"\n"+out) + (err.isEmpty()?"":"\nERR: "+err);
    }

    private String readStream(java.io.InputStream in) throws Exception {
        StringBuilder sb=new StringBuilder();
        try(BufferedReader br=new BufferedReader(new InputStreamReader(in))){
            String line; while((line=br.readLine())!=null){if(sb.length()>0)sb.append('\n');sb.append(line);}
        }
        return sb.toString();
    }

    private void connectShizuku(){
        try{
            if(!Shizuku.pingBinder()){shizukuReady=false;setLabStatus("SHIZUKU NOT RUNNING — start Shizuku then retry");return;}
            if(Shizuku.isPreV11()){shizukuReady=false;setLabStatus("SHIZUKU TOO OLD — v11+ required");return;}
            if(Shizuku.checkSelfPermission()!=PackageManager.PERMISSION_GRANTED){
                shizukuReady=false;
                setLabStatus("Requesting Shizuku permission…");
                Shizuku.requestPermission(SHIZUKU_PERMISSION_REQUEST);
                return;
            }
            shizukuReady=true;refreshShizukuState();
        }catch(Throwable t){shizukuReady=false;showLabError("connect Shizuku",t);}
    }

    private void refreshShizukuState(){
        try{
            if(Shizuku.pingBinder()){
                int uid=Shizuku.getUid();
                boolean granted=Shizuku.checkSelfPermission()==PackageManager.PERMISSION_GRANTED;
                shizukuReady=granted;
                setLabStatus(granted?"SHIZUKU READY — server uid="+uid+" (2000 expected for Wireless debugging)":"SHIZUKU RUNNING — press CONNECT SHIZUKU and allow permission");
            }else shizukuReady=false;
        }catch(Throwable ignored){}
    }

    private void showLabError(String stage, Throwable t){
        String msg=t.getMessage();
        if(msg==null||msg.trim().isEmpty())msg="(no message)";
        String text="ERROR at " + stage + "\n" + t.getClass().getName() + "\n" + msg;
        setLabStatus(text);
        android.util.Log.e("RayNeoV093",text,t);
    }

    private void setLabStatus(String text){
        if(labInfo!=null)labInfo.setText("LAB: " + text);
    }

    private void releaseLabDisplay(boolean left,String message){
        VirtualDisplay vd=left?leftLabDisplay:rightLabDisplay;
        if(left)leftLabDisplay=null;else rightLabDisplay=null;
        if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}
        Surface sf=left?leftLabSurface:rightLabSurface;
        if(left)leftLabSurface=null;else rightLabSurface=null;
        if(sf!=null)try{sf.release();}catch(Throwable ignored){}
        if(presentation!=null){
            TextureView tv=left?presentation.leftLabTexture:presentation.rightLabTexture;
            TextView label=left?presentation.leftLabel:presentation.rightLabel;
            if(tv!=null){try{tv.setSurfaceTextureListener(null);}catch(Throwable ignored){}tv.setVisibility(View.GONE);}
            if(label!=null){label.setText(left?"LEFT\nSNAPSHOT":"RIGHT\nSNAPSHOT");label.setVisibility(View.VISIBLE);}
        }
        if(message!=null)setLabStatus(message);
    }

    private void snapshot(boolean left){
        if(presentation==null||!presentation.texture.isAvailable()){status.setText("Start Anchor first");return;}
        try{Bitmap b=presentation.texture.getBitmap();if(b==null){status.setText("Snapshot empty");return;}ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView label=left?presentation.leftLabel:presentation.rightLabel;iv.setImageBitmap(b);iv.setVisibility(View.VISIBLE);label.setVisibility(View.GONE);status.setText(left?"LEFT panel saved":"RIGHT panel saved");}catch(Throwable t){status.setText("Snapshot failed: "+t.getMessage());}
    }
    private void clear(boolean left){if(presentation==null)return;ImageView iv=left?presentation.leftImage:presentation.rightImage;TextView l=left?presentation.leftLabel:presentation.rightLabel;iv.setImageDrawable(null);iv.setVisibility(View.GONE);l.setVisibility(View.VISIBLE);}

    private void releaseVD(){VirtualDisplay vd=virtualDisplay;virtualDisplay=null;if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}Surface s=captureSurface;captureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){} }
    private void stopAnchor(){
        if(stopping)return;stopping=true;anchorRunning=false;
        releaseLabDisplay(true,null); releaseLabDisplay(false,null);
        releaseVD();
        SpatialPresentation p=presentation;presentation=null;if(p!=null){try{p.texture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        MediaProjection mp=projection;projection=null;if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}
        projectionCallback=null;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");
    }
    @Override protected void onDestroy(){
        Choreographer.getInstance().removeFrameCallback(frameCallback);
        try{unregisterReceiver(overlayReceiver);}catch(Throwable ignored){}
        try{Shizuku.removeBinderReceivedListener(shizukuBinderListener);}catch(Throwable ignored){}
        try{Shizuku.removeBinderDeadListener(shizukuDeadListener);}catch(Throwable ignored){}
        try{Shizuku.removeRequestPermissionResultListener(shizukuPermissionListener);}catch(Throwable ignored){}
        try{stopService(new Intent(this,OverlayControlService.class));}catch(Throwable ignored){}
        stopAnchor();
        super.onDestroy();
    }

    private static class SpatialPresentation extends Presentation {
        FrameLayout root,world,leftPanel,centerPanel,rightPanel;TextureView texture,leftLabTexture,rightLabTexture;ImageView leftImage,rightImage;TextView leftLabel,rightLabel;float worldCenterX;
        SpatialPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){
            super.onCreate(b);getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(true);
            world=new FrameLayout(getContext());world.setBackgroundColor(Color.BLACK);world.setClipChildren(false);world.setClipToPadding(false);root.addView(world,new FrameLayout.LayoutParams(1,-1,Gravity.TOP|Gravity.LEFT));
            leftPanel=panel(getContext(),0xff171b22);centerPanel=panel(getContext(),Color.BLACK);rightPanel=panel(getContext(),0xff171b22);
            world.addView(leftPanel,new FrameLayout.LayoutParams(1,1));world.addView(centerPanel,new FrameLayout.LayoutParams(1,1));world.addView(rightPanel,new FrameLayout.LayoutParams(1,1));
            leftImage=image(getContext());leftPanel.addView(leftImage,new FrameLayout.LayoutParams(-1,-1));leftLabTexture=new TextureView(getContext());leftLabTexture.setOpaque(true);leftLabTexture.setVisibility(View.GONE);leftPanel.addView(leftLabTexture,new FrameLayout.LayoutParams(-1,-1));leftLabel=label(getContext(),"LEFT\nSNAPSHOT");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1));
            texture=new TextureView(getContext());texture.setOpaque(true);centerPanel.addView(texture,new FrameLayout.LayoutParams(-1,-1));TextView ct=tag(getContext(),"CENTRE • LIVE");FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=10;centerPanel.addView(ct,ctlp);
            rightImage=image(getContext());rightPanel.addView(rightImage,new FrameLayout.LayoutParams(-1,-1));rightLabTexture=new TextureView(getContext());rightLabTexture.setOpaque(true);rightLabTexture.setVisibility(View.GONE);rightPanel.addView(rightLabTexture,new FrameLayout.LayoutParams(-1,-1));rightLabel=label(getContext(),"RIGHT\nSNAPSHOT");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1));
            setContentView(root);
        }
        private static FrameLayout panel(Context c,int bg){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(bg);f.setClipChildren(true);f.setElevation(2f);return f;}
        private static ImageView image(Context c){ImageView i=new ImageView(c);i.setScaleType(ImageView.ScaleType.FIT_CENTER);i.setBackgroundColor(Color.BLACK);i.setVisibility(View.GONE);return i;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(28);v.setGravity(Gravity.CENTER);v.setTextColor(0xffe0e0e0);v.setBackgroundColor(0xff171b22);return v;}
        private static TextView tag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(13);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }
}
