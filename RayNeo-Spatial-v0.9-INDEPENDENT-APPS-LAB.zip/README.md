# RayNeo Spatial v0.9 — INDEPENDENT APPS LAB

Experimental successor to the known-good v0.8 beta.

## What this build tests

- Keeps the proven Air 4 Pro IMU / smooth 3DoF anchoring path.
- Centre panel remains the normal live Android screen via MediaProjection.
- LEFT creates its own Android `VirtualDisplay`.
- RIGHT creates a second independent Android `VirtualDisplay`.
- `SELECT LEFT APP` and `SELECT RIGHT APP` list installed launchable apps.
- The selected activity is launched with `ActivityOptions.setLaunchDisplayId()` onto that panel's display.
- Floating controls become `◀ APP | PIN | APP ▶ | ×`.

## The test that matters

1. Start normal RayNeo head tracking.
2. Open Anchor / Spatial Desktop.
3. Press **START SPATIAL DESKTOP** and allow screen capture.
4. Press **PIN HERE**.
5. Press **SELECT LEFT APP** and choose an app (e.g. YouTube).
6. Press **SELECT RIGHT APP** and choose a different app (e.g. Chrome or Settings).
7. Look left / centre / right.

### Success

LEFT and RIGHT show different, independently running live apps while CENTRE remains the normal phone screen.

### Useful failure

If a side panel says **ANDROID BLOCKED APP LAUNCH**, the device/ROM is preventing ordinary apps from launching third-party activities onto app-owned virtual displays. That tells us the next version needs a privileged bridge (likely Shizuku/ADB or device-specific support).

## Current limitation

This lab does **not** forward touch/mouse input into the side VirtualDisplays yet. First we need to prove that independent third-party activities can render there at all.

Do not replace the public v0.8 release with this lab build yet.
