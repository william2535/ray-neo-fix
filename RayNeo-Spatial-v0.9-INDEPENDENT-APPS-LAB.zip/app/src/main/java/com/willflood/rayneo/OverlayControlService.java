package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.os.*;
import android.view.*;
import android.widget.*;

/** Floating controls for the v0.9 independent-apps lab. */
public class OverlayControlService extends Service {
    private static final String CHANNEL_ID="rayneo_anchor_controls";
    private WindowManager wm; private LinearLayout bar; private WindowManager.LayoutParams params;

    @Override public void onCreate(){super.onCreate();createChannel();Notification n=new Notification.Builder(this,CHANNEL_ID).setSmallIcon(android.R.drawable.ic_menu_view).setContentTitle("RayNeo Spatial Controls").setContentText("Independent panel controls active").setOngoing(true).build();startForeground(2208,n);showOverlay();}
    private void createChannel(){if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL_ID,"RayNeo Spatial Controls",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}}
    private TextView control(String s){TextView v=new TextView(this);v.setText(s);v.setTextColor(Color.WHITE);v.setTextSize(14);v.setGravity(Gravity.CENTER);v.setPadding(15,14,15,14);v.setBackgroundColor(0xdd263238);return v;}
    private void showOverlay(){
        if(bar!=null)return;wm=(WindowManager)getSystemService(WINDOW_SERVICE);bar=new LinearLayout(this);bar.setOrientation(LinearLayout.HORIZONTAL);bar.setGravity(Gravity.CENTER_VERTICAL);bar.setBackgroundColor(0xcc101417);bar.setPadding(4,4,4,4);
        TextView left=control("◀ APP"),pin=control("📌 PIN"),right=control("APP ▶"),close=control("×");bar.addView(left);bar.addView(pin);bar.addView(right);bar.addView(close);
        int type=Build.VERSION.SDK_INT>=26?WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY:WindowManager.LayoutParams.TYPE_PHONE;params=new WindowManager.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT,WindowManager.LayoutParams.WRAP_CONTENT,type,WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE|WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,PixelFormat.TRANSLUCENT);params.gravity=Gravity.TOP|Gravity.START;params.x=20;params.y=120;
        final float[] down=new float[4];pin.setOnTouchListener((v,e)->{switch(e.getActionMasked()){case MotionEvent.ACTION_DOWN:down[0]=e.getRawX();down[1]=e.getRawY();down[2]=params.x;down[3]=params.y;return false;case MotionEvent.ACTION_MOVE:if(Math.abs(e.getRawX()-down[0])>12||Math.abs(e.getRawY()-down[1])>12){params.x=(int)(down[2]+e.getRawX()-down[0]);params.y=(int)(down[3]+e.getRawY()-down[1]);try{wm.updateViewLayout(bar,params);}catch(Throwable ignored){}return true;}}return false;});
        left.setOnClickListener(v->send(AnchorActivity.CMD_SELECT_LEFT));right.setOnClickListener(v->send(AnchorActivity.CMD_SELECT_RIGHT));pin.setOnClickListener(v->send(AnchorActivity.CMD_PIN));close.setOnClickListener(v->stopSelf());try{wm.addView(bar,params);}catch(Throwable t){stopSelf();}
    }
    private void send(String command){Intent i=new Intent(AnchorActivity.ACTION_OVERLAY).setPackage(getPackageName()).putExtra(AnchorActivity.EXTRA_COMMAND,command);sendBroadcast(i);}
    @Override public int onStartCommand(Intent intent,int flags,int startId){return START_STICKY;}@Override public IBinder onBind(Intent i){return null;}
    @Override public void onDestroy(){if(bar!=null&&wm!=null)try{wm.removeView(bar);}catch(Throwable ignored){}bar=null;stopForeground(true);super.onDestroy();}
}
