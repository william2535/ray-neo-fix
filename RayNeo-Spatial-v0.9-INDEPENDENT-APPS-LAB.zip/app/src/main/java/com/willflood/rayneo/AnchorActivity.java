package com.willflood.rayneo;

import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.*;
import android.graphics.SurfaceTexture;
import android.hardware.display.*;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.os.*;
import android.provider.Settings;
import android.net.Uri;
import android.util.DisplayMetrics;
import android.view.*;
import android.widget.*;
import java.util.*;

/**
 * RayNeo Spatial Desktop v0.9 INDEPENDENT APPS LAB.
 *
 * Centre: live MediaProjection capture of the normal Android display.
 * Left/Right: app-owned Android VirtualDisplays. A selected launchable activity is
 * started directly on each display using ActivityOptions.setLaunchDisplayId().
 *
 * This is intentionally a LAB build: many Android ROMs restrict third-party activity
 * launches on virtual displays. Success/failure is reported explicitly in the UI.
 */
public class AnchorActivity extends Activity {
    public static final String ACTION_OVERLAY = "com.willflood.rayneo.ANCHOR_OVERLAY_ACTION";
    public static final String EXTRA_COMMAND = "command";
    public static final String CMD_PIN = "pin";
    public static final String CMD_STOP = "stop";
    public static final String CMD_SELECT_LEFT = "select_left";
    public static final String CMD_SELECT_RIGHT = "select_right";

    private static final int REQ_CAPTURE = 4401;
    private static final int MAX_CAPTURE_LONG_EDGE = 1280;
    private static final long UI_INTERVAL_MS = 250L;

    private MediaProjectionManager projectionManager;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay centreCaptureDisplay;
    private Surface centreCaptureSurface;
    private SpatialPresentation presentation;

    private DisplayManager displayManager;
    private VirtualDisplay leftAppDisplay, rightAppDisplay;
    private Surface leftAppSurface, rightAppSurface;
    private int leftDisplayId = Display.INVALID_DISPLAY;
    private int rightDisplayId = Display.INVALID_DISPLAY;
    private String leftAppName = "EMPTY", rightAppName = "EMPTY";
    private String leftPackage, rightPackage;

    private TextView status, poseInfo, renderInfo;
    private boolean overlayPermissionRequested;

    private volatile float latestPitch, latestYaw;
    private float filteredPitch, filteredYaw;
    private float anchorPitch, anchorYaw;
    private boolean havePose;

    private boolean anchorRunning, stopping;
    private boolean invertX = true, invertY = true;
    private float panelScale = 0.72f;
    private float panelSpacingScreens = 1.02f;
    private float hFovDeg = 46f, vFovDeg = 27f;
    private long lastFrameNs, lastUiMs;
    private float lastDx, lastDy;

    private final BroadcastReceiver overlayReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (!ACTION_OVERLAY.equals(intent.getAction())) return;
            String command = intent.getStringExtra(EXTRA_COMMAND);
            if (CMD_PIN.equals(command)) pinHere();
            else if (CMD_SELECT_LEFT.equals(command)) chooseApp(true);
            else if (CMD_SELECT_RIGHT.equals(command)) chooseApp(false);
            else if (CMD_STOP.equals(command)) stopAnchor();
        }
    };

    private final Choreographer.FrameCallback frameCallback = new Choreographer.FrameCallback() {
        @Override public void doFrame(long frameTimeNanos) {
            if (isFinishing() || isDestroyed()) return;

            if (TrackingService.livePoseValid) {
                latestPitch = (float) TrackingService.livePitch;
                latestYaw = (float) TrackingService.liveYaw;
                if (!havePose) {
                    filteredPitch = latestPitch;
                    filteredYaw = latestYaw;
                    anchorPitch = filteredPitch;
                    anchorYaw = filteredYaw;
                    havePose = true;
                }
            }

            if (havePose) {
                float dt = lastFrameNs == 0 ? 1f/60f : Math.min(.05f,(frameTimeNanos-lastFrameNs)/1_000_000_000f);
                float alpha = 1f-(float)Math.exp(-dt*30f);
                filteredPitch += (latestPitch-filteredPitch)*alpha;
                filteredYaw += (latestYaw-filteredYaw)*alpha;
            }
            lastFrameNs = frameTimeNanos;

            if (anchorRunning && !stopping) updateCamera();

            long now = SystemClock.uptimeMillis();
            if (now-lastUiMs >= UI_INTERVAL_MS) {
                lastUiMs=now;
                poseInfo.setText(String.format(Locale.UK,
                        "PITCH %+7.2f°   YAW %+7.2f°\nPIN   %+7.2f°   %+7.2f°",
                        filteredPitch,filteredYaw,anchorPitch,anchorYaw));
                renderInfo.setText(String.format(Locale.UK,
                        "CAMERA X %+7.0f px   Y %+7.0f px\nLEFT [%d] %s\nCENTRE LIVE\nRIGHT [%d] %s",
                        lastDx,lastDy,leftDisplayId,leftAppName,rightDisplayId,rightAppName));
            }
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        projectionManager=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
        displayManager=(DisplayManager)getSystemService(DISPLAY_SERVICE);
        registerReceiver(overlayReceiver, new IntentFilter(ACTION_OVERLAY));
        buildUi();
        Choreographer.getInstance().postFrameCallback(frameCallback);
    }

    private void buildUi() {
        ScrollView sv=new ScrollView(this);
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(24,24,24,32); sv.addView(root);
        TextView title=new TextView(this); title.setText("RAYNEO SPATIAL DESKTOP • v0.9 INDEPENDENT APPS LAB"); title.setTextSize(22); title.setTypeface(null,Typeface.BOLD); root.addView(title);
        TextView help=new TextView(this); help.setText("Experimental build: CENTRE is your normal live Android screen. LEFT and RIGHT are separate Android VirtualDisplays. Pick an installed app for each side and this build will try to launch it directly onto that panel. Some Android ROMs block this — the result is part of the test."); help.setPadding(0,8,0,12); root.addView(help);
        status=box(root,"Ready — start head tracking first, then START SPATIAL DESKTOP");
        poseInfo=box(root,"IMU waiting…");
        renderInfo=box(root,"Spatial canvas not started");

        TextView sz=new TextView(this); sz.setText("Panel size"); root.addView(sz);
        SeekBar size=new SeekBar(this); size.setMax(100); size.setProgress(60); root.addView(size);
        TextView sp=new TextView(this); sp.setText("Panel spacing"); root.addView(sp);
        SeekBar spacing=new SeekBar(this); spacing.setMax(100); spacing.setProgress(52); root.addView(spacing);

        CheckBox ix=new CheckBox(this); ix.setText("Invert horizontal anchor"); ix.setChecked(true); root.addView(ix);
        CheckBox iy=new CheckBox(this); iy.setText("Invert vertical anchor"); iy.setChecked(true); root.addView(iy);

        LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
        Button start=button("START SPATIAL DESKTOP",0xff2f7d4a), pin=button("PIN HERE",0xff59645b);
        row.addView(start,new LinearLayout.LayoutParams(0,-2,1)); row.addView(pin,new LinearLayout.LayoutParams(0,-2,1)); root.addView(row);

        LinearLayout apps=new LinearLayout(this); apps.setOrientation(LinearLayout.HORIZONTAL);
        Button left=button("SELECT LEFT APP",0xff315c82), right=button("SELECT RIGHT APP",0xff315c82);
        apps.addView(left,new LinearLayout.LayoutParams(0,-2,1)); apps.addView(right,new LinearLayout.LayoutParams(0,-2,1)); root.addView(apps);

        LinearLayout relaunch=new LinearLayout(this); relaunch.setOrientation(LinearLayout.HORIZONTAL);
        Button rl=button("RELAUNCH LEFT",0xff4f638c), rr=button("RELAUNCH RIGHT",0xff4f638c);
        relaunch.addView(rl,new LinearLayout.LayoutParams(0,-2,1)); relaunch.addView(rr,new LinearLayout.LayoutParams(0,-2,1)); root.addView(relaunch);

        Button floating=button("ENABLE FLOATING CONTROLS",0xff7b4f9c); LinearLayout.LayoutParams flp=new LinearLayout.LayoutParams(-1,-2); flp.setMargins(0,8,0,8); root.addView(floating,flp);
        Button stop=button("STOP SPATIAL DESKTOP",0xffa43f35); root.addView(stop);

        TextView note=new TextView(this);
        note.setText("TEST: Start → grant screen capture → PIN HERE → SELECT LEFT APP → choose e.g. YouTube → SELECT RIGHT APP → choose a different app. If both side panels show different live apps while centre remains your normal screen, the VirtualDisplay/task-launch architecture works on this handheld. Touch/click forwarding to side displays is NOT implemented yet.");
        note.setPadding(0,16,0,0); root.addView(note);

        start.setOnClickListener(v->requestCapture()); pin.setOnClickListener(v->pinHere()); stop.setOnClickListener(v->stopAnchor());
        left.setOnClickListener(v->chooseApp(true)); right.setOnClickListener(v->chooseApp(false));
        rl.setOnClickListener(v->relaunch(true)); rr.setOnClickListener(v->relaunch(false));
        floating.setOnClickListener(v->enableFloatingControls());
        ix.setOnCheckedChangeListener((b2,c)->invertX=c); iy.setOnCheckedChangeListener((b2,c)->invertY=c);
        size.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelScale=.46f+.42f*(p/100f);layoutWorld();}});
        spacing.setOnSeekBarChangeListener(new SimpleSeek(){@Override public void onProgressChanged(SeekBar s,int p,boolean f){panelSpacingScreens=.78f+.75f*(p/100f);layoutWorld();}});
        panelScale=.46f+.42f*.60f; panelSpacingScreens=.78f+.75f*.52f;
        setContentView(sv);
    }

    private abstract static class SimpleSeek implements SeekBar.OnSeekBarChangeListener { public void onStartTrackingTouch(SeekBar s){} public void onStopTrackingTouch(SeekBar s){} }
    private TextView box(LinearLayout r,String t){TextView v=new TextView(this);v.setText(t);v.setTextSize(13);v.setTypeface(Typeface.MONOSPACE);v.setTextColor(0xffe8eee8);v.setBackgroundColor(0xff20242a);v.setPadding(12,12,12,12);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,6,0,6);r.addView(v,lp);return v;}
    private Button button(String t,int c){Button b=new Button(this);b.setText(t);b.setTextColor(Color.WHITE);b.setBackgroundColor(c);return b;}

    private void enableFloatingControls() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            overlayPermissionRequested = true;
            status.setText("Allow ‘Display over other apps’, then return here");
            startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName())));
            return;
        }
        startOverlayService();
    }

    private void startOverlayService() {
        try { Intent i=new Intent(this,OverlayControlService.class); if(Build.VERSION.SDK_INT>=26)startForegroundService(i);else startService(i); status.setText("FLOATING CONTROLS ACTIVE"); }
        catch(Throwable t){status.setText("Could not start floating controls: "+t.getMessage());}
    }

    @Override protected void onResume(){super.onResume();if(overlayPermissionRequested&&(Build.VERSION.SDK_INT<23||Settings.canDrawOverlays(this))){overlayPermissionRequested=false;startOverlayService();}}

    private Display externalDisplay(){Display[] p=displayManager.getDisplays(DisplayManager.DISPLAY_CATEGORY_PRESENTATION);if(p!=null)for(Display d:p)if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;for(Display d:displayManager.getDisplays())if(d.getDisplayId()!=Display.DEFAULT_DISPLAY)return d;return null;}

    private void requestCapture(){
        if(anchorRunning||projection!=null){status.setText("Already running — STOP first");return;}
        Display d=externalDisplay(); if(d==null){status.setText("No external RayNeo display detected");return;}
        status.setText("Requesting Android screen capture…"); startActivityForResult(projectionManager.createScreenCaptureIntent(),REQ_CAPTURE);
    }

    @Override protected void onActivityResult(int req,int result,Intent data){
        super.onActivityResult(req,result,data); if(req!=REQ_CAPTURE)return;
        if(result!=RESULT_OK||data==null){status.setText("Capture permission cancelled");return;}
        projection=projectionManager.getMediaProjection(result,data); if(projection==null){status.setText("MediaProjection failed");return;}
        projectionCallback=new MediaProjection.Callback(){@Override public void onStop(){runOnUiThread(()->{if(!stopping){anchorRunning=false;status.setText("Capture stopped by Android");}});}};
        projection.registerCallback(projectionCallback,new Handler(Looper.getMainLooper()));
        startSpatialDisplay();
    }

    private void startSpatialDisplay(){
        Display d=externalDisplay(); if(d==null){status.setText("RayNeo display disappeared");stopAnchor();return;}
        try{presentation=new SpatialPresentation(this,d);presentation.show();}catch(Throwable t){status.setText("Presentation failed: "+t.getMessage());stopAnchor();return;}
        presentation.root.post(()->{layoutWorld();attachCentreCapture();attachSideDisplays();pinHere();});
    }

    private void attachCentreCapture(){
        if(presentation==null)return;
        presentation.centerTexture.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){startCentreCapture(st);} public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){} public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseCentreCapture();return true;} public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(presentation.centerTexture.isAvailable())startCentreCapture(presentation.centerTexture.getSurfaceTexture());
    }

    private void attachSideDisplays(){
        attachAppTexture(true,presentation.leftTexture);
        attachAppTexture(false,presentation.rightTexture);
    }

    private void attachAppTexture(final boolean left, TextureView tv){
        tv.setSurfaceTextureListener(new TextureView.SurfaceTextureListener(){
            public void onSurfaceTextureAvailable(SurfaceTexture st,int w,int h){createAppDisplay(left,st,w,h);} public void onSurfaceTextureSizeChanged(SurfaceTexture st,int w,int h){recreateAppDisplay(left,st,w,h);} public boolean onSurfaceTextureDestroyed(SurfaceTexture st){releaseAppDisplay(left);return true;} public void onSurfaceTextureUpdated(SurfaceTexture st){}
        });
        if(tv.isAvailable())createAppDisplay(left,tv.getSurfaceTexture(),tv.getWidth(),tv.getHeight());
    }

    private void startCentreCapture(SurfaceTexture st){
        releaseCentreCapture(); if(stopping||projection==null||st==null)return;
        DisplayMetrics m=new DisplayMetrics();getWindowManager().getDefaultDisplay().getRealMetrics(m);
        float ds=Math.min(1f,MAX_CAPTURE_LONG_EDGE/(float)Math.max(m.widthPixels,m.heightPixels));
        int w=Math.max(320,Math.round(m.widthPixels*ds)),h=Math.max(240,Math.round(m.heightPixels*ds)),dpi=Math.max(160,Math.round(m.densityDpi*ds));
        st.setDefaultBufferSize(w,h); centreCaptureSurface=new Surface(st);
        centreCaptureDisplay=projection.createVirtualDisplay("RayNeoCentreCapture",w,h,dpi,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,centreCaptureSurface,null,null);
        anchorRunning=centreCaptureDisplay!=null;
        status.setText(anchorRunning?"SPATIAL DESKTOP ACTIVE — select apps for LEFT / RIGHT":"Centre capture failed");
    }

    private int panelWidth(){return presentation==null?960:Math.max(480,presentation.leftPanel.getWidth());}
    private int panelHeight(){return presentation==null?540:Math.max(270,presentation.leftPanel.getHeight());}

    private void recreateAppDisplay(boolean left,SurfaceTexture st,int w,int h){String pkg=left?leftPackage:rightPackage;releaseAppDisplay(left);createAppDisplay(left,st,w,h);if(pkg!=null)new Handler(Looper.getMainLooper()).postDelayed(()->launchPackage(left,pkg),250);}

    private void createAppDisplay(boolean left, SurfaceTexture st,int surfaceW,int surfaceH){
        if(stopping||st==null||displayManager==null)return;
        releaseAppDisplay(left);
        int w=Math.max(480,surfaceW>0?surfaceW:panelWidth()); int h=Math.max(270,surfaceH>0?surfaceH:panelHeight());
        int dpi=getResources().getDisplayMetrics().densityDpi;
        st.setDefaultBufferSize(w,h); Surface surface=new Surface(st);
        int flags=DisplayManager.VIRTUAL_DISPLAY_FLAG_PUBLIC | DisplayManager.VIRTUAL_DISPLAY_FLAG_OWN_CONTENT_ONLY | DisplayManager.VIRTUAL_DISPLAY_FLAG_PRESENTATION;
        try{
            VirtualDisplay vd=displayManager.createVirtualDisplay(left?"RayNeoLeftApps":"RayNeoRightApps",w,h,dpi,surface,flags);
            if(left){leftAppDisplay=vd;leftAppSurface=surface;leftDisplayId=vd!=null?vd.getDisplay().getDisplayId():Display.INVALID_DISPLAY;}
            else{rightAppDisplay=vd;rightAppSurface=surface;rightDisplayId=vd!=null?vd.getDisplay().getDisplayId():Display.INVALID_DISPLAY;}
            updatePanelLabel(left,vd!=null?"READY\nSELECT APP":"DISPLAY FAILED");
        }catch(Throwable t){try{surface.release();}catch(Throwable ignored){}updatePanelLabel(left,"VIRTUAL DISPLAY FAILED\n"+shortMsg(t));status.setText("Side VirtualDisplay failed: "+shortMsg(t));}
    }

    private void chooseApp(final boolean left){
        if(presentation==null){status.setText("Start Spatial Desktop first");return;}
        final int displayId=left?leftDisplayId:rightDisplayId;
        if(displayId==Display.INVALID_DISPLAY){status.setText((left?"LEFT":"RIGHT")+" VirtualDisplay is not ready");return;}
        Intent probe=new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all=getPackageManager().queryIntentActivities(probe,0);
        final ArrayList<AppEntry> apps=new ArrayList<>();
        for(ResolveInfo r:all){if(r.activityInfo==null)continue;String pkg=r.activityInfo.packageName;if(getPackageName().equals(pkg))continue;CharSequence l=r.loadLabel(getPackageManager());apps.add(new AppEntry(l!=null?l.toString():pkg,pkg));}
        Collections.sort(apps,(a,b)->a.name.compareToIgnoreCase(b.name));
        if(apps.isEmpty()){status.setText("No launchable apps found");return;}
        String[] names=new String[apps.size()];for(int i=0;i<apps.size();i++)names[i]=apps.get(i).name;
        new AlertDialog.Builder(this).setTitle("Launch on "+(left?"LEFT":"RIGHT")+" panel").setItems(names,(d,which)->launchPackage(left,apps.get(which).pkg)).setNegativeButton("Cancel",null).show();
    }

    private void relaunch(boolean left){String pkg=left?leftPackage:rightPackage;if(pkg==null){chooseApp(left);return;}launchPackage(left,pkg);}

    private void launchPackage(boolean left,String pkg){
        int displayId=left?leftDisplayId:rightDisplayId;
        if(displayId==Display.INVALID_DISPLAY){status.setText("VirtualDisplay not ready");return;}
        Intent launch=getPackageManager().getLaunchIntentForPackage(pkg);
        if(launch==null){status.setText("No launcher activity for "+pkg);return;}
        String name=appName(pkg);
        try{
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK|Intent.FLAG_ACTIVITY_MULTIPLE_TASK|Intent.FLAG_ACTIVITY_NEW_DOCUMENT);
            ActivityOptions options=ActivityOptions.makeBasic();
            options.setLaunchDisplayId(displayId);
            startActivity(launch,options.toBundle());
            if(left){leftPackage=pkg;leftAppName=name;}else{rightPackage=pkg;rightAppName=name;}
            updatePanelLabel(left,"LAUNCHING\n"+name+"\nDisplay "+displayId);
            status.setText("Requested "+name+" on "+(left?"LEFT":"RIGHT")+" display "+displayId);
            new Handler(Looper.getMainLooper()).postDelayed(()->hidePanelLabel(left),1200);
        }catch(SecurityException se){updatePanelLabel(left,"ANDROID BLOCKED APP LAUNCH\n"+shortMsg(se));status.setText("Android blocked launch on display "+displayId+": "+shortMsg(se));}
        catch(Throwable t){updatePanelLabel(left,"APP LAUNCH FAILED\n"+shortMsg(t));status.setText("Launch failed: "+shortMsg(t));}
    }

    private String appName(String pkg){try{PackageManager pm=getPackageManager();CharSequence l=pm.getApplicationLabel(pm.getApplicationInfo(pkg,0));return l!=null?l.toString():pkg;}catch(Throwable t){return pkg;}}
    private static String shortMsg(Throwable t){String s=t.getMessage();if(s==null)s=t.getClass().getSimpleName();return s.length()>120?s.substring(0,120):s;}
    private static class AppEntry{final String name,pkg;AppEntry(String n,String p){name=n;pkg=p;}}

    private void updatePanelLabel(boolean left,String text){if(presentation==null)return;TextView v=left?presentation.leftLabel:presentation.rightLabel;v.setText(text);v.setVisibility(View.VISIBLE);}
    private void hidePanelLabel(boolean left){if(presentation==null)return;(left?presentation.leftLabel:presentation.rightLabel).setVisibility(View.GONE);}

    private void layoutWorld(){
        if(presentation==null||presentation.root==null)return;
        int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        int worldW=vw*5; FrameLayout.LayoutParams wlp=(FrameLayout.LayoutParams)presentation.world.getLayoutParams();wlp.width=worldW;wlp.height=vh;wlp.gravity=Gravity.TOP|Gravity.LEFT;presentation.world.setLayoutParams(wlp);
        int pw=Math.max(320,Math.round(vw*panelScale)),ph=Math.max(240,Math.round(vh*panelScale));float cx=worldW/2f,gap=panelSpacingScreens*vw;
        placePanel(presentation.leftPanel,pw,ph,cx-gap,vh/2f);placePanel(presentation.centerPanel,pw,ph,cx,vh/2f);placePanel(presentation.rightPanel,pw,ph,cx+gap,vh/2f);presentation.worldCenterX=cx;updateCamera();
    }

    private void placePanel(View v,int w,int h,float cx,float cy){FrameLayout.LayoutParams lp=(FrameLayout.LayoutParams)v.getLayoutParams();lp.width=w;lp.height=h;lp.gravity=Gravity.TOP|Gravity.LEFT;v.setLayoutParams(lp);v.setX(cx-w/2f);v.setY(cy-h/2f);}

    private void pinHere(){
        if(!havePose&&TrackingService.livePoseValid){latestPitch=(float)TrackingService.livePitch;latestYaw=(float)TrackingService.liveYaw;filteredPitch=latestPitch;filteredYaw=latestYaw;havePose=true;}
        if(!havePose){status.setText("Start head tracking first — no IMU pose yet");return;}
        filteredPitch=latestPitch;filteredYaw=latestYaw;anchorPitch=filteredPitch;anchorYaw=filteredYaw;updateCamera();status.setText("PINNED — centre is straight ahead");
    }

    private void updateCamera(){
        if(presentation==null||presentation.root==null||presentation.world==null)return;int vw=presentation.root.getWidth(),vh=presentation.root.getHeight();if(vw<=0||vh<=0)return;
        float yaw=filteredYaw-anchorYaw,pitch=filteredPitch-anchorPitch;float dx=(invertX?1f:-1f)*(yaw/hFovDeg)*vw;float dy=(invertY?1f:-1f)*(pitch/vFovDeg)*vh;float baseX=vw/2f-presentation.worldCenterX;presentation.world.setTranslationX(baseX+dx);presentation.world.setTranslationY(dy);lastDx=dx;lastDy=dy;
    }

    private void releaseCentreCapture(){VirtualDisplay vd=centreCaptureDisplay;centreCaptureDisplay=null;if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}Surface s=centreCaptureSurface;centreCaptureSurface=null;if(s!=null)try{s.release();}catch(Throwable ignored){} }

    private void releaseAppDisplay(boolean left){
        VirtualDisplay vd=left?leftAppDisplay:rightAppDisplay;Surface s=left?leftAppSurface:rightAppSurface;
        if(left){leftAppDisplay=null;leftAppSurface=null;leftDisplayId=Display.INVALID_DISPLAY;}else{rightAppDisplay=null;rightAppSurface=null;rightDisplayId=Display.INVALID_DISPLAY;}
        if(vd!=null){try{vd.setSurface(null);}catch(Throwable ignored){}try{vd.release();}catch(Throwable ignored){}}if(s!=null)try{s.release();}catch(Throwable ignored){};
    }

    private void stopAnchor(){
        if(stopping)return;stopping=true;anchorRunning=false;releaseCentreCapture();releaseAppDisplay(true);releaseAppDisplay(false);
        SpatialPresentation p=presentation;presentation=null;if(p!=null){try{p.centerTexture.setSurfaceTextureListener(null);p.leftTexture.setSurfaceTextureListener(null);p.rightTexture.setSurfaceTextureListener(null);}catch(Throwable ignored){}try{p.dismiss();}catch(Throwable ignored){}}
        MediaProjection mp=projection;projection=null;if(mp!=null){if(projectionCallback!=null)try{mp.unregisterCallback(projectionCallback);}catch(Throwable ignored){}try{mp.stop();}catch(Throwable ignored){}}projectionCallback=null;stopping=false;if(status!=null)status.setText("Spatial desktop stopped safely");
    }

    @Override protected void onDestroy(){Choreographer.getInstance().removeFrameCallback(frameCallback);try{unregisterReceiver(overlayReceiver);}catch(Throwable ignored){}try{stopService(new Intent(this,OverlayControlService.class));}catch(Throwable ignored){}stopAnchor();super.onDestroy();}

    private static class SpatialPresentation extends Presentation {
        FrameLayout root,world,leftPanel,centerPanel,rightPanel;TextureView leftTexture,centerTexture,rightTexture;TextView leftLabel,rightLabel;float worldCenterX;
        SpatialPresentation(Context c,Display d){super(c,d);}
        @Override protected void onCreate(Bundle b){
            super.onCreate(b);getWindow().setBackgroundDrawableResource(android.R.color.black);getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            root=new FrameLayout(getContext());root.setBackgroundColor(Color.BLACK);root.setClipChildren(true);world=new FrameLayout(getContext());world.setBackgroundColor(Color.BLACK);world.setClipChildren(false);world.setClipToPadding(false);root.addView(world,new FrameLayout.LayoutParams(1,-1,Gravity.TOP|Gravity.LEFT));
            leftPanel=panel(getContext(),0xff111317);centerPanel=panel(getContext(),Color.BLACK);rightPanel=panel(getContext(),0xff111317);world.addView(leftPanel,new FrameLayout.LayoutParams(1,1));world.addView(centerPanel,new FrameLayout.LayoutParams(1,1));world.addView(rightPanel,new FrameLayout.LayoutParams(1,1));
            leftTexture=texture(getContext());leftPanel.addView(leftTexture,new FrameLayout.LayoutParams(-1,-1));leftLabel=label(getContext(),"LEFT\nVIRTUAL DISPLAY");leftPanel.addView(leftLabel,new FrameLayout.LayoutParams(-1,-1));
            centerTexture=texture(getContext());centerPanel.addView(centerTexture,new FrameLayout.LayoutParams(-1,-1));TextView ct=tag(getContext(),"CENTRE • PHONE LIVE");FrameLayout.LayoutParams ctlp=new FrameLayout.LayoutParams(-2,-2,Gravity.TOP|Gravity.CENTER_HORIZONTAL);ctlp.topMargin=10;centerPanel.addView(ct,ctlp);
            rightTexture=texture(getContext());rightPanel.addView(rightTexture,new FrameLayout.LayoutParams(-1,-1));rightLabel=label(getContext(),"RIGHT\nVIRTUAL DISPLAY");rightPanel.addView(rightLabel,new FrameLayout.LayoutParams(-1,-1));setContentView(root);
        }
        private static FrameLayout panel(Context c,int bg){FrameLayout f=new FrameLayout(c);f.setBackgroundColor(bg);f.setClipChildren(true);f.setElevation(2f);return f;}
        private static TextureView texture(Context c){TextureView t=new TextureView(c);t.setOpaque(true);return t;}
        private static TextView label(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(22);v.setGravity(Gravity.CENTER);v.setTextColor(0xffe0e0e0);v.setBackgroundColor(0xaa171b22);return v;}
        private static TextView tag(Context c,String t){TextView v=new TextView(c);v.setText(t);v.setTextSize(13);v.setTextColor(Color.WHITE);v.setBackgroundColor(0x99000000);v.setPadding(12,6,12,6);return v;}
    }
}
