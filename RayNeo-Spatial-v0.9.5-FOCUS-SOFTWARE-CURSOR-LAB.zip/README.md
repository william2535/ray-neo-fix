# RayNeo Spatial v0.9.5 — Focus + Software Cursor LAB

Experimental build based on the smooth v0.9.3.3 isolated-Shizuku architecture.

## What changed

- Removed the v0.9.4 accelerometer/depth experiment completely.
- Keeps the proven Air 4 Pro tracking and independent LEFT/RIGHT VirtualDisplays.
- Adds intentional gaze-focus enlargement: the panel closest to the centre of view grows smoothly while the others shrink.
- Adds a RayNeo-drawn software crosshair for LEFT and RIGHT. It does **not** rely on Android rendering a mouse cursor on a VirtualDisplay.
- The crosshair is gaze-based: the centre of the glasses viewport is projected into the selected side panel.
- `CLICK SELECTED` maps that crosshair position into the VirtualDisplay buffer and asks the isolated Shizuku bridge to run a display-targeted touchscreen tap.
- `BACK SELECTED` sends Back to the selected VirtualDisplay.
- `CONTROL CENTRE` restores the normal `/dev/uinput` head mouse.

## Test order

1. Keep Shizuku running in the background.
2. Start RayNeo tracking and confirm smoothness.
3. Start Anchor / Spatial Desktop.
4. Connect Shizuku.
5. Create LEFT and RIGHT displays and launch different apps.
6. Press CONTROL LEFT. A white crosshair should appear on the LEFT panel as you look around it.
7. Aim at a button and press CLICK SELECTED.
8. Repeat on RIGHT.
9. Press CONTROL CENTRE to return to the normal head mouse.

## Notes

This is still a LAB build. Keep v0.8 as the public known-good release. The side-panel tap path uses Android's `input touchscreen -d DISPLAY_ID tap X Y` command through the already-isolated Shizuku process.
